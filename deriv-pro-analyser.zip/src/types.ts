export interface Market {
  symbol: string;
  name: string;
}

export interface Tick {
  epoch: number;
  quote: number;
  digit: number;
  symbol: string;
}

export interface DigitDistribution {
  digit: number;
  count: number;
  percentage: number;
  recentCount: number;
  recentPercentage: number;
  status: "high" | "low" | "normal";
}

export interface AnalysisOutcome {
  label: string;
  count: number;
  percentage: number;
}

export interface AnalysisResult {
  indication: "MATCH" | "DIFFER" | "EVEN" | "ODD" | "OVER" | "UNDER";
  predictedDigit: number | null;
  predictedDigitPercentage: number | null;
  unrestrictedDigit: number | null;
  unrestrictedDigitPercentage: number | null;
  confidence: number;
  winProbability: number;
  explanation: string;
  distribution: Record<string, number>;
  percentages: number[];
  outcomes: AnalysisOutcome[];
  evenCount: number;
  oddCount: number;
  sampleSize: number;
  pattern: string;
  topDigits: number[];
  lowDigits: number[];
}

export interface ScannerMarketRank {
  symbol: string;
  name: string;
  score: number;
  sample: number;
  activity: number;
}

export interface WebSocketEndpoint {
  id: string;
  label: string;
  url: string;
}

export interface FeedSnapshot {
  status: "connecting" | "open" | "closed" | "error";
  error: string | null;
  endpoint: WebSocketEndpoint | null;
  lastMessageAt: number;
  version: number;
}

export interface MarketBook {
  symbol: string;
  ticks: Tick[];
  pipSize?: number;
  state: "loading" | "live" | "error";
  error: string | null;
  lastTickAt: number;
}

export interface UserProfile {
  id: string;
  username: string;
  email: string;
  is_admin: boolean;
  account_status: "ACTIVE" | "PENDING" | "EXPIRED";
  access_level: "PRO" | "STANDARD";
  access_expiry: string | null;
  pro_entitled: boolean;
  payment_status: "VERIFIED" | "UNPAID";
  created_at: string;
  updated_at: string;
}

export interface UserSession {
  user: {
    id: string;
    username: string;
  };
}

export type PageId =
  | "dashboard"
  | "matches"
  | "evenodd"
  | "overunder"
  | "scanner"
  | "frequency";
