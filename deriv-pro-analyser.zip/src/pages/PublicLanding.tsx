import React, { useState } from "react";
import {
  ArrowDown,
  ArrowRight,
  Bot,
  Check,
  ExternalLink,
  Laptop,
  Lock,
  MessageCircle,
  ShieldAlert,
  Smartphone,
  Sparkles,
  TrendingUp,
} from "lucide-react";
import { Logo } from "../components/Logo";
import { AutomatedPipelineBanner } from "../components/AutomatedPipelineBanner";
import { LoginModal } from "../components/LoginModal";
import { TermsModal } from "../components/TermsModal";
import {
  openBotPurchaseWhatsApp,
  openPurchaseWhatsApp,
  RNGTRADER_URL,
} from "../constants";

export const PublicLanding: React.FC = () => {
  const [loginOpen, setLoginOpen] = useState(false);
  const [termsOpen, setTermsOpen] = useState(false);

  const scrollToAccess = () => {
    document.getElementById("access")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-white selection:bg-[#0ea5e9] selection:text-black">
      {/* Background Decorators */}
      <div className="pointer-events-none absolute inset-0 bg-grid-faint opacity-60 [background-size:40px_40px]" />
      <div className="pointer-events-none absolute -top-32 left-1/2 h-[480px] w-[820px] max-w-[140vw] -translate-x-1/2 rounded-full bg-[#e0f2fe] blur-3xl" />

      {/* Top Navbar */}
      <header className="relative z-10 flex items-center justify-between gap-3 px-4 py-5 sm:px-10">
        <Logo size="md" />
        <div className="flex items-center gap-3">
          <a
            href="#access"
            className="hidden items-center gap-1.5 text-xs font-extrabold uppercase tracking-wide text-[#22272e] hover:text-[#0369a1] sm:inline-flex"
          >
            How to access <ArrowDown size={14} />
          </a>
          <button
            onClick={() => setLoginOpen(true)}
            className="btn-primary py-2 px-4 text-xs font-extrabold"
          >
            Access / Login <ArrowRight size={14} />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 mx-auto w-full max-w-5xl px-4 pb-20 sm:px-6">
        {/* Hero Section */}
        <section className="flex flex-col items-center pt-6 text-center sm:pt-14">
          <span className="chip mb-6 animate-fade-in border-black bg-black text-white shadow-hard">
            <Sparkles size={13} className="text-[#38bdf8]" />
            Automated digit-market analysis
          </span>

          <h1 className="font-display text-4xl font-extrabold leading-tight tracking-tight text-black sm:text-6xl max-w-4xl">
            Welcome to the World of{" "}
            <span className="text-[#0369a1] underline decoration-[#0ea5e9] decoration-4">
              Deriv Automation
            </span>
          </h1>

          <p className="mt-5 max-w-2xl text-base font-semibold text-[#5c636b] sm:text-lg">
            The engine connects to the live Deriv tick feed, reads every last
            digit and scores the market automatically. You pick a market; the
            analysis runs itself.
          </p>

          <div className="mt-8 flex flex-col sm:flex-row items-center gap-3 w-full max-w-md justify-center">
            <button
              onClick={() => setLoginOpen(true)}
              className="btn-primary w-full sm:w-auto px-8 py-4 text-base"
            >
              Access / Login <ArrowRight size={18} />
            </button>
            <button
              onClick={scrollToAccess}
              className="btn-ghost w-full sm:w-auto px-6 py-4 text-sm font-bold border-2 border-black"
            >
              <ArrowDown size={16} /> How to Purchase
            </button>
          </div>
        </section>

        {/* Engine Pipeline Banner */}
        <div className="mt-12">
          <AutomatedPipelineBanner />
        </div>

        {/* Works Everywhere Section */}
        <section className="mt-16">
          <div className="mb-4 border-t-2 border-[#e6e9ed] pt-8">
            <p className="font-mono text-[10px] font-extrabold uppercase tracking-[0.22em] text-[#0369a1]">
              Works everywhere
            </p>
            <h2 className="mt-1 font-display text-2xl font-extrabold uppercase tracking-tight text-black sm:text-3xl">
              Mobile + PC Ready
            </h2>
            <p className="mt-2 max-w-2xl text-sm font-semibold leading-relaxed text-[#5c636b]">
              Use Deriv Pro Analyser on your smartphone, tablet or desktop
              computer. No software download or high-end computer required.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="flex items-center gap-4 rounded-xl border-2 border-black bg-black p-5 text-white shadow-hard">
              <Smartphone size={28} className="shrink-0 text-[#38bdf8]" />
              <div className="min-w-0">
                <p className="font-display text-base font-extrabold uppercase">
                  Phone & Tablet
                </p>
                <p className="font-mono text-xs font-bold text-white/70">
                  Optimized for fast mobile browser operation
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4 rounded-xl border-2 border-black bg-white p-5 text-black shadow-hard">
              <Laptop size={28} className="shrink-0 text-[#0369a1]" />
              <div className="min-w-0">
                <p className="font-display text-base font-extrabold uppercase">
                  Laptop & Desktop
                </p>
                <p className="font-mono text-xs font-bold text-[#5c636b]">
                  Full-width analysis workspace with live charts
                </p>
              </div>
            </div>
          </div>

          <ul className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {[
              "Mobile compatible",
              "PC compatible",
              "Responsive interface",
              "Instant browser access",
            ].map((feature) => (
              <li
                key={feature}
                className="flex items-center gap-2 text-xs font-extrabold text-[#22272e]"
              >
                <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full border-2 border-black bg-[#0ea5e9] text-black">
                  <Check size={11} strokeWidth={3.5} />
                </span>
                {feature}
              </li>
            ))}
          </ul>
        </section>

        {/* Free Automated Bots (RNGTrader) Section */}
        <section className="mt-16">
          <div className="mb-4 border-t-2 border-[#e6e9ed] pt-8">
            <p className="font-mono text-[10px] font-extrabold uppercase tracking-[0.22em] text-[#0369a1]">
              Third-party integration
            </p>
            <h2 className="mt-1 font-display text-2xl font-extrabold uppercase tracking-tight text-black sm:text-3xl">
              Free Automated Trading Bots
            </h2>
            <p className="mt-2 max-w-2xl text-sm font-semibold leading-relaxed text-[#5c636b]">
              RNGTrader is a professional automated trading platform for Deriv,
              providing free access to automated trading bots and synchronised
              strategies.
            </p>
          </div>

          <div className="glass-card p-6 shadow-hard">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl border-2 border-black bg-black text-white shadow-hard">
                  <Bot size={24} />
                </span>
                <div>
                  <p className="font-display text-lg font-extrabold uppercase tracking-wide text-black">
                    RNGTrader Platform
                  </p>
                  <p className="font-mono text-xs font-bold text-[#0369a1]">
                    rngtrader.site
                  </p>
                  <p className="mt-1 text-xs font-semibold text-[#5c636b]">
                    Free premium automated bots and tested digit strategies.
                  </p>
                </div>
              </div>

              <a
                href={RNGTRADER_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary py-3 px-6 whitespace-nowrap"
              >
                <ExternalLink size={16} /> Load Free Platform
              </a>
            </div>

            <p className="mt-4 text-center font-mono text-[11px] font-bold text-[#8e959e] border-t border-[#e6e9ed] pt-3">
              RNGTrader is an independent third-party service. It is not owned
              or operated by Deriv, and it is not part of Deriv Pro Analyser.
            </p>
          </div>
        </section>

        {/* Stated Accuracy Range */}
        <section className="mt-16">
          <div className="rounded-2xl border-2 border-black bg-black p-6 text-center text-white shadow-hard sm:p-10">
            <p className="font-mono text-[11px] font-extrabold uppercase tracking-[0.22em] text-[#38bdf8]">
              Statistical Model Accuracy
            </p>
            <p className="mt-2 font-display text-5xl font-extrabold tracking-tight sm:text-6xl text-white">
              86% – 96%
            </p>
            <p className="mx-auto mt-3 max-w-md text-xs sm:text-sm font-semibold text-white/75">
              The tool measures historical digit frequency deviation and
              calculates probability estimates across active volatility tick streams.
            </p>

            <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
              <span className="rounded-full border border-white/20 bg-white/10 px-3 py-1 font-mono text-xs font-bold text-[#7dd3fc]">
                Measured In-Stream Win Rates
              </span>
              <span className="rounded-full border border-white/20 bg-white/10 px-3 py-1 font-mono text-xs font-bold text-[#7dd3fc]">
                Dynamic Model Confidence
              </span>
            </div>
          </div>

          <div className="mt-4 rounded-xl border-2 border-amber-500 bg-amber-50 p-4 text-xs font-semibold leading-relaxed text-amber-900">
            <strong>Notice:</strong> Accuracy figures reflect calculated statistical
            probabilities derived from recent tick samples. Market outcomes are
            uncertain, and past statistical frequencies do not guarantee future
            trades.
          </div>
        </section>

        {/* Paid Access / How to Access Section */}
        <section id="access" className="mt-16">
          <div className="mb-4 border-t-2 border-[#e6e9ed] pt-8">
            <p className="font-mono text-[10px] font-extrabold uppercase tracking-[0.22em] text-[#0369a1]">
              Paid access
            </p>
            <h2 className="mt-1 font-display text-2xl font-extrabold uppercase tracking-tight text-black sm:text-3xl">
              How to Access Deriv Pro Analyser
            </h2>
            <p className="mt-2 max-w-2xl text-sm font-semibold leading-relaxed text-[#5c636b]">
              Public access to Deriv Pro Analyser is available for a one-time fee
              of $115. Message us directly on WhatsApp to receive your private login credentials.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            {/* Analyser Full Access */}
            <div className="glass-card p-6 shadow-hard flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-display font-extrabold uppercase text-lg">
                    Full Analyser Access
                  </span>
                  <span className="font-mono text-2xl font-extrabold text-[#0369a1]">
                    $115
                  </span>
                </div>
                <p className="mt-2 text-xs font-semibold text-[#5c636b]">
                  Lifetime account login with full access to all analytical modules.
                </p>

                <ul className="mt-5 space-y-2 text-xs font-bold text-[#22272e]">
                  {[
                    "Full access to all 5 analysis modules",
                    "Volatility scanner & frequency graphs",
                    "Matches/Differs, Even/Odd, Over/Under",
                    "Real-time live Deriv WebSocket streaming",
                    "Dedicated WhatsApp support & setup",
                  ].map((item) => (
                    <li key={item} className="flex items-center gap-2">
                      <Check size={14} className="text-[#0369a1] shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-6">
                <button
                  onClick={openPurchaseWhatsApp}
                  className="btn-primary w-full py-3.5 text-xs sm:text-sm font-extrabold"
                >
                  <MessageCircle size={16} /> Purchase via WhatsApp ($115)
                </button>
              </div>
            </div>

            {/* Synchronised Pro Bot */}
            <div className="glass-card p-6 shadow-hard flex flex-col justify-between bg-[#f0f9ff]">
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-display font-extrabold uppercase text-lg">
                    Synchronised Pro Bot
                  </span>
                  <span className="font-mono text-2xl font-extrabold text-black">
                    $55
                  </span>
                </div>
                <p className="mt-2 text-xs font-semibold text-[#5c636b]">
                  Automated execution bot pre-synchronised to the Analyser's signals.
                </p>

                <ul className="mt-5 space-y-2 text-xs font-bold text-[#22272e]">
                  {[
                    "Plug & play bot for Deriv platform",
                    "Automated signal ingestion",
                    "Preset risk management & stop-loss rules",
                    "Strategy manual & configuration guide",
                  ].map((item) => (
                    <li key={item} className="flex items-center gap-2">
                      <Check size={14} className="text-black shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-6">
                <button
                  onClick={openBotPurchaseWhatsApp}
                  className="btn-ghost w-full py-3.5 text-xs sm:text-sm font-extrabold border-2 border-black bg-white"
                >
                  <MessageCircle size={16} /> Get Pro Bot ($55)
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Disclaimers & Footer */}
        <footer className="mt-20 border-t-2 border-[#e6e9ed] pt-8 text-center">
          <div className="flex items-center justify-center gap-2 mb-3">
            <button
              onClick={() => setTermsOpen(true)}
              className="text-xs font-bold text-[#0369a1] hover:underline cursor-pointer"
            >
              Terms & Conditions
            </button>
            <span className="text-[#8e959e]">·</span>
            <button
              onClick={() => setLoginOpen(true)}
              className="text-xs font-bold text-[#0369a1] hover:underline cursor-pointer"
            >
              Account Login
            </button>
          </div>

          <p className="mx-auto max-w-xl text-[11px] font-medium leading-relaxed text-[#8e959e]">
            Deriv Pro Analyser is a statistical analysis tool only. It does not
            place trades, does not guarantee profits and is not financial
            advice. All financial market outcomes are uncertain.
          </p>
          <p className="mt-3 font-mono text-[11px] font-bold text-[#5c636b]">
            © {new Date().getFullYear()} Deriv Pro Analyser. All rights reserved.
          </p>
        </footer>
      </main>

      <LoginModal open={loginOpen} onClose={() => setLoginOpen(false)} />
      <TermsModal open={termsOpen} onClose={() => setTermsOpen(false)} />
    </div>
  );
};
