import React, { useEffect, useRef, useState } from "react";
import { ArrowUpDown, ChevronDown, RefreshCw, Zap } from "lucide-react";
import { ALL_DIGITS, MARKETS } from "../constants";
import { Tick } from "../types";
import { useAnalysisRunner } from "../hooks/useDeriv";
import { calculateOverUnder } from "../utils/analysis";
import { LiveDigitRibbon } from "../components/LiveDigitRibbon";
import { DigitFrequencyGauges } from "../components/DigitFrequencyGauges";
import {
  AnalysisControls,
  MarketSelector,
  ModuleHeader,
} from "../components/MarketControls";
import { ProbabilityCards } from "../components/ProbabilityCards";
import { OutcomeBreakdown } from "../components/OutcomeBreakdown";
import { AnalysisRunnerOverlay } from "../components/AnalysisRunnerOverlay";

interface OverUnderViewProps {
  ticks: Tick[];
  selectedSymbol: string;
  onSelectSymbol: (symbol: string) => void;
  feedStatus: "connecting" | "open" | "closed" | "error";
}

export const OverUnderView: React.FC<OverUnderViewProps> = ({
  ticks,
  selectedSymbol,
  onSelectSymbol,
  feedStatus,
}) => {
  const activeMarket =
    MARKETS.find((m) => m.symbol === selectedSymbol) ?? MARKETS[0];

  const [sampleSize, setSampleSize] = useState(120);
  const [mode, setMode] = useState("STANDARD");
  const [entryDigit, setEntryDigit] = useState<number | null>(5);
  const [executedDigit, setExecutedDigit] = useState<number | null>(null);

  const runner = useAnalysisRunner();
  const DURATION_SEC = 4;
  const isFirstMount = useRef(true);

  useEffect(() => {
    if (isFirstMount.current) {
      isFirstMount.current = false;
      return;
    }
    runner.reset();
    setExecutedDigit(null);
  }, [selectedSymbol, entryDigit]);

  const handleRun = () => {
    if (entryDigit === null) return;
    setExecutedDigit(entryDigit);
    runner.run({
      symbol: selectedSymbol,
      mode,
      sampleSize,
      entryDigit,
      durationSec: DURATION_SEC,
      compute: (sampleTicks, _, d) => calculateOverUnder(sampleTicks, d ?? 5),
    });
  };

  const result = runner.result;
  const isRunning = runner.phase === "running";
  const isDone = runner.phase === "done" && result != null && executedDigit != null;
  const isOver = result?.indication === "OVER";

  return (
    <div className="space-y-6">
      <ModuleHeader
        icon={<ArrowUpDown size={22} />}
        title="Over / Under Analysis"
        subtitle="Pick an entry barrier digit, then calculate which side of it the next tick is statistically more likely to land on."
      />

      {/* Market Selector */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <MarketSelector
            value={selectedSymbol}
            onChange={onSelectSymbol}
            disabled={runner.locked}
          />
        </div>
        <div className="flex items-end">
          <div className="glass-card flex w-full items-center justify-between p-4">
            <span className="section-title">Active Market</span>
            <span className="font-display font-extrabold text-black">
              {activeMarket.name}
            </span>
          </div>
        </div>
      </div>

      {/* Entry Digit Selector Box */}
      <div className="glass-card p-5">
        <h3 className="font-display font-extrabold uppercase tracking-wide text-black">
          Select Entry Barrier Digit
        </h3>
        <p className="mb-4 font-mono text-xs font-bold text-[#5c636b]">
          Over wins above your digit, Under wins below it. Landing exactly on it loses both.
        </p>

        {/* 0-9 Digit Buttons */}
        <div className="flex flex-wrap gap-2">
          {ALL_DIGITS.map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => setEntryDigit(d)}
              disabled={runner.locked}
              className={`grid h-12 w-12 place-items-center rounded-xl border-2 border-black font-mono text-lg font-extrabold transition-all disabled:opacity-40 cursor-pointer ${
                entryDigit === d
                  ? "bg-[#0ea5e9] text-black shadow-hard scale-105"
                  : "bg-white text-black hover:bg-[#f0f9ff] hover:text-[#0369a1]"
              }`}
            >
              {d}
            </button>
          ))}
        </div>

        {/* Dropdown helper */}
        <div className="relative mt-4 max-w-xs">
          <select
            value={entryDigit ?? ""}
            onChange={(e) =>
              setEntryDigit(e.target.value === "" ? null : Number(e.target.value))
            }
            disabled={runner.locked}
            className="input-field cursor-pointer appearance-none pr-10 disabled:bg-[#f4f6f8]"
          >
            <option value="">— Select digit —</option>
            {ALL_DIGITS.map((d) => (
              <option key={d} value={d}>
                Barrier Digit {d}
              </option>
            ))}
          </select>
          <ChevronDown
            size={18}
            className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-black"
          />
        </div>

        {entryDigit !== null && (
          <p className="mt-3 rounded-xl border-2 border-[#e6e9ed] bg-[#f4f6f8] p-3 font-mono text-xs font-bold text-[#22272e]">
            Selected Barrier: <strong>Digit {entryDigit}</strong>. Baseline Over:{" "}
            {((9 - entryDigit) * 10).toFixed(0)}% · Baseline Under:{" "}
            {(entryDigit * 10).toFixed(0)}%.
          </p>
        )}
      </div>

      {/* Live Digit Ribbon */}
      <LiveDigitRibbon
        ticks={ticks}
        symbol={selectedSymbol}
        marketName={activeMarket.name}
        status={feedStatus}
        span={24}
      />

      {/* Digit Frequency Gauges */}
      <DigitFrequencyGauges ticks={ticks} />

      {/* Engine Controls */}
      <AnalysisControls
        tickCount={sampleSize}
        setTickCount={setSampleSize}
        mode={mode}
        setMode={setMode}
        marketName={activeMarket.name}
        duration={DURATION_SEC}
        locked={runner.locked}
      />

      {/* Action Execution Card */}
      <div className="glass-card p-5 sm:p-7">
        <div className="flex flex-col items-center gap-6">
          <div className="text-center">
            <span className="section-title text-[#5c636b]">Barrier Prediction</span>
            <p className="mt-1 font-display text-sm font-extrabold uppercase text-black">
              Calculate Deviation Against Digit {entryDigit}
            </p>
          </div>

          {!isRunning && !isDone && (
            <button
              type="button"
              onClick={handleRun}
              disabled={entryDigit === null || feedStatus !== "open" || runner.locked}
              className="btn-primary w-full max-w-sm py-4 text-base"
            >
              <Zap size={18} /> Run Over / Under Analysis
            </button>
          )}

          {/* Running State */}
          {isRunning && (
            <div className="w-full max-w-md">
              <AnalysisRunnerOverlay
                progress={runner.progress}
                message={`Calculating barrier deviation around digit ${entryDigit} on ${activeMarket.name}...`}
              />
            </div>
          )}

          {/* Done State */}
          {isDone && (
            <div className="flex w-full flex-col items-center gap-5 border-t-2 border-[#e6e9ed] pt-6 animate-scale-in">
              <div className="flex items-center gap-3">
                <span
                  className={`grid h-14 w-14 place-items-center rounded-2xl border-2 border-black font-display text-2xl font-extrabold uppercase text-white shadow-hard animate-slam ${
                    isOver ? "bg-[#0ea5e9] text-black" : "bg-[#0c4a6e] text-white"
                  }`}
                >
                  {isOver ? "▲" : "▼"}
                </span>
                <span className="font-display text-4xl font-extrabold uppercase tracking-tight text-black sm:text-5xl">
                  {result.indication} {executedDigit}
                </span>
              </div>

              {/* Probability Cards */}
              <ProbabilityCards
                winProbability={result.winProbability}
                confidence={result.confidence}
                sampleSize={result.sampleSize}
              />

              {/* Outcome Breakdown */}
              <div className="w-full max-w-md">
                <OutcomeBreakdown
                  outcomes={result.outcomes}
                  highlight={result.indication}
                />
              </div>

              {/* Explanation Note */}
              <p className="max-w-md text-center text-xs font-semibold leading-relaxed text-[#5c636b]">
                {result.explanation}
              </p>

              <button
                type="button"
                onClick={() => runner.reset()}
                className="btn-ghost w-full max-w-sm border-2 border-black"
              >
                <RefreshCw size={15} /> Reset / Run Another
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
