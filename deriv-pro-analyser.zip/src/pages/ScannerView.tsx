import React, { useEffect, useRef, useState } from "react";
import { Check, Dices, Loader2, Radar, Sparkles } from "lucide-react";
import { MARKETS } from "../constants";
import { ScannerMarketRank, Tick } from "../types";
import { derivClient } from "../services/derivClient";
import {
  rankMarketsByDeviation,
  weightedRandomSelect,
} from "../utils/analysis";
import { MarketSelector, ModuleHeader } from "../components/MarketControls";
import { StatusIndicator } from "../components/StatusIndicator";

interface ScannerViewProps {
  selectedSymbol: string;
  onSelectSymbol: (symbol: string) => void;
  feedStatus: "connecting" | "open" | "closed" | "error";
}

const SCAN_STEPS = [
  "Scanning volatility markets",
  "Collecting recent tick data",
  "Extracting last digits",
  "Comparing digit distributions",
  "Ranking markets by deviation",
  "Picking a market at random",
];

export const ScannerView: React.FC<ScannerViewProps> = ({
  selectedSymbol,
  onSelectSymbol,
  feedStatus,
}) => {
  const [phase, setPhase] = useState<"idle" | "scanning" | "done">("idle");
  const [progress, setProgress] = useState(0);
  const [stepMessage, setStepMessage] = useState("Scanning volatility markets");
  const [rankings, setRankings] = useState<ScannerMarketRank[]>([]);
  const [selectedMarket, setSelectedMarket] = useState<ScannerMarketRank | null>(
    null
  );

  const shuffleIntervalRef = useRef<NodeJS.Timeout | number | null>(null);

  useEffect(() => {
    return () => {
      if (shuffleIntervalRef.current) clearInterval(shuffleIntervalRef.current);
    };
  }, []);

  const handleScan = async () => {
    setPhase("scanning");
    setProgress(0);
    setSelectedMarket(null);

    let stepIdx = 0;
    const msgTimer = setInterval(() => {
      setStepMessage(SCAN_STEPS[Math.min(stepIdx, SCAN_STEPS.length - 1)]);
      stepIdx++;
    }, 1100);

    const progTimer = setInterval(() => {
      setProgress((p) => Math.min(p + 100 / 60, 95));
    }, 100);

    // Rapid shuffle market animation
    if (shuffleIntervalRef.current) clearInterval(shuffleIntervalRef.current);
    shuffleIntervalRef.current = setInterval(() => {
      const randomMarket = MARKETS[Math.floor(Math.random() * MARKETS.length)];
      onSelectSymbol(randomMarket.symbol);
    }, 150);

    try {
      const results: Record<string, Tick[]> = {};

      // Batch in parallel
      const chunks = [MARKETS.slice(0, 5), MARKETS.slice(5, 10)];
      for (const group of chunks) {
        const settled = await Promise.allSettled(
          group.map(async (m) => {
            const ticks = await derivClient.history(m.symbol, 180);
            return { symbol: m.symbol, ticks };
          })
        );

        settled.forEach((res) => {
          if (res.status === "fulfilled") {
            results[res.value.symbol] = res.value.ticks;
          }
        });
      }

      const ranked = rankMarketsByDeviation(results).map((item) => {
        const matched = MARKETS.find((m) => m.symbol === item.symbol);
        return {
          ...item,
          name: matched ? matched.name : item.symbol,
        };
      });

      setRankings(ranked);

      if (ranked.length > 0) {
        const picked = weightedRandomSelect(ranked);
        setSelectedMarket(picked);
        onSelectSymbol(picked.symbol);
      }
      setProgress(100);
    } catch (err) {
      console.warn("Scan error", err);
    } finally {
      if (shuffleIntervalRef.current) {
        clearInterval(shuffleIntervalRef.current);
        shuffleIntervalRef.current = null;
      }
      clearInterval(msgTimer);
      clearInterval(progTimer);
      setStepMessage("Scan complete");
      setTimeout(() => setPhase("done"), 500);
    }
  };

  const handlePickAnother = () => {
    if (!rankings.length) return;
    const picked = weightedRandomSelect(rankings);
    setSelectedMarket(picked);
    onSelectSymbol(picked.symbol);
  };

  const isScanning = phase === "scanning";
  const isDone = phase === "done" && rankings.length > 0;

  return (
    <div className="space-y-6">
      <ModuleHeader
        icon={<Radar size={22} />}
        title="Volatility Scanner"
        subtitle="Scan every synthetic volatility market, rank them by digit deviation, then auto-select the highest statistical edge."
      />

      {/* Market Selector & Scan Button */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <MarketSelector
            value={selectedSymbol}
            onChange={onSelectSymbol}
            spinning={isScanning}
            disabled={isScanning}
          />
        </div>
        <div className="flex items-end">
          <button
            onClick={handleScan}
            disabled={isScanning || feedStatus !== "open"}
            className="btn-primary w-full py-4 text-base cursor-pointer"
          >
            {isScanning ? (
              <>
                <Loader2 size={18} className="animate-spin" /> Scanning Markets...
              </>
            ) : (
              <>
                <Radar size={18} /> Scan Volatility Markets
              </>
            )}
          </button>
        </div>
      </div>

      {/* Scanning In-Progress Card */}
      {isScanning && (
        <div className="glass-card overflow-hidden">
          <div className="relative h-1.5 overflow-hidden bg-[#e6e9ed]">
            <div className="absolute inset-y-0 w-1/3 animate-scan-sweep bg-[#0ea5e9]" />
          </div>
          <div className="flex flex-col items-center justify-center p-8 text-center gap-4">
            <div className="grid h-14 w-14 place-items-center rounded-2xl border-2 border-black bg-[#0ea5e9] text-black shadow-hard animate-pulse-slow">
              <Radar size={28} />
            </div>
            <div>
              <p className="font-display text-lg font-extrabold uppercase text-black">
                {stepMessage}
              </p>
              <p className="font-mono text-xs font-bold text-[#0369a1] mt-1">
                Sampling 180 ticks per instrument in real-time...
              </p>
            </div>

            <div className="w-full max-w-sm">
              <div className="h-2.5 w-full overflow-hidden rounded-full border-2 border-black bg-white">
                <div
                  className="h-full bg-[#0ea5e9] transition-all duration-100"
                  style={{ width: `${Math.round(progress)}%` }}
                />
              </div>
              <p className="mt-1.5 text-center font-mono text-xs font-extrabold tabular-nums text-black">
                {Math.round(progress)}%
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Done / Results Card */}
      {isDone && selectedMarket && (
        <div className="space-y-6 animate-scale-in">
          {/* Selected Market Card */}
          <div className="rounded-2xl border-2 border-black bg-[#0ea5e9] p-6 text-black shadow-hard">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="font-mono text-[10px] font-extrabold uppercase tracking-[0.2em] text-black/70">
                  Recommended Opportunity
                </span>
                <h3 className="font-display text-2xl font-extrabold uppercase tracking-tight text-black sm:text-3xl mt-0.5">
                  {selectedMarket.name}
                </h3>
                <p className="font-mono text-xs font-bold text-black/80 mt-1">
                  Symbol: <strong>{selectedMarket.symbol}</strong> · Automatically applied across all app modules
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handlePickAnother}
                  className="rounded-xl border-2 border-black bg-white px-4 py-2.5 font-display text-xs font-extrabold uppercase tracking-wide text-black hover:bg-black hover:text-white transition-all shadow-hard cursor-pointer"
                >
                  <Dices size={16} className="inline mr-1.5" /> Pick Another
                </button>
              </div>
            </div>

            <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div className="rounded-xl border-2 border-black bg-white p-3">
                <p className="font-mono text-[10px] font-extrabold uppercase tracking-wider text-[#5c636b]">
                  Deviation Score
                </p>
                <p className="mt-1 font-mono text-lg font-extrabold tabular-nums text-black">
                  {selectedMarket.score.toFixed(2)}
                </p>
              </div>

              <div className="rounded-xl border-2 border-black bg-white p-3">
                <p className="font-mono text-[10px] font-extrabold uppercase tracking-wider text-[#5c636b]">
                  Sample Ticks
                </p>
                <p className="mt-1 font-mono text-lg font-extrabold tabular-nums text-black">
                  {selectedMarket.sample}
                </p>
              </div>

              <div className="rounded-xl border-2 border-black bg-white p-3">
                <p className="font-mono text-[10px] font-extrabold uppercase tracking-wider text-[#5c636b]">
                  Tick Velocity
                </p>
                <p className="mt-1 font-mono text-lg font-extrabold tabular-nums text-black">
                  {selectedMarket.activity.toFixed(2)} t/s
                </p>
              </div>

              <div className="rounded-xl border-2 border-black bg-white p-3">
                <p className="font-mono text-[10px] font-extrabold uppercase tracking-wider text-[#5c636b]">
                  Global State
                </p>
                <p className="mt-1 flex items-center gap-1.5 text-sm font-extrabold text-[#0369a1]">
                  <StatusIndicator color="brand" pulse /> Applied
                </p>
              </div>
            </div>
          </div>

          {/* Ranking Table */}
          <div className="glass-card overflow-hidden">
            <div className="border-b-2 border-[#e6e9ed] p-4 flex items-center justify-between">
              <p className="section-title">Market Ranking Leaderboard</p>
              <span className="font-mono text-xs font-bold text-[#5c636b]">
                Click row to select market
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b-2 border-black bg-black text-left font-mono text-[10px] uppercase tracking-wider text-white">
                    <th className="p-3 font-extrabold">#</th>
                    <th className="p-3 font-extrabold">Market</th>
                    <th className="p-3 font-extrabold">Deviation Score</th>
                    <th className="p-3 font-extrabold">Sample Ticks</th>
                    <th className="p-3 font-extrabold">Activity (t/s)</th>
                  </tr>
                </thead>
                <tbody>
                  {rankings.map((m, idx) => {
                    const isCurrent = m.symbol === selectedSymbol;

                    return (
                      <tr
                        key={m.symbol}
                        onClick={() => onSelectSymbol(m.symbol)}
                        className={`cursor-pointer border-b-2 border-[#e6e9ed] transition-colors ${
                          isCurrent
                            ? "bg-[#f0f9ff] font-bold"
                            : "hover:bg-[#f4f6f8]"
                        }`}
                      >
                        <td className="p-3 font-mono font-extrabold text-[#5c636b]">
                          {idx + 1}
                        </td>
                        <td className="p-3 font-extrabold text-black">
                          <span className="flex items-center gap-2">
                            {m.name}
                            {isCurrent && (
                              <Check size={16} className="text-[#0369a1]" />
                            )}
                          </span>
                        </td>
                        <td className="p-3 font-mono tabular-nums text-[#22272e]">
                          {m.score.toFixed(2)}
                        </td>
                        <td className="p-3 font-mono tabular-nums text-[#22272e]">
                          {m.sample}
                        </td>
                        <td className="p-3 font-mono tabular-nums text-[#22272e]">
                          {m.activity.toFixed(2)} t/s
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Idle State */}
      {phase === "idle" && (
        <div className="glass-card flex flex-col items-center gap-3 p-10 text-center">
          <StatusIndicator color="gray" label="Ready to Scan" />
          <p className="max-w-md text-sm font-semibold text-[#5c636b] leading-relaxed">
            Press <strong>Scan Volatility Markets</strong> to pull recent ticks
            from all 10 indices, calculate chi-square deviation against uniform
            distributions, and auto-select the highest statistical edge.
          </p>
        </div>
      )}
    </div>
  );
};
