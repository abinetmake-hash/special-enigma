import React, { useEffect, useRef, useState } from "react";
import { Binary, Play, RefreshCw, Zap } from "lucide-react";
import { MARKETS } from "../constants";
import { Tick } from "../types";
import { useAnalysisRunner } from "../hooks/useDeriv";
import { calculateEvenOdd } from "../utils/analysis";
import { LiveDigitRibbon } from "../components/LiveDigitRibbon";
import { DigitFrequencyGauges } from "../components/DigitFrequencyGauges";
import { DigitChart } from "../components/DigitChart";
import {
  AnalysisControls,
  MarketSelector,
  ModuleHeader,
} from "../components/MarketControls";
import { ProbabilityCards } from "../components/ProbabilityCards";
import { OutcomeBreakdown } from "../components/OutcomeBreakdown";
import { AnalysisRunnerOverlay } from "../components/AnalysisRunnerOverlay";

interface EvenOddViewProps {
  ticks: Tick[];
  selectedSymbol: string;
  onSelectSymbol: (symbol: string) => void;
  feedStatus: "connecting" | "open" | "closed" | "error";
}

export const EvenOddView: React.FC<EvenOddViewProps> = ({
  ticks,
  selectedSymbol,
  onSelectSymbol,
  feedStatus,
}) => {
  const activeMarket =
    MARKETS.find((m) => m.symbol === selectedSymbol) ?? MARKETS[0];

  const [sampleSize, setSampleSize] = useState(120);
  const [mode, setMode] = useState("STANDARD");

  const runner = useAnalysisRunner();
  const DURATION_SEC = 4;
  const isFirstMount = useRef(true);

  useEffect(() => {
    if (isFirstMount.current) {
      isFirstMount.current = false;
      return;
    }
    runner.reset();
  }, [selectedSymbol]);

  const handleRun = () => {
    runner.run({
      symbol: selectedSymbol,
      mode,
      sampleSize,
      durationSec: DURATION_SEC,
      compute: (sampleTicks) => calculateEvenOdd(sampleTicks),
    });
  };

  const result = runner.result;
  const isRunning = runner.phase === "running";
  const isDone = runner.phase === "done" && result != null;
  const isEven = result?.indication === "EVEN";

  return (
    <div className="space-y-6">
      <ModuleHeader
        icon={<Binary size={22} />}
        title="Even / Odd Analysis"
        subtitle="Measure the even-versus-odd distribution in recent ticks and calculate probability for the next digit."
      />

      {/* Market Selector */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <MarketSelector
            value={selectedSymbol}
            onChange={onSelectSymbol}
            disabled={runner.locked}
          />
        </div>
        <div className="flex items-end">
          <div className="glass-card flex w-full items-center justify-between p-4">
            <span className="section-title">Active Market</span>
            <span className="font-display font-extrabold text-black">
              {activeMarket.name}
            </span>
          </div>
        </div>
      </div>

      {/* Live Digit Ribbon */}
      <LiveDigitRibbon
        ticks={ticks}
        symbol={selectedSymbol}
        marketName={activeMarket.name}
        status={feedStatus}
        span={24}
      />

      {/* Digit Frequency Gauges */}
      <DigitFrequencyGauges ticks={ticks} />

      {/* Digit Distribution Chart */}
      <DigitChart ticks={ticks} tickCount={sampleSize} />

      {/* Engine Controls */}
      <AnalysisControls
        tickCount={sampleSize}
        setTickCount={setSampleSize}
        mode={mode}
        setMode={setMode}
        marketName={activeMarket.name}
        duration={DURATION_SEC}
        locked={runner.locked}
      />

      {/* Action Decision Area */}
      <div className="glass-card p-5 sm:p-7">
        <div className="flex flex-col items-center gap-6">
          <div className="text-center">
            <span className="section-title text-[#5c636b]">Parity Engine</span>
            <p className="mt-1 font-display text-sm font-extrabold uppercase text-black">
              Calculate Statistical Even vs Odd Edge
            </p>
          </div>

          {!isRunning && !isDone && (
            <button
              type="button"
              onClick={handleRun}
              disabled={feedStatus !== "open" || runner.locked}
              className="btn-primary w-full max-w-sm py-4 text-base"
            >
              <Zap size={18} /> Run Even / Odd Analysis
            </button>
          )}

          {/* Running State */}
          {isRunning && (
            <div className="w-full max-w-md">
              <AnalysisRunnerOverlay
                progress={runner.progress}
                message={`Evaluating even/odd digit parity on ${activeMarket.name}...`}
              />
            </div>
          )}

          {/* Done State */}
          {isDone && (
            <div className="flex w-full flex-col items-center gap-5 border-t-2 border-[#e6e9ed] pt-6 animate-scale-in">
              <div className="flex items-center gap-3">
                <span
                  className={`grid h-14 w-14 place-items-center rounded-2xl border-2 border-black font-display text-2xl font-extrabold uppercase text-white shadow-hard animate-slam ${
                    isEven ? "bg-[#0ea5e9] text-black" : "bg-[#0c4a6e] text-white"
                  }`}
                >
                  {isEven ? "E" : "O"}
                </span>
                <span className="font-display text-4xl font-extrabold uppercase tracking-tight text-black sm:text-5xl">
                  {result.indication}
                </span>
              </div>

              {/* Probability Cards */}
              <ProbabilityCards
                winProbability={result.winProbability}
                confidence={result.confidence}
                sampleSize={result.sampleSize}
              />

              {/* Outcome Breakdown */}
              <div className="w-full max-w-md">
                <OutcomeBreakdown
                  outcomes={result.outcomes}
                  highlight={result.indication}
                />
              </div>

              {/* Explanation Note */}
              <p className="max-w-md text-center text-xs font-semibold leading-relaxed text-[#5c636b]">
                {result.explanation}
              </p>

              <button
                type="button"
                onClick={() => runner.reset()}
                className="btn-ghost w-full max-w-sm border-2 border-black"
              >
                <RefreshCw size={15} /> Reset / Run Another
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
