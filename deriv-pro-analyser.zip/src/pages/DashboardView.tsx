import React from "react";
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  ArrowUpDown,
  BarChart3,
  Binary,
  Bot,
  ExternalLink,
  Layers,
  Radio,
  Radar,
  RefreshCw,
  Sparkles,
  Target,
  Zap,
} from "lucide-react";
import { Market, PageId, Tick } from "../types";
import { MARKETS, RNGTRADER_URL } from "../constants";
import { AutomatedPipelineBanner } from "../components/AutomatedPipelineBanner";
import { LiveDigitRibbon } from "../components/LiveDigitRibbon";
import { DigitFrequencyGauges } from "../components/DigitFrequencyGauges";
import { MarketSelector } from "../components/MarketControls";
import { StatusIndicator } from "../components/StatusIndicator";

interface DashboardViewProps {
  status: "connecting" | "open" | "closed" | "error";
  error: string | null;
  source: string | null;
  ticks: Tick[];
  selectedSymbol: string;
  onSelectSymbol: (symbol: string) => void;
  onNavigate: (page: PageId) => void;
  onReconnect: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  status,
  error,
  source,
  ticks,
  selectedSymbol,
  onSelectSymbol,
  onNavigate,
  onReconnect,
}) => {
  const isOnline = status === "open";
  const activeMarket =
    MARKETS.find((m) => m.symbol === selectedSymbol) ?? MARKETS[0];

  const analysisModules = [
    {
      key: "matches" as PageId,
      title: "Matches / Differs",
      desc: "Identify peak digit frequency and calculate repeat probabilities",
      icon: Target,
      tag: "Most Popular",
    },
    {
      key: "evenodd" as PageId,
      title: "Even / Odd",
      desc: "Measure parity skew and calculated Bayesian next-tick odds",
      icon: Binary,
      tag: "Parity Engine",
    },
    {
      key: "overunder" as PageId,
      title: "Over / Under",
      desc: "Select barrier digit 0–9 and measure baseline split deviations",
      icon: ArrowUpDown,
      tag: "Barrier Analysis",
    },
    {
      key: "scanner" as PageId,
      title: "Volatility Scanner",
      desc: "Simultaneously scan all 10 indices and rank by chi-square deviation",
      icon: Radar,
      tag: "Auto Market Selection",
    },
    {
      key: "frequency" as PageId,
      title: "Frequency Graph",
      desc: "Detailed bar charts, 10% expected uniform line and live histograms",
      icon: BarChart3,
      tag: "Live Histograms",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex items-start gap-3">
        <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border-2 border-black bg-[#0ea5e9] text-black shadow-hard">
          <Activity size={22} />
        </div>
        <div>
          <h2 className="font-display text-xl font-extrabold uppercase tracking-tight text-black sm:text-2xl">
            Dashboard
          </h2>
          <p className="text-xs font-semibold text-[#5c636b] sm:text-sm">
            Live Deriv tick streaming and mathematical analysis pipeline
          </p>
        </div>
      </div>

      {/* Connection Warning Banner if offline */}
      {!isOnline && (
        <div className="flex flex-col items-start gap-3 rounded-2xl border-2 border-rose-500 bg-rose-50 p-4 sm:flex-row sm:items-center sm:justify-between shadow-hard">
          <div className="flex items-start gap-3">
            <span className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-lg border-2 border-rose-500 bg-white text-rose-600">
              <AlertTriangle size={18} />
            </span>
            <div>
              <p className="font-display text-sm font-extrabold uppercase tracking-wide text-rose-700">
                Deriv Tick Stream {status === "connecting" ? "Connecting…" : "Disconnected"}
                {source ? ` · ${source}` : ""}
              </p>
              <p className="mt-0.5 text-xs font-bold text-rose-600">
                {error ?? "Establishing live WebSocket connection to Deriv nodes..."}
              </p>
            </div>
          </div>
          <button
            onClick={onReconnect}
            className="shrink-0 rounded-xl border-2 border-rose-600 bg-white px-4 py-2 font-mono text-xs font-extrabold uppercase tracking-wide text-rose-700 transition-colors hover:bg-rose-600 hover:text-white cursor-pointer"
          >
            Reconnect Feed
          </button>
        </div>
      )}

      {/* System Metrics Triad */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        {/* System Feed */}
        <div className="glass-card flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <Radio size={20} className="text-[#0ea5e9]" />
            <div>
              <span className="section-title">Feed Status</span>
              {source && (
                <p className="font-mono text-[10px] font-bold uppercase tracking-wide text-[#5c636b]">
                  {source}
                </p>
              )}
            </div>
          </div>
          <StatusIndicator
            color={isOnline ? "brand" : "rose"}
            pulse={isOnline}
            label={isOnline ? "Online" : "Offline"}
          />
        </div>

        {/* Active Market */}
        <div className="glass-card flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <Layers size={20} className="text-[#0c4a6e]" />
            <div>
              <span className="section-title">Active Market</span>
              <p className="font-mono text-[10px] font-bold uppercase tracking-wide text-[#5c636b]">
                {activeMarket.symbol}
              </p>
            </div>
          </div>
          <span className="font-display font-extrabold text-sm text-black">
            {activeMarket.name.replace("Volatility ", "V")}
          </span>
        </div>

        {/* Buffered Ticks */}
        <div className="glass-card flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <BarChart3 size={20} className="text-[#0369a1]" />
            <div>
              <span className="section-title">Tick Buffer</span>
              <p className="font-mono text-[10px] font-bold uppercase tracking-wide text-[#5c636b]">
                In-Memory Cache
              </p>
            </div>
          </div>
          <span className="font-mono text-sm font-extrabold tabular-nums text-black">
            {ticks.length} ticks
          </span>
        </div>
      </div>

      {/* Automated Pipeline Banner */}
      <AutomatedPipelineBanner />

      {/* Market Selector & Live Tape */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <MarketSelector
            value={selectedSymbol}
            onChange={onSelectSymbol}
            label="Active Market Instrument"
          />
        </div>
        <div className="flex items-end">
          <div className="glass-card flex w-full items-center justify-between p-4">
            <span className="section-title">Subscribed Instrument</span>
            <span className="font-display font-extrabold text-sm text-black">
              {activeMarket.name}
            </span>
          </div>
        </div>
      </div>

      {/* Live Digit Ribbon */}
      <LiveDigitRibbon
        ticks={ticks}
        symbol={selectedSymbol}
        marketName={activeMarket.name}
        status={status}
        span={20}
      />

      {/* Digit Frequency Gauges */}
      <DigitFrequencyGauges ticks={ticks} recentWindow={25} />

      {/* Analysis Modules Grid */}
      <div>
        <div className="mb-3 flex items-center justify-between">
          <h3 className="section-title text-black">Analysis Modules</h3>
          <span className="font-mono text-xs font-bold text-[#5c636b]">
            Select module to execute
          </span>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {analysisModules.map((mod) => {
            const Icon = mod.icon;
            return (
              <div
                key={mod.key}
                onClick={() => onNavigate(mod.key)}
                className="glass-card p-5 transition-transform hover:-translate-y-1 cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="grid h-11 w-11 place-items-center rounded-xl border-2 border-black bg-[#0ea5e9] text-black shadow-hard">
                      <Icon size={20} />
                    </span>
                    <span className="rounded-md border border-black bg-[#f0f9ff] px-2 py-0.5 font-mono text-[10px] font-extrabold text-[#0369a1] uppercase">
                      {mod.tag}
                    </span>
                  </div>

                  <h4 className="mt-4 font-display font-extrabold uppercase tracking-wide text-black text-base">
                    {mod.title}
                  </h4>
                  <p className="mt-1.5 text-xs font-medium text-[#5c636b] leading-relaxed">
                    {mod.desc}
                  </p>
                </div>

                <div className="mt-5 flex items-center justify-between border-t border-[#e6e9ed] pt-3 font-mono text-xs font-extrabold text-black">
                  <span>Open Module</span>
                  <ArrowRight size={14} className="text-[#0ea5e9]" />
                </div>
              </div>
            );
          })}

          {/* RNGTrader Card in Modules Grid */}
          <div className="glass-card p-5 bg-[#f0f9ff] border-2 border-black flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <span className="grid h-11 w-11 place-items-center rounded-xl border-2 border-black bg-black text-white shadow-hard">
                  <Bot size={20} />
                </span>
                <span className="rounded-md border border-black bg-white px-2 py-0.5 font-mono text-[10px] font-extrabold text-black uppercase">
                  Automated Trading
                </span>
              </div>

              <h4 className="mt-4 font-display font-extrabold uppercase tracking-wide text-black text-base">
                RNGTrader Platform
              </h4>
              <p className="mt-1.5 text-xs font-medium text-[#5c636b] leading-relaxed">
                Connect your Deriv account to automated trading bots with free strategies.
              </p>
            </div>

            <div className="mt-5 pt-3 border-t border-[#bae6fd]">
              <a
                href={RNGTRADER_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary w-full py-2.5 text-xs font-extrabold"
              >
                <ExternalLink size={14} /> Launch RNGTrader
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
