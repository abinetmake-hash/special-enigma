import React, { useMemo } from "react";
import { BarChart3 } from "lucide-react";
import { MARKETS } from "../constants";
import { Tick } from "../types";
import { calculateDistribution } from "../utils/analysis";
import { LiveDigitRibbon } from "../components/LiveDigitRibbon";
import { DigitFrequencyGauges } from "../components/DigitFrequencyGauges";
import { DigitChart } from "../components/DigitChart";
import { MarketSelector, ModuleHeader } from "../components/MarketControls";

interface FrequencyViewProps {
  ticks: Tick[];
  selectedSymbol: string;
  onSelectSymbol: (symbol: string) => void;
  feedStatus: "connecting" | "open" | "closed" | "error";
}

export const FrequencyView: React.FC<FrequencyViewProps> = ({
  ticks,
  selectedSymbol,
  onSelectSymbol,
  feedStatus,
}) => {
  const activeMarket =
    MARKETS.find((m) => m.symbol === selectedSymbol) ?? MARKETS[0];

  const distribution = useMemo(
    () => calculateDistribution(ticks, 25),
    [ticks]
  );

  return (
    <div className="space-y-6">
      <ModuleHeader
        icon={<BarChart3 size={22} />}
        title="Frequency Graph"
        subtitle="Digit percentages and distribution statistics for the active market, updating live on every incoming tick."
      />

      {/* Market Selector */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <MarketSelector
            value={selectedSymbol}
            onChange={onSelectSymbol}
          />
        </div>
        <div className="flex items-end">
          <div className="glass-card flex w-full items-center justify-between p-4">
            <span className="section-title">Active Market</span>
            <span className="font-display font-extrabold text-black">
              {activeMarket.name}
            </span>
          </div>
        </div>
      </div>

      {/* Live Digit Ribbon */}
      <LiveDigitRibbon
        ticks={ticks}
        symbol={selectedSymbol}
        marketName={activeMarket.name}
        status={feedStatus}
        span={24}
      />

      {/* Digit Distribution Bar Chart */}
      <DigitChart ticks={ticks} />

      {/* Digit Frequency Circular Gauges */}
      <DigitFrequencyGauges ticks={ticks} recentWindow={25} />

      {/* Numerical Data Table */}
      <div className="glass-card overflow-hidden">
        <div className="border-b-2 border-[#e6e9ed] p-4 flex items-center justify-between">
          <p className="section-title">Digit Statistics Table</p>
          <span className="font-mono text-xs font-bold text-[#5c636b]">
            Sample: {ticks.length} ticks
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b-2 border-black bg-black text-left font-mono text-[10px] uppercase tracking-wider text-white">
                <th className="p-3 font-extrabold">Digit</th>
                <th className="p-3 font-extrabold">Total Count</th>
                <th className="p-3 font-extrabold">Appearance Rate</th>
                <th className="p-3 font-extrabold">Last 25 Window</th>
                <th className="p-3 font-extrabold">Deviation Status</th>
              </tr>
            </thead>
            <tbody>
              {distribution.map((item) => {
                const statusColor =
                  item.status === "high"
                    ? "bg-[#0ea5e9] text-black"
                    : item.status === "low"
                    ? "bg-[#e6e9ed] text-[#5c636b]"
                    : "bg-white text-black";

                return (
                  <tr
                    key={item.digit}
                    className="border-b-2 border-[#e6e9ed] hover:bg-[#f4f6f8] transition-colors"
                  >
                    <td className="p-3">
                      <span className="grid h-8 w-8 place-items-center rounded-lg border-2 border-black bg-white font-mono font-extrabold text-black shadow-xs">
                        {item.digit}
                      </span>
                    </td>
                    <td className="p-3 font-mono tabular-nums text-black font-bold">
                      {item.count}
                    </td>
                    <td className="p-3 font-mono tabular-nums text-black font-extrabold">
                      {item.percentage.toFixed(1)}%
                    </td>
                    <td className="p-3 font-mono tabular-nums text-[#5c636b]">
                      {item.recentCount} ({item.recentPercentage.toFixed(1)}%)
                    </td>
                    <td className="p-3">
                      <span
                        className={`inline-block rounded-md border border-black px-2 py-0.5 font-mono text-[10px] font-extrabold uppercase ${statusColor}`}
                      >
                        {item.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
