import React, { useEffect, useRef, useState } from "react";
import { Lock, RefreshCw, Target } from "lucide-react";
import { MARKETS, PREDICTION_DIGITS } from "../constants";
import { Tick } from "../types";
import { useAnalysisRunner } from "../hooks/useDeriv";
import { calculateMatchesDiffers } from "../utils/analysis";
import { LiveDigitRibbon } from "../components/LiveDigitRibbon";
import { DigitFrequencyGauges } from "../components/DigitFrequencyGauges";
import {
  AnalysisControls,
  MarketSelector,
  ModuleHeader,
} from "../components/MarketControls";
import { ProbabilityCards } from "../components/ProbabilityCards";
import { OutcomeBreakdown } from "../components/OutcomeBreakdown";
import { AnalysisRunnerOverlay } from "../components/AnalysisRunnerOverlay";

interface MatchesDiffersViewProps {
  ticks: Tick[];
  selectedSymbol: string;
  onSelectSymbol: (symbol: string) => void;
  feedStatus: "connecting" | "open" | "closed" | "error";
}

export const MatchesDiffersView: React.FC<MatchesDiffersViewProps> = ({
  ticks,
  selectedSymbol,
  onSelectSymbol,
  feedStatus,
}) => {
  const activeMarket =
    MARKETS.find((m) => m.symbol === selectedSymbol) ?? MARKETS[0];

  const [sampleSize, setSampleSize] = useState(120);
  const [mode, setMode] = useState("STANDARD");
  const [selectedAction, setSelectedAction] = useState<"MATCH" | "DIFFER" | null>(
    null
  );

  const runner = useAnalysisRunner();
  const DURATION_SEC = 4;
  const isFirstMount = useRef(true);

  useEffect(() => {
    if (isFirstMount.current) {
      isFirstMount.current = false;
      return;
    }
    runner.reset();
    setSelectedAction(null);
  }, [selectedSymbol]);

  const handleRun = (action: "MATCH" | "DIFFER") => {
    setSelectedAction(action);
    runner.run({
      symbol: selectedSymbol,
      mode,
      sampleSize,
      durationSec: DURATION_SEC,
      compute: (sampleTicks, m) =>
        calculateMatchesDiffers(sampleTicks, m, PREDICTION_DIGITS),
    });
  };

  const result = runner.result;
  const isRunning = runner.phase === "running";
  const isDone = runner.phase === "done" && result != null;
  const isActionDisabled = feedStatus !== "open" || runner.locked;

  const getButtonClass = (btnAction: "MATCH" | "DIFFER") => {
    const base =
      "flex-1 shrink-0 rounded-2xl border-2 border-black py-6 font-display text-sm font-extrabold uppercase tracking-wide shadow-hard transition-all sm:py-8 sm:text-lg min-w-[120px] active:translate-x-1 active:translate-y-1 active:shadow-none disabled:opacity-40 disabled:shadow-none cursor-pointer";
    if (isDone && selectedAction === btnAction) {
      return `${base} bg-black text-white`;
    }
    if (btnAction === "MATCH") {
      return `${base} bg-[#0ea5e9] text-black hover:bg-[#38bdf8]`;
    }
    return `${base} bg-white text-black hover:bg-[#0c4a6e] hover:text-white`;
  };

  return (
    <div className="space-y-6">
      <ModuleHeader
        icon={<Target size={22} />}
        title="Matches / Differs"
        subtitle="Detect the most frequent digit in recent ticks and calculate repeat vs differing probabilities."
      />

      {/* Market Selector */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <MarketSelector
            value={selectedSymbol}
            onChange={onSelectSymbol}
            disabled={runner.locked}
          />
        </div>
        <div className="flex items-end">
          <div className="glass-card flex w-full items-center justify-between p-4">
            <span className="section-title">Active Market</span>
            <span className="font-display font-extrabold text-black">
              {activeMarket.name}
            </span>
          </div>
        </div>
      </div>

      {/* Live Digit Ribbon */}
      <LiveDigitRibbon
        ticks={ticks}
        symbol={selectedSymbol}
        marketName={activeMarket.name}
        status={feedStatus}
        span={24}
      />

      {/* Digit Frequency Gauges */}
      <DigitFrequencyGauges ticks={ticks} />

      {/* Engine Controls */}
      <AnalysisControls
        tickCount={sampleSize}
        setTickCount={setSampleSize}
        mode={mode}
        setMode={setMode}
        marketName={activeMarket.name}
        duration={DURATION_SEC}
        locked={runner.locked}
      />

      {/* Action Decision Area */}
      <div className="glass-card p-5 sm:p-7">
        <div className="flex flex-col items-center gap-6">
          <div className="text-center">
            <span className="section-title text-[#5c636b]">Contract Selection</span>
            <p className="mt-1 font-display text-sm font-extrabold uppercase text-black">
              Select Contract Type to Run Analysis
            </p>
          </div>

          {/* Match & Differ Action Buttons */}
          <div className="flex w-full max-w-md gap-4 justify-center">
            <button
              type="button"
              onClick={() => handleRun("MATCH")}
              disabled={isActionDisabled}
              className={getButtonClass("MATCH")}
            >
              Match
            </button>
            <button
              type="button"
              onClick={() => handleRun("DIFFER")}
              disabled={isActionDisabled}
              className={getButtonClass("DIFFER")}
            >
              Differ
            </button>
          </div>

          {/* Prediction range pills */}
          <div className="flex flex-wrap items-center justify-center gap-1.5">
            <span className="font-mono text-[10px] font-extrabold uppercase tracking-widest text-[#5c636b]">
              Prediction range
            </span>
            {PREDICTION_DIGITS.map((digit) => (
              <span
                key={digit}
                className={`grid h-7 w-7 place-items-center rounded-md border-2 border-black font-mono text-xs font-extrabold transition-colors ${
                  isDone && result.predictedDigit === digit
                    ? "bg-black text-white shadow-hard"
                    : "bg-white text-black"
                }`}
              >
                {digit}
              </span>
            ))}
          </div>

          {/* Running State */}
          {isRunning && (
            <div className="w-full max-w-md">
              <AnalysisRunnerOverlay
                progress={runner.progress}
                message={`Calculating Matches/Differs probabilities for ${activeMarket.name}...`}
              />
            </div>
          )}

          {/* Done State */}
          {isDone && (
            <div className="flex w-full flex-col items-center gap-5 border-t-2 border-[#e6e9ed] pt-6 animate-scale-in">
              <div className="flex flex-wrap items-center justify-center gap-2">
                <span className="chip border-black bg-black text-white">
                  <Lock size={12} /> Digit locked: {result.predictedDigit}
                </span>
                <span className="chip border-black bg-white text-black">
                  {DURATION_SEC}s sample duration
                </span>
              </div>

              {/* Indication Banner */}
              <div className="flex items-center gap-3">
                <span
                  className={`grid h-12 w-12 place-items-center rounded-xl border-2 border-black font-display text-2xl font-extrabold uppercase text-white shadow-hard animate-slam ${
                    result.indication === "MATCH"
                      ? "bg-[#0ea5e9] text-black"
                      : "bg-[#0c4a6e] text-white"
                  }`}
                >
                  {result.indication === "MATCH" ? "=" : "≠"}
                </span>
                <span className="font-display text-4xl font-extrabold uppercase tracking-tight text-black sm:text-5xl">
                  {result.indication} {result.predictedDigit}
                </span>
              </div>

              {/* Probability Cards */}
              <ProbabilityCards
                winProbability={result.winProbability}
                confidence={result.confidence}
                sampleSize={result.sampleSize}
                predictedDigitPercentage={result.predictedDigitPercentage}
              />

              {/* Outcome Breakdown */}
              <div className="w-full max-w-md">
                <OutcomeBreakdown
                  outcomes={result.outcomes}
                  highlight={`${result.indication} ${result.predictedDigit}`}
                />
              </div>

              {/* Explanation Note */}
              <p className="max-w-md text-center text-xs font-semibold leading-relaxed text-[#5c636b]">
                {result.explanation}
              </p>

              <button
                type="button"
                onClick={() => runner.reset()}
                className="btn-ghost w-full max-w-sm border-2 border-black"
              >
                <RefreshCw size={15} /> Reset / Run Another
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
