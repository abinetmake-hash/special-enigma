import {
  FeedSnapshot,
  MarketBook,
  Tick,
  WebSocketEndpoint,
} from "../types";
import { extractLastDigit } from "../utils/analysis";

const ENDPOINT_STORAGE_KEY = "dpa.feed.endpoint";
const BUFFER_CAP = 600;
const HANDSHAKE_TIMEOUT_MS = 7000;
const REQUEST_TIMEOUT_MS = 12000;
const HEARTBEAT_INTERVAL_MS = 20000;
const WATCHDOG_MAX_SILENCE_MS = 35000;
const STREAM_STALL_MS = 20000;

export const DEFAULT_ENDPOINTS: WebSocketEndpoint[] = [
  {
    id: "options-public",
    label: "Deriv API (public)",
    url: "wss://api.derivws.com/trading/v1/options/ws/public",
  },
  {
    id: "legacy-derivws",
    label: "Deriv v3 (legacy)",
    url: "wss://ws.derivws.com/websockets/v3?app_id=1089",
  },
  {
    id: "legacy-binaryws",
    label: "Binary v3 (legacy)",
    url: "wss://ws.binaryws.com/websockets/v3?app_id=1089",
  },
];

interface PendingRequest {
  payload: Record<string, unknown>;
  sent: boolean;
  timer: NodeJS.Timeout | number;
  resolve: (res: any) => void;
  reject: (err: Error) => void;
}

interface StreamState {
  refs: number;
  reqId: number | null;
  subId: string | null;
  releaseTimer: NodeJS.Timeout | number | null;
}

export class DerivFeedClient {
  private endpoints: WebSocketEndpoint[];
  private epIndex = 0;
  private ws: WebSocket | null = null;
  private healthy = false;
  private failStreak = 0;
  private reqSeq = 1;

  private pending = new Map<number, PendingRequest>();
  private streams = new Map<string, StreamState>();
  private streamByReq = new Map<number, string>();
  private books = new Map<string, MarketBook>();
  private listeners = new Set<() => void>();

  private snapshot: FeedSnapshot = {
    status: "connecting",
    error: null,
    endpoint: null,
    lastMessageAt: Date.now(),
    version: 0,
  };

  private reconnectTimer: NodeJS.Timeout | number | null = null;
  private heartbeatTimer: NodeJS.Timeout | number | null = null;
  private watchdogTimer: NodeJS.Timeout | number | null = null;
  private started = false;
  private handshakeId: number | null = null;

  constructor(endpoints: WebSocketEndpoint[] = DEFAULT_ENDPOINTS) {
    this.endpoints = endpoints;
    try {
      const saved = localStorage.getItem(ENDPOINT_STORAGE_KEY);
      const idx = endpoints.findIndex((e) => e.id === saved);
      if (idx >= 0) this.epIndex = idx;
    } catch {
      // ignore
    }
  }

  public subscribe = (listener: () => void): (() => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };

  public getSnapshot = (): FeedSnapshot => this.snapshot;

  public start(): void {
    if (this.started) return;
    this.started = true;
    this.connect();
    this.watchdogTimer = setInterval(() => this.watchdog(), 5000);

    if (typeof window !== "undefined") {
      window.addEventListener("online", this.kick);
      document.addEventListener("visibilitychange", this.onVisibility);
    }
  }

  public getBook(symbol: string): MarketBook {
    let book = this.books.get(symbol);
    if (!book) {
      book = {
        symbol,
        ticks: [],
        state: "loading",
        error: null,
        lastTickAt: 0,
      };
      this.books.set(symbol, book);
    }
    return book;
  }

  public watch(symbol: string): () => void {
    this.start();
    let stream = this.streams.get(symbol);
    if (!stream) {
      stream = { refs: 0, reqId: null, subId: null, releaseTimer: null };
      this.streams.set(symbol, stream);
    }
    stream.refs++;
    if (stream.releaseTimer) {
      clearTimeout(stream.releaseTimer);
      stream.releaseTimer = null;
    }
    if (stream.reqId == null && stream.subId == null) {
      this.openStream(symbol);
    }

    let released = false;
    return () => {
      if (!released) {
        released = true;
        this.release(symbol);
      }
    };
  }

  public async history(symbol: string, count: number): Promise<Tick[]> {
    const targetCount = Math.min(Math.max(Math.round(count), 10), 5000);
    const book = this.books.get(symbol);
    if (book && book.state === "live" && book.ticks.length >= targetCount) {
      return book.ticks.slice(-targetCount);
    }
    this.start();
    try {
      const response = await this.request({
        ticks_history: symbol,
        count: targetCount,
        end: "latest",
        style: "ticks",
      });
      return this.parseHistory(symbol, response);
    } catch {
      // If history request fails or times out, fallback to current available ticks or synthetic ticks
      return book ? book.ticks.slice(-targetCount) : [];
    }
  }

  public reconnect(): void {
    this.failStreak = 0;
    this.epIndex = 0;
    this.dropSocket();
    this.connect();
  }

  private kick = (): void => {
    if (!this.healthy) {
      this.failStreak = 0;
      this.dropSocket();
      this.connect();
    }
  };

  private onVisibility = (): void => {
    if (document.visibilityState === "visible") {
      this.kick();
    }
  };

  private connect(): void {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.ws && this.ws.readyState <= WebSocket.OPEN) return;

    const endpoint = this.endpoints[this.epIndex];
    this.healthy = false;
    this.update({
      status: this.failStreak >= this.endpoints.length ? "error" : "connecting",
      endpoint,
    });

    let socket: WebSocket;
    try {
      socket = new WebSocket(endpoint.url);
    } catch (err) {
      this.onConnectFailure(`Could not open WebSocket to ${endpoint.label}.`);
      return;
    }

    this.ws = socket;
    const handshakeTimer = setTimeout(() => {
      if (this.ws === socket && !this.healthy) {
        this.dropSocket();
        this.onConnectFailure(`${endpoint.label} did not respond.`);
      }
    }, HANDSHAKE_TIMEOUT_MS);

    socket.onopen = () => {
      const reqId = this.reqSeq++;
      this.handshakeId = reqId;
      this.pending.set(reqId, {
        payload: { ping: 1 },
        sent: true,
        timer: handshakeTimer,
        resolve: () => {
          clearTimeout(handshakeTimer);
          if (this.ws === socket) this.onHealthy(endpoint);
        },
        reject: () => {},
      });
      socket.send(JSON.stringify({ ping: 1, req_id: reqId }));
    };

    socket.onmessage = (event) => this.onMessage(event.data);

    socket.onerror = () => {
      if (this.ws === socket) {
        if (this.healthy) {
          setTimeout(() => {
            if (this.ws === socket) {
              this.dropSocket();
              this.update({
                status: "closed",
                error: "Connection dropped — reconnecting…",
              });
              this.scheduleReconnect(600);
            }
          }, 1500);
        } else {
          clearTimeout(handshakeTimer);
          this.dropSocket();
          this.onConnectFailure(`${endpoint.label} is unreachable.`);
        }
      }
    };

    socket.onclose = (event) => {
      clearTimeout(handshakeTimer);
      if (this.ws !== socket) return;
      this.ws = null;
      const wasHealthy = this.healthy;
      this.healthy = false;
      this.stopHeartbeat();
      this.requeueInFlight();
      this.resetStreamsForReconnect();

      if (wasHealthy) {
        this.update({
          status: "closed",
          error: "Connection dropped — reconnecting…",
        });
        this.scheduleReconnect(600);
      } else {
        this.onConnectFailure(
          `${endpoint.label} refused the connection (code ${event.code}).`
        );
      }
    };
  }

  private onHealthy(endpoint: WebSocketEndpoint): void {
    this.healthy = true;
    this.failStreak = 0;
    try {
      localStorage.setItem(ENDPOINT_STORAGE_KEY, endpoint.id);
    } catch {}

    this.update({
      status: "open",
      error: null,
      lastMessageAt: Date.now(),
    });
    this.startHeartbeat();
    this.flushQueue();

    for (const [symbol, stream] of this.streams) {
      if (stream.refs > 0 || stream.releaseTimer) {
        this.openStream(symbol);
      }
    }
  }

  private onConnectFailure(msg: string): void {
    this.failStreak++;
    this.epIndex = (this.epIndex + 1) % this.endpoints.length;
    const allFailed = this.failStreak >= this.endpoints.length;
    const delay = allFailed ? Math.min(1000 * 2 ** (this.failStreak - this.endpoints.length), 20000) : 350;

    this.update({
      status: allFailed ? "error" : "connecting",
      error: allFailed
        ? `${msg} All market-data endpoints are unreachable — retrying.`
        : msg,
    });
    this.scheduleReconnect(delay);
  }

  private scheduleReconnect(delayMs: number): void {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = setTimeout(() => this.connect(), delayMs);
  }

  private dropSocket(): void {
    const s = this.ws;
    this.ws = null;
    this.healthy = false;
    this.handshakeId = null;
    this.stopHeartbeat();
    this.requeueInFlight();
    this.resetStreamsForReconnect();

    if (s) {
      s.onopen = s.onmessage = s.onerror = s.onclose = null;
      try {
        s.close();
      } catch {}
    }
  }

  private startHeartbeat(): void {
    this.stopHeartbeat();
    this.heartbeatTimer = setInterval(() => {
      this.request({ ping: 1 }, 10000).catch(() => {
        this.dropSocket();
        this.connect();
      });
    }, HEARTBEAT_INTERVAL_MS);
  }

  private stopHeartbeat(): void {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
  }

  private watchdog(): void {
    if (!this.healthy) return;
    const now = Date.now();
    if (now - this.snapshot.lastMessageAt > WATCHDOG_MAX_SILENCE_MS) {
      this.dropSocket();
      this.connect();
      return;
    }
    for (const [symbol, stream] of this.streams) {
      const book = this.books.get(symbol);
      if (
        stream.subId &&
        book &&
        book.state === "live" &&
        now - book.lastTickAt > STREAM_STALL_MS
      ) {
        this.closeStream(symbol);
        this.openStream(symbol);
      }
    }
  }

  private request(payload: Record<string, unknown>, timeoutMs = REQUEST_TIMEOUT_MS): Promise<any> {
    return new Promise((resolve, reject) => {
      const reqId = this.reqSeq++;
      const timer = setTimeout(() => {
        this.pending.delete(reqId);
        reject(new Error("Deriv did not answer in time."));
      }, timeoutMs);

      const req: PendingRequest = {
        payload,
        resolve,
        reject,
        timer,
        sent: false,
      };

      this.pending.set(reqId, req);
      if (this.healthy) {
        this.sendPending(reqId, req);
      }
    });
  }

  private sendPending(reqId: number, req: PendingRequest): void {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    try {
      this.ws.send(JSON.stringify({ ...req.payload, req_id: reqId }));
      req.sent = true;
    } catch {}
  }

  private flushQueue(): void {
    for (const [reqId, req] of this.pending) {
      if (!req.sent) this.sendPending(reqId, req);
    }
  }

  private requeueInFlight(): void {
    for (const [reqId, req] of this.pending) {
      if (req.payload.ping) {
        clearTimeout(req.timer);
        this.pending.delete(reqId);
        req.reject(new Error("Connection closed."));
      } else {
        req.sent = false;
      }
    }
  }

  private openStream(symbol: string): void {
    const stream = this.streams.get(symbol);
    if (!stream || !this.healthy || !this.ws) return;

    const reqId = this.reqSeq++;
    stream.reqId = reqId;
    stream.subId = null;
    this.streamByReq.set(reqId, symbol);

    const existing = this.books.get(symbol);
    if (existing) {
      if (existing.state === "error") {
        this.setBook(symbol, { ...existing, state: "loading", error: null });
      }
    } else {
      this.setBook(symbol, { ...this.getBook(symbol) });
    }

    try {
      this.ws.send(
        JSON.stringify({
          ticks_history: symbol,
          count: 500,
          end: "latest",
          style: "ticks",
          subscribe: 1,
          req_id: reqId,
        })
      );
    } catch {
      this.streamByReq.delete(reqId);
      stream.reqId = null;
    }
  }

  private closeStream(symbol: string): void {
    const stream = this.streams.get(symbol);
    if (!stream) return;
    if (stream.subId && this.ws && this.ws.readyState === WebSocket.OPEN) {
      try {
        this.ws.send(JSON.stringify({ forget: stream.subId }));
      } catch {}
    }
    stream.subId = null;
    stream.reqId = null;
  }

  private release(symbol: string): void {
    const stream = this.streams.get(symbol);
    if (!stream) return;
    stream.refs = Math.max(0, stream.refs - 1);
    if (stream.refs === 0 && !stream.releaseTimer) {
      stream.releaseTimer = setTimeout(() => {
        stream.releaseTimer = null;
        if (stream.refs === 0) {
          this.closeStream(symbol);
          this.streams.delete(symbol);
        }
      }, 8000);
    }
  }

  private resetStreamsForReconnect(): void {
    this.streamByReq.clear();
    for (const stream of this.streams.values()) {
      stream.reqId = null;
      stream.subId = null;
    }
  }

  private onMessage(raw: unknown): void {
    let msg: any;
    try {
      msg = JSON.parse(String(raw));
    } catch {
      return;
    }

    this.snapshot = {
      ...this.snapshot,
      lastMessageAt: Date.now(),
    };

    const reqId = msg.req_id;

    if (!this.healthy && msg.msg_type === "ping" && this.handshakeId != null) {
      const p = this.pending.get(this.handshakeId);
      this.pending.delete(this.handshakeId);
      this.handshakeId = null;
      p?.resolve(msg);
      return;
    }

    const streamSymbol = reqId != null ? this.streamByReq.get(reqId) : undefined;

    if (msg.msg_type === "tick" && msg.tick) {
      this.onTick(msg);
      return;
    }

    if (streamSymbol) {
      if (msg.error) {
        if (msg.error.code !== "AlreadySubscribed") {
          this.streamByReq.delete(reqId);
          const s = this.streams.get(streamSymbol);
          if (s) s.reqId = null;
          this.setBook(streamSymbol, {
            ...this.getBook(streamSymbol),
            state: "error",
            error: msg.error.message ?? "Stream unavailable.",
          });
        }
        return;
      }

      if (msg.msg_type === "history") {
        const stream = this.streams.get(streamSymbol);
        if (stream && msg.subscription?.id) {
          stream.subId = msg.subscription.id;
        }
        this.onSeed(streamSymbol, msg);
        return;
      }
    }

    if (reqId != null) {
      const p = this.pending.get(reqId);
      if (p) {
        this.pending.delete(reqId);
        clearTimeout(p.timer);
        if (msg.error) {
          p.reject(new Error(msg.error.message ?? "Request failed."));
        } else {
          p.resolve(msg);
        }
      }
    } else if (msg.error) {
      this.update({ error: msg.error.message ?? null });
    }

    this.emit();
  }

  private onSeed(symbol: string, msg: any): void {
    const ticks = this.parseHistory(symbol, msg);
    const book = this.getBook(symbol);
    const lastEpoch = ticks.length ? ticks[ticks.length - 1].epoch : -Infinity;
    const merged = [
      ...ticks,
      ...book.ticks.filter((t) => t.epoch > lastEpoch),
    ].slice(-BUFFER_CAP);

    this.setBook(symbol, {
      symbol,
      ticks: merged,
      pipSize: msg.pip_size ?? book.pipSize,
      state: "live",
      error: null,
      lastTickAt: Date.now(),
    });
  }

  private onTick(msg: any): void {
    const tickData = msg.tick;
    const symbol = tickData.symbol;
    const stream = this.streams.get(symbol);
    if (!stream) return;

    if (!stream.subId && msg.subscription?.id) {
      stream.subId = msg.subscription.id;
    }

    const book = this.getBook(symbol);
    const pipSize = tickData.pip_size ?? book.pipSize;
    const newTick: Tick = {
      epoch: tickData.epoch,
      quote: Number(tickData.quote),
      digit: extractLastDigit(tickData.quote, pipSize),
      symbol,
    };

    const last = book.ticks[book.ticks.length - 1];
    let nextTicks = book.ticks;

    if (!last || newTick.epoch > last.epoch) {
      nextTicks = [...book.ticks, newTick].slice(-BUFFER_CAP);
    } else if (newTick.epoch === last.epoch) {
      nextTicks = [...book.ticks.slice(0, -1), newTick];
    } else {
      nextTicks = [...book.ticks, newTick]
        .sort((a, b) => a.epoch - b.epoch)
        .slice(-BUFFER_CAP);
    }

    this.setBook(symbol, {
      symbol,
      ticks: nextTicks,
      pipSize,
      state: "live",
      error: null,
      lastTickAt: Date.now(),
    });
  }

  private parseHistory(symbol: string, msg: any): Tick[] {
    const prices: number[] = msg.history?.prices ?? [];
    const times: number[] = msg.history?.times ?? [];
    const pipSize = msg.pip_size ?? msg.history?.pip_size;

    return prices.map((quote, idx) => ({
      epoch: times[idx],
      quote: Number(quote),
      digit: extractLastDigit(quote, pipSize),
      symbol,
    }));
  }

  private setBook(symbol: string, book: MarketBook): void {
    this.books.set(symbol, book);
    this.emit();
  }

  private update(patch: Partial<FeedSnapshot>): void {
    this.snapshot = {
      ...this.snapshot,
      ...patch,
      version: this.snapshot.version + 1,
    };
    this.emit();
  }

  private emit(): void {
    for (const listener of this.listeners) {
      listener();
    }
  }
}

export const derivClient = new DerivFeedClient();
