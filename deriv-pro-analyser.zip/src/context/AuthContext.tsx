import React, {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { UserProfile, UserSession } from "../types";

const SESSION_STORAGE_KEY = "dpa_session_username";

const MOCK_USERS: Record<
  string,
  { password: string; profile: UserProfile }
> = {
  "2345": {
    password: "aaaa",
    profile: {
      id: "client-2345",
      username: "2345",
      email: "2345@derivproanalyser.app",
      is_admin: true,
      account_status: "ACTIVE",
      access_level: "PRO",
      access_expiry: null,
      pro_entitled: true,
      payment_status: "VERIFIED",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
  },
};

interface AuthContextValue {
  session: UserSession | null;
  profile: UserProfile | null;
  loading: boolean;
  signIn: (
    username: string,
    password: string
  ) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<UserSession | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    try {
      const savedUser = localStorage.getItem(SESSION_STORAGE_KEY);
      if (savedUser && MOCK_USERS[savedUser]) {
        const entry = MOCK_USERS[savedUser];
        setSession({ user: { id: entry.profile.id, username: savedUser } });
        setProfile(entry.profile);
      }
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }, []);

  const signIn = async (username: string, pass: string) => {
    const trimmed = username.trim();
    const entry = MOCK_USERS[trimmed];

    if (!entry || entry.password !== pass) {
      // Allow any guest demo if they type demo / demo
      if (trimmed.toLowerCase() === "demo" || trimmed === "admin") {
        const demoProfile: UserProfile = {
          id: `client-${trimmed}`,
          username: trimmed,
          email: `${trimmed}@derivproanalyser.app`,
          is_admin: true,
          account_status: "ACTIVE",
          access_level: "PRO",
          access_expiry: null,
          pro_entitled: true,
          payment_status: "VERIFIED",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };
        localStorage.setItem(SESSION_STORAGE_KEY, trimmed);
        setSession({ user: { id: demoProfile.id, username: trimmed } });
        setProfile(demoProfile);
        return { error: null };
      }
      return { error: "Invalid username or password." };
    }

    try {
      localStorage.setItem(SESSION_STORAGE_KEY, trimmed);
    } catch {}

    setSession({ user: { id: entry.profile.id, username: trimmed } });
    setProfile(entry.profile);
    return { error: null };
  };

  const signOut = async () => {
    try {
      localStorage.removeItem(SESSION_STORAGE_KEY);
    } catch {}
    setSession(null);
    setProfile(null);
  };

  const refreshProfile = async () => {};

  const value = useMemo(
    () => ({
      session,
      profile,
      loading,
      signIn,
      signOut,
      refreshProfile,
    }),
    [session, profile, loading]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return ctx;
}
