import React, { useEffect, useMemo, useState } from "react";

function BinaryRain() {
  const columns = useMemo(
    () =>
      Array.from({ length: 24 }, (_, i) => {
        const chars = Array.from({ length: 28 }, () =>
          Math.random() > 0.5 ? "1" : "0"
        ).join(" ");
        return {
          left: `${(i / 24) * 100}%`,
          duration: `${4 + Math.random() * 5}s`,
          delay: `${-Math.random() * 6}s`,
          chars,
          key: i,
        };
      }),
    []
  );

  return (
    <div
      className="pointer-events-none absolute inset-0 overflow-hidden opacity-[0.18]"
      aria-hidden="true"
    >
      {columns.map((col) => (
        <div
          key={col.key}
          className="absolute top-0 animate-binary-fall font-mono text-[13px] font-bold leading-5 text-[#0369a1]"
          style={{
            left: col.left,
            animationDuration: col.duration,
            animationDelay: col.delay,
            writingMode: "vertical-rl",
          }}
        >
          {col.chars}
        </div>
      ))}
    </div>
  );
}

interface IntroSplashProps {
  onDone: () => void;
}

export const IntroSplash: React.FC<IntroSplashProps> = ({ onDone }) => {
  const [progress, setProgress] = useState(0);
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((p) => Math.min(p + 4, 100));
    }, 90);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (progress >= 100 && !fadeOut) {
      setFadeOut(true);
      const timeout = setTimeout(onDone, 500);
      return () => clearTimeout(timeout);
    }
  }, [progress, fadeOut, onDone]);

  return (
    <div
      className={`fixed inset-0 z-[100] flex flex-col items-center justify-center bg-white transition-opacity duration-500 ${
        fadeOut ? "opacity-0 pointer-events-none" : "opacity-100"
      }`}
    >
      <BinaryRain />
      <div className="pointer-events-none absolute inset-0 bg-grid-faint opacity-40 [background-size:40px_40px]" />
      <div className="pointer-events-none absolute h-72 w-72 rounded-full bg-[#e0f2fe] blur-3xl" />

      <div className="relative flex flex-col items-center gap-6">
        <div className="relative">
          <div className="absolute inset-0 animate-ping rounded-2xl bg-[#0ea5e9]/40" />
          <div className="relative grid h-20 w-20 place-items-center rounded-2xl border-2 border-black bg-[#0284c7] shadow-hard">
            {/* Antenna */}
            <span className="absolute left-1/2 top-0 h-3 w-[3px] -translate-x-1/2 -translate-y-full bg-black" />
            <span className="absolute left-1/2 top-0 h-2 w-2 -translate-x-1/2 -translate-y-[210%] rounded-full bg-[#7dd3fc]" />
            {/* Eyes */}
            <div className="flex items-center gap-2">
              <span className="h-4 w-4 origin-center animate-blink rounded-[4px] bg-white" />
              <span
                className="h-4 w-4 origin-center animate-blink rounded-[4px] bg-white"
                style={{ animationDelay: "0.15s" }}
              />
            </div>
            {/* Smile */}
            <span className="absolute bottom-3 left-1/2 h-[3px] w-6 -translate-x-1/2 rounded-full bg-[#bae6fd]" />
          </div>
        </div>

        <div className="text-center">
          <p className="font-display text-xl font-extrabold lowercase tracking-tight text-black sm:text-2xl">
            derivproanalyser
          </p>
          <p className="mt-1 font-mono text-xs font-bold uppercase tracking-[0.2em] text-[#5c636b]">
            Initializing Analysis Engine...
          </p>
        </div>

        <div className="w-56">
          <div className="h-2.5 w-full overflow-hidden rounded-full border-2 border-black bg-white">
            <div
              className="h-full bg-[#0284c7] transition-all duration-100"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="mt-2 text-center font-mono text-xs font-bold tabular-nums text-black">
            {progress}%
          </p>
        </div>
      </div>
    </div>
  );
};
