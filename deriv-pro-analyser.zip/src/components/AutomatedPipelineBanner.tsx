import React, { useEffect, useState } from "react";
import { Zap } from "lucide-react";
import { PIPELINE_STAGES } from "../constants";

export const AutomatedPipelineBanner: React.FC = () => {
  const [currentStage, setCurrentStage] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentStage((prev) => (prev + 1) % PIPELINE_STAGES.length);
    }, 1800);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="w-full overflow-hidden rounded-2xl border-2 border-black bg-black text-white shadow-hard">
      {/* Scan Sweep Bar */}
      <div className="relative h-1.5 overflow-hidden bg-white/10">
        <div className="absolute inset-y-0 w-1/3 animate-scan-sweep bg-[#38bdf8]" />
      </div>

      <div className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:gap-5 sm:p-5">
        <div className="flex shrink-0 items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-lg border-2 border-white/30 bg-[#0ea5e9]">
            <Zap size={17} className="animate-pulse-slow text-black" />
          </span>
          <div>
            <p className="font-mono text-[10px] font-extrabold uppercase tracking-[0.2em] text-[#7dd3fc]">
              Automated engine
            </p>
            <p className="font-display text-sm font-extrabold uppercase tracking-wide">
              Fully automated pipeline
            </p>
          </div>
        </div>

        <div className="min-w-0 flex-1 sm:border-l-2 sm:border-white/15 sm:pl-5">
          <p className="font-mono text-[10px] font-extrabold uppercase tracking-[0.2em] text-white/45">
            Stage {currentStage + 1} of {PIPELINE_STAGES.length}
          </p>
          <p
            key={currentStage}
            className="animate-ticker-in truncate font-mono text-sm font-bold text-[#7dd3fc]"
          >
            ▸ {PIPELINE_STAGES[currentStage]}
          </p>
        </div>

        <div className="flex shrink-0 gap-1">
          {PIPELINE_STAGES.map((_, idx) => (
            <span
              key={idx}
              className={`h-1.5 w-5 rounded-full transition-colors duration-300 ${
                idx === currentStage
                  ? "bg-[#38bdf8]"
                  : idx < currentStage
                  ? "bg-white/45"
                  : "bg-white/15"
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
