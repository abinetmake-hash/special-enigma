import React, { useMemo } from "react";
import { Tick } from "../types";
import { calculateDistribution } from "../utils/analysis";

interface DigitChartProps {
  ticks: Tick[];
  tickCount?: number;
  selectable?: boolean;
  selectedDigit?: number | null;
  onSelect?: (digit: number) => void;
}

export const DigitChart: React.FC<DigitChartProps> = ({
  ticks,
  tickCount,
  selectable = false,
  selectedDigit = null,
  onSelect,
}) => {
  const windowTicks = useMemo(
    () => (tickCount ? ticks.slice(-tickCount) : ticks),
    [ticks, tickCount]
  );

  const distribution = useMemo(
    () => calculateDistribution(windowTicks),
    [windowTicks]
  );

  const maxPct = useMemo(() => {
    const pcts = distribution.map((d) => d.percentage);
    return Math.max(15, ...pcts);
  }, [distribution]);

  const evenPct = useMemo(() => {
    if (!windowTicks.length) return 50;
    const evens = windowTicks.filter((t) => t.digit % 2 === 0).length;
    return (evens / windowTicks.length) * 100;
  }, [windowTicks]);

  return (
    <div className="glass-card p-4 sm:p-5">
      <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="font-display font-extrabold uppercase tracking-wide text-black">
            Digit Distribution
          </h3>
          <p className="font-mono text-xs font-bold text-[#5c636b]">
            Appearance rate over the last {windowTicks.length} ticks
          </p>
        </div>

        <div className="flex items-center gap-3 font-mono text-xs font-bold">
          <span className="flex items-center gap-1.5 text-black">
            <span className="h-2 w-2 rounded-full bg-[#0ea5e9]" /> Even:{" "}
            {evenPct.toFixed(1)}%
          </span>
          <span className="flex items-center gap-1.5 text-black">
            <span className="h-2 w-2 rounded-full bg-[#38bdf8]" /> Odd:{" "}
            {(100 - evenPct).toFixed(1)}%
          </span>
        </div>
      </div>

      {/* Bar Chart Container */}
      <div className="relative pt-6 pb-2">
        {/* 10.0% Expected Line */}
        <div
          className="pointer-events-none absolute left-0 right-0 border-b border-dashed border-[#8e959e]"
          style={{ bottom: `${(10 / maxPct) * 100}%` }}
        >
          <span className="absolute -top-4 right-0 font-mono text-[9px] font-bold text-[#8e959e]">
            10.0% Expected
          </span>
        </div>

        <div className="grid grid-cols-10 gap-1.5 sm:gap-3 items-end h-44">
          {distribution.map((item) => {
            const isSelected = selectedDigit === item.digit;
            const barHeightPct = Math.min(100, (item.percentage / maxPct) * 100);
            const isHigh = item.percentage > 12;

            return (
              <div
                key={item.digit}
                onClick={() => selectable && onSelect?.(item.digit)}
                className={`flex flex-col items-center gap-1.5 ${
                  selectable ? "cursor-pointer" : ""
                }`}
              >
                <span className="font-mono text-[10px] font-extrabold text-[#5c636b] tabular-nums sm:text-xs">
                  {item.percentage.toFixed(1)}%
                </span>

                <div className="relative w-full rounded-t-lg bg-[#e6e9ed] h-36 flex items-end overflow-hidden">
                  <div
                    className={`w-full rounded-t-lg transition-all duration-300 ${
                      isSelected
                        ? "bg-black"
                        : isHigh
                        ? "bg-[#0ea5e9]"
                        : "bg-[#38bdf8]"
                    }`}
                    style={{ height: `${barHeightPct}%` }}
                  />
                </div>

                <span
                  className={`grid h-7 w-7 place-items-center rounded-md border-2 font-mono text-xs font-extrabold ${
                    isSelected
                      ? "border-black bg-black text-white"
                      : "border-black bg-white text-black"
                  }`}
                >
                  {item.digit}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
