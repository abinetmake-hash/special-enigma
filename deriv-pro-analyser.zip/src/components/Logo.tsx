import React from "react";

interface LogoProps {
  size?: "sm" | "md" | "lg";
  dark?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ size = "md", dark = false }) => {
  const iconDimensions =
    size === "sm" ? "h-7 w-7" : size === "lg" ? "h-11 w-11" : "h-9 w-9";
  const textSize =
    size === "sm" ? "text-base" : size === "lg" ? "text-2xl" : "text-lg";

  return (
    <div className="flex items-center gap-2.5 select-none">
      <span
        className={`${iconDimensions} relative grid place-items-center rounded-xl border-2 border-black bg-[#0284c7] shadow-hard`}
        aria-hidden="true"
      >
        {/* Antenna Pole */}
        <span className="absolute left-1/2 top-0 h-1 w-[2px] -translate-x-1/2 -translate-y-full bg-black" />
        {/* Antenna Tip */}
        <span className="absolute left-1/2 top-0 h-1 w-1 -translate-x-1/2 -translate-y-[150%] rounded-full bg-[#7dd3fc]" />
        {/* Blinking Eyes */}
        <span className="flex items-center gap-[3px]">
          <span className="h-[7px] w-[7px] origin-center animate-blink rounded-[2px] bg-white" />
          <span
            className="h-[7px] w-[7px] origin-center animate-blink rounded-[2px] bg-white"
            style={{ animationDelay: "0.15s" }}
          />
        </span>
        {/* Smile */}
        <span className="absolute bottom-[18%] left-1/2 h-[2px] w-2 -translate-x-1/2 rounded-full bg-[#bae6fd]" />
      </span>
      <span
        className={`font-display ${textSize} font-extrabold lowercase tracking-tight ${
          dark ? "text-white" : "text-black"
        }`}
      >
        derivproanalyser
      </span>
    </div>
  );
};
