import React from "react";

interface StatusIndicatorProps {
  color?: "brand" | "rose" | "gray" | "cyan" | "amber" | "emerald";
  pulse?: boolean;
  label?: string;
}

const COLOR_MAP: Record<string, string> = {
  brand: "bg-[#0ea5e9]",
  rose: "bg-rose-500",
  gray: "bg-[#8e959e]",
  cyan: "bg-[#38bdf8]",
  amber: "bg-amber-400",
  emerald: "bg-emerald-500",
};

export const StatusIndicator: React.FC<StatusIndicatorProps> = ({
  color = "brand",
  pulse = false,
  label,
}) => {
  const bgClass = COLOR_MAP[color] || "bg-[#0ea5e9]";

  return (
    <span className="inline-flex items-center gap-2">
      <span className="relative flex h-2.5 w-2.5">
        {pulse && (
          <span
            className={`absolute inline-flex h-full w-full animate-ping rounded-full ${bgClass} opacity-75`}
          />
        )}
        <span
          className={`relative inline-flex h-2.5 w-2.5 rounded-full ring-2 ring-black ${bgClass}`}
        />
      </span>
      {label && (
        <span className="font-mono text-[11px] font-bold uppercase tracking-wide text-[#161b22]">
          {label}
        </span>
      )}
    </span>
  );
};
