import React, { useEffect, useState } from "react";
import { Zap } from "lucide-react";

interface AnalysisRunnerOverlayProps {
  progress: number;
  message?: string;
}

const SCAN_STEPS = [
  "Reading live ticks from stream",
  "Extracting last digits at native pip size",
  "Building frequency distribution table",
  "Measuring deviation against uniform baseline",
  "Estimating probability & model confidence",
  "Formulating signal prediction",
];

export const AnalysisRunnerOverlay: React.FC<AnalysisRunnerOverlayProps> = ({
  progress,
  message = "Analyzing market ticks...",
}) => {
  const [stepIndex, setStepIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setStepIndex((i) => (i + 1) % SCAN_STEPS.length);
    }, 700);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="glass-card overflow-hidden">
      <div className="relative h-1.5 overflow-hidden bg-[#e6e9ed]">
        <div className="absolute inset-y-0 w-1/3 animate-scan-sweep bg-[#0ea5e9]" />
      </div>

      <div className="flex flex-col items-center gap-4 p-5 sm:p-7 text-center">
        <div className="relative">
          <div className="grid h-12 w-12 place-items-center rounded-2xl border-2 border-black bg-[#0ea5e9] text-black shadow-hard animate-pulse-slow">
            <Zap size={24} />
          </div>
        </div>

        <div>
          <h4 className="font-display text-base font-extrabold uppercase tracking-wide text-black">
            {message}
          </h4>
          <p className="mt-1 font-mono text-xs font-bold text-[#0369a1] animate-fade-in">
            ▸ {SCAN_STEPS[stepIndex]}
          </p>
        </div>

        <div className="w-full max-w-sm">
          <div className="h-2.5 w-full overflow-hidden rounded-full border-2 border-black bg-white">
            <div
              className="h-full bg-[#0ea5e9] transition-all duration-100"
              style={{ width: `${Math.round(progress)}%` }}
            />
          </div>
          <p className="mt-1.5 text-center font-mono text-xs font-extrabold tabular-nums text-black">
            {Math.round(progress)}%
          </p>
        </div>
      </div>
    </div>
  );
};
