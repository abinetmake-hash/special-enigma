import React from "react";
import { Gauge, Hash, Percent, Target } from "lucide-react";

interface ProbabilityCardsProps {
  winProbability: number;
  confidence: number;
  sampleSize: number;
  predictedDigitPercentage?: number | null;
}

export const ProbabilityCards: React.FC<ProbabilityCardsProps> = ({
  winProbability,
  confidence,
  sampleSize,
  predictedDigitPercentage,
}) => {
  const confidenceClass =
    confidence >= 75
      ? "bg-[#0ea5e9] text-black"
      : confidence >= 62
      ? "bg-[#0c4a6e] text-white"
      : "bg-white text-black";

  return (
    <div className="grid w-full max-w-md grid-cols-2 gap-2 sm:grid-cols-4">
      {/* Win Rate */}
      <div className="rounded-xl border-2 border-black bg-black p-3 text-white">
        <div className="flex items-center gap-1.5 font-mono text-[10px] font-extrabold uppercase tracking-wider text-white/70">
          <Target size={13} /> Win rate
        </div>
        <div className="mt-1 font-mono text-xl font-extrabold tabular-nums sm:text-2xl">
          {winProbability.toFixed(1)}%
        </div>
      </div>

      {/* Model Confidence */}
      <div
        className={`rounded-xl border-2 border-black p-3 transition-colors ${confidenceClass}`}
      >
        <div className="flex items-center gap-1.5 font-mono text-[10px] font-extrabold uppercase tracking-wider opacity-80">
          <Gauge size={13} /> Confidence
        </div>
        <div className="mt-1 font-mono text-xl font-extrabold tabular-nums sm:text-2xl">
          {confidence.toFixed(1)}%
        </div>
      </div>

      {/* Digit Rate (if applicable) */}
      {predictedDigitPercentage != null && (
        <div className="rounded-xl border-2 border-black bg-white p-3 text-black">
          <div className="flex items-center gap-1.5 font-mono text-[10px] font-extrabold uppercase tracking-wider text-[#5c636b]">
            <Percent size={13} /> Digit rate
          </div>
          <div className="mt-1 font-mono text-xl font-extrabold tabular-nums sm:text-2xl">
            {predictedDigitPercentage.toFixed(1)}%
          </div>
        </div>
      )}

      {/* Sample Size / Ticks */}
      <div className="rounded-xl border-2 border-black bg-white p-3 text-black">
        <div className="flex items-center gap-1.5 font-mono text-[10px] font-extrabold uppercase tracking-wider text-[#5c636b]">
          <Hash size={13} /> Ticks
        </div>
        <div className="mt-1 font-mono text-xl font-extrabold tabular-nums sm:text-2xl">
          {sampleSize}
        </div>
      </div>
    </div>
  );
};
