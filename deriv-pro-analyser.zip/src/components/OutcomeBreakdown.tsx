import React from "react";
import { AnalysisOutcome } from "../types";

interface OutcomeBreakdownProps {
  outcomes: AnalysisOutcome[];
  highlight?: string;
}

export const OutcomeBreakdown: React.FC<OutcomeBreakdownProps> = ({
  outcomes,
  highlight,
}) => {
  if (!outcomes.length) return null;

  return (
    <div className="w-full space-y-2">
      {outcomes.map((outcome) => {
        const isTarget = highlight ? outcome.label.startsWith(highlight) : false;

        return (
          <div key={outcome.label}>
            <div className="mb-1 flex items-baseline justify-between gap-2">
              <span
                className={`font-mono text-[11px] font-extrabold uppercase tracking-wide ${
                  isTarget ? "text-[#0369a1]" : "text-[#22272e]"
                }`}
              >
                {outcome.label}
              </span>
              <span className="font-mono text-xs font-extrabold tabular-nums text-black">
                {outcome.percentage.toFixed(1)}%{" "}
                <span className="text-[#8e959e] font-medium">({outcome.count})</span>
              </span>
            </div>

            <div className="h-2.5 w-full overflow-hidden rounded-full border-2 border-black bg-white">
              <div
                className={`h-full transition-all duration-300 ${
                  isTarget ? "bg-[#0ea5e9]" : "bg-[#c3c8cf]"
                }`}
                style={{ width: `${Math.min(100, Math.max(0, outcome.percentage))}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
};
