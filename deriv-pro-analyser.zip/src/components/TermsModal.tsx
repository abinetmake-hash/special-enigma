import React, { useEffect } from "react";
import { X, ShieldAlert } from "lucide-react";

interface TermsModalProps {
  open: boolean;
  onClose: () => void;
}

export const TermsModal: React.FC<TermsModalProps> = ({ open, onClose }) => {
  useEffect(() => {
    if (!open) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", handleKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-xs"
        onClick={onClose}
      />
      <div className="relative w-full max-w-lg rounded-2xl border-2 border-black bg-white p-6 shadow-hard animate-scale-in">
        <div className="flex items-start justify-between border-b-2 border-[#e6e9ed] pb-4">
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-lg border-2 border-black bg-[#0ea5e9] text-black">
              <ShieldAlert size={18} />
            </span>
            <div>
              <h3 className="font-display text-lg font-extrabold uppercase tracking-tight text-black">
                Terms & Conditions
              </h3>
              <p className="font-mono text-xs font-bold text-[#5c636b]">
                Deriv Pro Analyser User Agreement
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg border-2 border-black p-1.5 text-black hover:bg-black hover:text-white transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        <div className="mt-4 max-h-[60vh] space-y-3 overflow-y-auto pr-2 text-xs font-medium leading-relaxed text-[#22272e]">
          <p>
            <strong>1. Statistical Analysis Only:</strong> Deriv Pro Analyser is a
            statistical analysis and probability modeling tool designed
            specifically for Deriv synthetic volatility index tick streams. It
            does not place trades, does not guarantee profits, and is strictly
            not financial advice.
          </p>
          <p>
            <strong>2. Risk of Loss:</strong> All financial and synthetic
            trading markets carry substantial risk of capital loss. Past statistical
            patterns, digit deviation scores, and historical tendencies do not
            guarantee future outcomes.
          </p>
          <p>
            <strong>3. Personal & Non-Transferable:</strong> Access credentials
            issued for Deriv Pro Analyser are personal and non-transferable.
            Sharing credentials or reverse-engineering algorithms is prohibited.
          </p>
          <p>
            <strong>4. Regulatory Compliance:</strong> You are solely responsible
            for ensuring your use of Deriv and third-party trading tools complies
            with the laws and financial regulations of your local jurisdiction.
          </p>
          <p>
            <strong>5. Third-Party Services:</strong> Any third-party tools, bots,
            or brokers (such as RNGTrader or Deriv) linked from this application
            are independent entities not operated or owned by Deriv Pro Analyser.
          </p>
        </div>

        <div className="mt-6 border-t-2 border-[#e6e9ed] pt-4">
          <button onClick={onClose} className="btn-primary w-full py-3">
            I Understand & Agree
          </button>
        </div>
      </div>
    </div>
  );
};
