import React, { useState } from "react";
import { Lock, User, Key, CheckSquare, Square, X, Loader2, Info } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { TermsModal } from "./TermsModal";

interface LoginModalProps {
  open: boolean;
  onClose: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ open, onClose }) => {
  const { signIn } = useAuth();
  const [username, setUsername] = useState("2345");
  const [password, setPassword] = useState("aaaa");
  const [agreed, setAgreed] = useState(true);
  const [showTerms, setShowTerms] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!open) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!agreed) {
      setError("You must agree to the Terms & Conditions.");
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const res = await signIn(username, password);
      if (res.error) {
        setError(res.error);
      } else {
        onClose();
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleFillDemo = () => {
    setUsername("2345");
    setPassword("aaaa");
    setAgreed(true);
    setError(null);
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div
          className="absolute inset-0 bg-black/75 backdrop-blur-xs"
          onClick={onClose}
        />

        <div className="relative w-full max-w-md rounded-2xl border-2 border-black bg-white p-6 shadow-hard animate-scale-in">
          {/* Header */}
          <div className="flex items-start justify-between border-b-2 border-[#e6e9ed] pb-4">
            <div className="flex items-center gap-2.5">
              <span className="grid h-10 w-10 place-items-center rounded-xl border-2 border-black bg-[#0ea5e9] text-black shadow-hard">
                <Lock size={19} />
              </span>
              <div>
                <h3 className="font-display text-lg font-extrabold uppercase tracking-tight text-black">
                  Account Login
                </h3>
                <p className="font-mono text-xs font-bold text-[#5c636b]">
                  Deriv Pro Analyser Authentication
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="rounded-lg border-2 border-black p-1.5 text-black hover:bg-black hover:text-white transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>

          {/* Quick Demo Credentials Helper */}
          <div className="mt-4 flex items-center justify-between rounded-xl border-2 border-[#bae6fd] bg-[#f0f9ff] p-3 text-xs">
            <div className="font-medium text-[#0369a1]">
              <strong>Demo Login:</strong> User <code>2345</code> · Pass <code>aaaa</code>
            </div>
            <button
              type="button"
              onClick={handleFillDemo}
              className="rounded-md border border-black bg-white px-2 py-1 font-mono text-[11px] font-bold text-black hover:bg-[#0ea5e9] transition-colors cursor-pointer"
            >
              Auto-Fill
            </button>
          </div>

          <form onSubmit={handleSubmit} className="mt-4 space-y-4">
            {/* Username */}
            <div>
              <label className="mb-1.5 block font-mono text-xs font-bold uppercase tracking-wider text-[#5c636b]">
                Username or Client ID
              </label>
              <div className="relative">
                <User
                  size={16}
                  className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#8e959e]"
                />
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. 2345"
                  className="input-field pl-9"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="mb-1.5 block font-mono text-xs font-bold uppercase tracking-wider text-[#5c636b]">
                Access Password
              </label>
              <div className="relative">
                <Key
                  size={16}
                  className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#8e959e]"
                />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="input-field pl-9"
                />
              </div>
            </div>

            {/* Terms checkbox */}
            <div className="rounded-xl border-2 border-[#e6e9ed] bg-[#f4f6f8] p-3">
              <label className="flex cursor-pointer items-start gap-2.5 text-xs font-semibold text-[#161b22]">
                <button
                  type="button"
                  onClick={() => setAgreed(!agreed)}
                  className="mt-0.5 text-black hover:text-[#0369a1]"
                >
                  {agreed ? (
                    <CheckSquare size={16} className="text-[#0369a1]" />
                  ) : (
                    <Square size={16} className="text-[#8e959e]" />
                  )}
                </button>
                <span>
                  I agree to the{" "}
                  <button
                    type="button"
                    onClick={() => setShowTerms(true)}
                    className="font-bold text-[#0369a1] underline hover:text-black"
                  >
                    Terms & Conditions
                  </button>
                  . Statistical analysis only. Not financial advice.
                </span>
              </label>
            </div>

            {error && (
              <div className="rounded-xl border-2 border-rose-500 bg-rose-50 p-3 text-xs font-bold text-rose-700">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={submitting || !agreed}
              className="btn-primary w-full py-3.5 text-sm"
            >
              {submitting ? (
                <>
                  <Loader2 size={18} className="animate-spin" /> Signing In...
                </>
              ) : (
                "Login to Analyser"
              )}
            </button>
          </form>

          {/* Secure credentials note */}
          <div className="mt-4 flex items-start gap-2 rounded-xl border border-[#e6e9ed] bg-[#f4f6f8] p-3 text-[11px] font-medium text-[#5c636b]">
            <Info size={15} className="mt-0.5 shrink-0 text-[#0369a1]" />
            <span>
              Access is login-only. New accounts are provisioned by an administrator
              after purchase.
            </span>
          </div>
        </div>
      </div>

      <TermsModal open={showTerms} onClose={() => setShowTerms(false)} />
    </>
  );
};
