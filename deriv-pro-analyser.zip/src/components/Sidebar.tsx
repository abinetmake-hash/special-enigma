import React from "react";
import {
  ArrowUpDown,
  BarChart3,
  Binary,
  Bot,
  ExternalLink,
  LayoutDashboard,
  LogOut,
  Radar,
  Target,
  X,
} from "lucide-react";
import { Logo } from "./Logo";
import { PageId } from "../types";
import { RNGTRADER_URL } from "../constants";
import { useAuth } from "../context/AuthContext";

interface NavItemConfig {
  key: PageId;
  label: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
}

export const NAV_ITEMS: NavItemConfig[] = [
  { key: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { key: "matches", label: "Matches/Differs", icon: Target },
  { key: "evenodd", label: "Even/Odd", icon: Binary },
  { key: "overunder", label: "Over/Under", icon: ArrowUpDown },
  { key: "scanner", label: "Volatility Scanner", icon: Radar },
  { key: "frequency", label: "Frequency Graph", icon: BarChart3 },
];

interface SidebarProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onNavigate,
  mobileOpen,
  onCloseMobile,
}) => {
  const { signOut, profile } = useAuth();

  const handleNav = (page: PageId) => {
    onNavigate(page);
    onCloseMobile();
  };

  const navContent = (
    <div className="flex h-full flex-col justify-between">
      <div>
        {/* Brand Lockup */}
        <div className="flex h-16 items-center justify-between border-b-2 border-black px-5">
          <Logo size="sm" />
          <button
            onClick={onCloseMobile}
            className="lg:hidden rounded-lg border-2 border-black p-1 text-black hover:bg-black hover:text-white"
          >
            <X size={18} />
          </button>
        </div>

        {/* Navigation Items */}
        <nav className="space-y-1.5 p-3">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.key;

            return (
              <button
                key={item.key}
                type="button"
                onClick={() => handleNav(item.key)}
                className={`flex w-full items-center gap-3 rounded-xl border-2 px-3 py-2.5 font-display text-xs font-extrabold uppercase tracking-wide transition-all cursor-pointer ${
                  isActive
                    ? "border-black bg-black text-white shadow-hard"
                    : "border-transparent text-[#22272e] hover:border-black hover:bg-[#f0f9ff]"
                }`}
              >
                <Icon
                  size={18}
                  className={isActive ? "text-[#0ea5e9]" : "text-[#5c636b]"}
                />
                <span>{item.label}</span>
              </button>
            );
          })}

          {/* External Platform Link (RNGTrader) */}
          <div className="pt-2">
            <a
              href={RNGTRADER_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-between rounded-xl border-2 border-black bg-[#f0f9ff] p-3 text-xs font-bold text-black shadow-hard-blue transition-transform hover:-translate-y-0.5"
            >
              <div className="flex items-center gap-2">
                <span className="grid h-7 w-7 place-items-center rounded-lg border-2 border-black bg-black text-white">
                  <Bot size={15} />
                </span>
                <div>
                  <div className="font-display font-extrabold uppercase text-[11px]">
                    RNGTrader
                  </div>
                  <div className="text-[10px] text-[#0369a1]">Free Bots</div>
                </div>
              </div>
              <ExternalLink size={14} className="text-[#0369a1]" />
            </a>
          </div>
        </nav>
      </div>

      {/* Footer Profile & Logout */}
      <div className="border-t-2 border-black p-3 space-y-2">
        {profile && (
          <div className="rounded-xl border border-[#e6e9ed] bg-[#f4f6f8] px-3 py-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-mono font-bold text-black">
                {profile.username}
              </span>
              <span className="rounded bg-[#0ea5e9] px-1.5 py-0.5 font-mono text-[9px] font-extrabold text-black uppercase">
                {profile.access_level}
              </span>
            </div>
            <div className="font-mono text-[10px] text-[#5c636b]">
              Deriv Analyser Verified
            </div>
          </div>
        )}

        <button
          type="button"
          onClick={() => signOut()}
          className="flex w-full items-center gap-3 rounded-xl border-2 border-transparent px-3 py-2 text-xs font-extrabold uppercase tracking-wide text-[#5c636b] transition-colors hover:border-black hover:bg-black hover:text-white cursor-pointer"
        >
          <LogOut size={16} /> Log out
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r-2 border-black bg-white lg:flex">
        {navContent}
      </aside>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-black/70 backdrop-blur-xs"
            onClick={onCloseMobile}
          />
          <div className="relative h-full w-72 max-w-[85vw] border-r-2 border-black bg-white shadow-hard">
            {navContent}
          </div>
        </div>
      )}
    </>
  );
};
