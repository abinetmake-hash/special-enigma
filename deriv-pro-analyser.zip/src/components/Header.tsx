import React from "react";
import { Menu, RefreshCw, Wifi, WifiOff } from "lucide-react";
import { Logo } from "./Logo";
import { StatusIndicator } from "./StatusIndicator";

interface HeaderProps {
  status: "connecting" | "open" | "closed" | "error";
  source: string | null;
  error: string | null;
  onReconnect: () => void;
  onOpenMobileMenu: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  status,
  source,
  error,
  onReconnect,
  onOpenMobileMenu,
}) => {
  const isOnline = status === "open";

  return (
    <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b-2 border-black bg-white px-4 sm:px-6">
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobileMenu}
          className="rounded-lg border-2 border-black p-1.5 text-black hover:bg-black hover:text-white transition-colors lg:hidden cursor-pointer"
          aria-label="Open navigation menu"
        >
          <Menu size={20} />
        </button>

        <div className="lg:hidden">
          <Logo size="sm" />
        </div>
      </div>

      {/* Feed Status and Diagnostics */}
      <div className="flex items-center gap-2 sm:gap-4">
        <div className="flex items-center gap-2 rounded-xl border border-[#e6e9ed] bg-[#f4f6f8] px-3 py-1.5">
          <StatusIndicator
            color={isOnline ? "brand" : status === "connecting" ? "amber" : "rose"}
            pulse={isOnline || status === "connecting"}
          />
          <div className="text-left font-mono text-[11px] leading-tight">
            <span className="font-extrabold uppercase text-black">
              {isOnline
                ? "Live Stream"
                : status === "connecting"
                ? "Connecting..."
                : "Disconnected"}
            </span>
            {source && (
              <span className="hidden text-[10px] text-[#5c636b] sm:inline ml-1">
                · {source}
              </span>
            )}
          </div>
        </div>

        <button
          onClick={onReconnect}
          title={error ?? "Refresh connection"}
          className="inline-flex items-center gap-1.5 rounded-lg border-2 border-black bg-white px-2.5 py-1.5 font-mono text-xs font-bold text-black hover:bg-[#f0f9ff] active:translate-x-0.5 active:translate-y-0.5 transition-all cursor-pointer"
        >
          <RefreshCw
            size={13}
            className={status === "connecting" ? "animate-spin" : ""}
          />
          <span className="hidden sm:inline">Reconnect</span>
        </button>
      </div>
    </header>
  );
};
