import React from "react";
import { ChevronDown, Sliders, Sparkles } from "lucide-react";
import { MARKETS, SAMPLE_SIZE_OPTIONS } from "../constants";

interface MarketSelectorProps {
  value: string;
  onChange: (symbol: string) => void;
  label?: string;
  spinning?: boolean;
  disabled?: boolean;
}

export const MarketSelector: React.FC<MarketSelectorProps> = ({
  value,
  onChange,
  label = "Select Volatility Market",
  spinning = false,
  disabled = false,
}) => {
  return (
    <div>
      <label className="section-title mb-2 flex items-center gap-2">
        {label}
        {spinning && (
          <span className="inline-flex items-center gap-1 rounded-full border-2 border-[#0ea5e9] bg-[#0ea5e9] px-2 py-0.5 text-[10px] font-extrabold text-black">
            <span className="h-2.5 w-2.5 animate-spin rounded-full border-2 border-black border-t-transparent" />{" "}
            Selecting
          </span>
        )}
      </label>
      <div className="relative">
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          disabled={disabled}
          className={`input-field cursor-pointer appearance-none pr-10 font-bold transition-colors disabled:cursor-not-allowed disabled:bg-[#f4f6f8] ${
            spinning
              ? "border-[#0ea5e9] bg-[#f0f9ff] text-[#0369a1] shadow-hard-blue"
              : ""
          }`}
        >
          {MARKETS.map((m) => (
            <option key={m.symbol} value={m.symbol}>
              {m.name} ({m.symbol})
            </option>
          ))}
        </select>
        <ChevronDown
          size={18}
          className={`pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 ${
            spinning ? "text-[#0369a1]" : "text-black"
          }`}
        />
      </div>
    </div>
  );
};

interface ModuleHeaderProps {
  icon: React.ReactNode;
  title: string;
  subtitle: string;
}

export const ModuleHeader: React.FC<ModuleHeaderProps> = ({
  icon,
  title,
  subtitle,
}) => {
  return (
    <div className="flex items-start gap-3">
      <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border-2 border-black bg-[#0ea5e9] text-black shadow-hard">
        {icon}
      </div>
      <div>
        <h2 className="font-display text-xl font-extrabold uppercase tracking-tight text-black sm:text-2xl">
          {title}
        </h2>
        <p className="text-xs font-semibold text-[#5c636b] sm:text-sm">
          {subtitle}
        </p>
      </div>
    </div>
  );
};

interface AnalysisControlsProps {
  tickCount: number;
  setTickCount: (count: number) => void;
  mode: string;
  setMode: (mode: string) => void;
  marketName: string;
  duration: number;
  locked: boolean;
}

export const AnalysisControls: React.FC<AnalysisControlsProps> = ({
  tickCount,
  setTickCount,
  mode,
  setMode,
  marketName,
  duration,
  locked,
}) => {
  return (
    <div className="glass-card p-4 sm:p-5">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sliders size={18} className="text-black" />
          <span className="section-title">Engine Configuration</span>
        </div>
        <span className="font-mono text-xs font-bold text-[#5c636b]">
          {marketName}
        </span>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        {/* Sample Size */}
        <div>
          <label className="mb-1.5 block font-mono text-[11px] font-extrabold uppercase tracking-wider text-[#5c636b]">
            Sample Window (Ticks)
          </label>
          <div className="flex flex-wrap gap-1.5">
            {SAMPLE_SIZE_OPTIONS.map((count) => (
              <button
                key={count}
                type="button"
                onClick={() => setTickCount(count)}
                disabled={locked}
                className={`rounded-lg border-2 border-black px-2.5 py-1 font-mono text-xs font-extrabold transition-all disabled:opacity-40 ${
                  tickCount === count
                    ? "bg-black text-white shadow-hard"
                    : "bg-white text-black hover:bg-[#f0f9ff]"
                }`}
              >
                {count}
              </button>
            ))}
          </div>
        </div>

        {/* Algorithm Mode */}
        <div>
          <label className="mb-1.5 block font-mono text-[11px] font-extrabold uppercase tracking-wider text-[#5c636b]">
            Algorithm Weight
          </label>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setMode("STANDARD")}
              disabled={locked}
              className={`flex-1 rounded-lg border-2 border-black py-1.5 font-display text-xs font-extrabold uppercase tracking-wide transition-all disabled:opacity-40 ${
                mode === "STANDARD"
                  ? "bg-[#0ea5e9] text-black shadow-hard"
                  : "bg-white text-black hover:bg-[#f0f9ff]"
              }`}
            >
              Standard
            </button>
            <button
              type="button"
              onClick={() => setMode("PRO")}
              disabled={locked}
              className={`flex-1 items-center justify-center gap-1 rounded-lg border-2 border-black py-1.5 font-display text-xs font-extrabold uppercase tracking-wide transition-all disabled:opacity-40 ${
                mode === "PRO"
                  ? "bg-black text-white shadow-hard"
                  : "bg-white text-black hover:bg-[#f0f9ff]"
              }`}
            >
              <Sparkles size={11} className="inline mr-1 text-[#7dd3fc]" />
              Pro Recency
            </button>
          </div>
        </div>

        {/* Execution Duration */}
        <div>
          <label className="mb-1.5 block font-mono text-[11px] font-extrabold uppercase tracking-wider text-[#5c636b]">
            Analysis Duration
          </label>
          <div className="flex items-center rounded-lg border-2 border-black bg-[#f4f6f8] px-3 py-1.5 font-mono text-xs font-bold text-black">
            <span>{duration}s tick sample scan</span>
          </div>
        </div>
      </div>
    </div>
  );
};
