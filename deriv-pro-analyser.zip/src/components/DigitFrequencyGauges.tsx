import React, { useMemo } from "react";
import { BarChart3 } from "lucide-react";
import { Tick } from "../types";
import { calculateDistribution } from "../utils/analysis";

interface DigitFrequencyGaugesProps {
  ticks: Tick[];
  recentWindow?: number;
}

const RADIUS = 25;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

export const DigitFrequencyGauges: React.FC<DigitFrequencyGaugesProps> = ({
  ticks,
  recentWindow = 25,
}) => {
  const distribution = useMemo(
    () => calculateDistribution(ticks, recentWindow),
    [ticks, recentWindow]
  );

  const hasTicks = ticks.length > 0;
  const lastTick = hasTicks ? ticks[ticks.length - 1] : null;
  const lastDigit = lastTick ? lastTick.digit : null;

  const highestDigit = useMemo(() => {
    return distribution.reduce(
      (max, d) => (d.percentage > max.percentage ? d : max),
      distribution[0]
    );
  }, [distribution]);

  const lowestDigit = useMemo(() => {
    return distribution.reduce(
      (min, d) => (d.percentage < min.percentage ? d : min),
      distribution[0]
    );
  }, [distribution]);

  return (
    <div className="glass-card p-4 sm:p-5">
      <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-lg border-2 border-black bg-[#0ea5e9] text-black">
            <BarChart3 size={17} />
          </span>
          <div>
            <h3 className="font-display font-extrabold uppercase tracking-wide text-black">
              Digit Frequency
            </h3>
            <p className="font-mono text-xs font-bold text-[#5c636b]">
              <span>{ticks.length}</span> ticks · last{" "}
              {Math.min(recentWindow, ticks.length)} highlighted
            </p>
          </div>
        </div>

        {hasTicks && (
          <div className="flex items-center gap-2 text-xs font-bold font-mono">
            <span className="rounded-md border border-black bg-[#f0f9ff] px-2 py-1 text-[#0369a1]">
              High: Digit {highestDigit.digit} ({highestDigit.percentage.toFixed(1)}%)
            </span>
            <span className="rounded-md border border-black bg-[#f4f6f8] px-2 py-1 text-[#5c636b]">
              Low: Digit {lowestDigit.digit} ({lowestDigit.percentage.toFixed(1)}%)
            </span>
          </div>
        )}
      </div>

      {/* 10 Circular Gauges */}
      <div className="grid grid-cols-5 gap-2 sm:grid-cols-10 sm:gap-3">
        {distribution.map((item) => {
          const isLast = item.digit === lastDigit;
          const isHigh = item.digit === highestDigit.digit && hasTicks;
          const isLow = item.digit === lowestDigit.digit && hasTicks;

          // Normalized offset (scale up to ~30% for visual effect)
          const pct = Math.min(100, Math.max(0, item.percentage));
          const strokeDashoffset = CIRCUMFERENCE - (pct / 30) * CIRCUMFERENCE;

          const strokeColor = isLast
            ? "#ffffff"
            : isHigh
            ? "#0ea5e9"
            : isLow
            ? "#c3c8cf"
            : "#38bdf8";

          return (
            <div
              key={item.digit}
              className="flex flex-col items-center select-none"
            >
              <div
                className={`relative flex h-14 w-14 items-center justify-center rounded-full border-2 transition-all sm:h-16 sm:w-16 ${
                  isLast
                    ? "border-black bg-black shadow-hard"
                    : "border-black bg-white"
                }`}
              >
                <svg
                  viewBox="0 0 64 64"
                  className="absolute inset-0 h-full w-full -rotate-90"
                  aria-hidden="true"
                >
                  <circle
                    cx="32"
                    cy="32"
                    r={RADIUS}
                    fill="none"
                    strokeWidth="5"
                    className={isLast ? "stroke-white/20" : "stroke-[#e6e9ed]"}
                  />
                  <circle
                    cx="32"
                    cy="32"
                    r={RADIUS}
                    fill="none"
                    strokeWidth="5"
                    strokeLinecap="round"
                    stroke={strokeColor}
                    strokeDasharray={`${CIRCUMFERENCE} ${CIRCUMFERENCE}`}
                    style={{
                      strokeDashoffset: Math.max(0, strokeDashoffset),
                      transition: "stroke-dashoffset 400ms ease-out",
                    }}
                  />
                </svg>

                <div className="relative flex flex-col items-center leading-none">
                  <span
                    className={`font-mono text-base font-extrabold sm:text-xl ${
                      isLast ? "text-white" : "text-black"
                    }`}
                  >
                    {item.digit}
                  </span>
                  <span
                    className={`mt-0.5 font-mono text-[9px] font-extrabold tabular-nums sm:text-[11px] ${
                      isLast
                        ? "text-white/80"
                        : isHigh
                        ? "text-[#0369a1]"
                        : "text-[#5c636b]"
                    }`}
                  >
                    {item.percentage.toFixed(1)}%
                  </span>
                </div>
              </div>

              {/* Triangle pointer under latest tick digit */}
              <div className="mt-1 flex h-3 items-start justify-center">
                {isLast && (
                  <svg
                    width="11"
                    height="7"
                    viewBox="0 0 11 7"
                    className="animate-ticker-in text-[#0ea5e9]"
                    aria-hidden="true"
                  >
                    <path d="M5.5 0 L11 7 L0 7 Z" fill="currentColor" />
                  </svg>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Legend */}
      <div className="mt-3 flex flex-wrap items-center justify-center gap-x-4 gap-y-1.5 border-t-2 border-[#e6e9ed] pt-3 font-mono text-[10px] font-bold uppercase tracking-wide text-[#5c636b]">
        <span className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-[#0ea5e9]" /> Highest
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-[#38bdf8]" /> Normal
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-[#c3c8cf]" /> Lowest
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-black" /> Last tick
        </span>
      </div>
    </div>
  );
};
