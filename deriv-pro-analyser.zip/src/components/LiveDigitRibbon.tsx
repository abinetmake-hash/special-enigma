import React, { useEffect, useMemo, useRef, useState } from "react";
import { Activity, Radio } from "lucide-react";
import { Tick } from "../types";

interface LiveDigitRibbonProps {
  ticks: Tick[];
  symbol: string;
  marketName: string;
  status: "connecting" | "open" | "closed" | "error";
  span?: number;
}

export const LiveDigitRibbon: React.FC<LiveDigitRibbonProps> = ({
  ticks,
  symbol,
  marketName,
  status,
  span = 18,
}) => {
  const isLive = status === "open";
  const lastTick = ticks.length ? ticks[ticks.length - 1] : null;
  const recentTicks = useMemo(() => ticks.slice(-span), [ticks, span]);

  const [flashing, setFlashing] = useState(false);
  const lastEpochRef = useRef<number | null>(null);

  useEffect(() => {
    if (lastTick) {
      if (lastEpochRef.current !== null && lastTick.epoch !== lastEpochRef.current) {
        setFlashing(true);
        const timer = setTimeout(() => setFlashing(false), 320);
        lastEpochRef.current = lastTick.epoch;
        return () => clearTimeout(timer);
      }
      lastEpochRef.current = lastTick.epoch;
    }
  }, [lastTick]);

  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const latencySec = lastTick
    ? Math.max(0, Math.floor(now / 1000 - lastTick.epoch))
    : null;
  const isStalled = latencySec != null && latencySec > 8;

  const tickRate = useMemo(() => {
    if (ticks.length < 2) return 0;
    const window = ticks.slice(-30);
    const duration = window[window.length - 1].epoch - window[0].epoch;
    return duration > 0 ? window.length / duration : 0;
  }, [ticks]);

  return (
    <div className="glass-card overflow-hidden">
      <div className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between sm:p-5">
        {/* Left: Market & Live Price */}
        <div className="flex items-center gap-3">
          <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border-2 border-black bg-[#0ea5e9] text-black shadow-hard">
            <Radio size={20} className={isLive ? "animate-pulse-slow" : ""} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display text-base font-extrabold uppercase tracking-wide text-black">
                {marketName}
              </span>
              <span className="rounded-md border border-black bg-[#f4f6f8] px-1.5 py-0.5 font-mono text-[10px] font-bold text-[#5c636b]">
                {symbol}
              </span>
            </div>
            <div className="mt-0.5 flex items-center gap-2 font-mono text-xs font-bold text-[#5c636b]">
              <span>
                Quote:{" "}
                <span className="text-black">
                  {lastTick ? lastTick.quote.toFixed(ticks[0] ? 4 : 2) : "—"}
                </span>
              </span>
              {latencySec != null && (
                <span
                  className={
                    isStalled ? "text-rose-600 font-bold" : "text-[#5c636b]"
                  }
                >
                  · {latencySec}s ago
                </span>
              )}
              {tickRate > 0 && (
                <span>· {tickRate.toFixed(1)} t/s</span>
              )}
            </div>
          </div>
        </div>

        {/* Right: Last Digits Strip */}
        <div className="min-w-0 flex-1 sm:max-w-md md:max-w-lg lg:max-w-xl">
          <div className="mb-1 flex items-center justify-between">
            <span className="font-mono text-[10px] font-extrabold uppercase tracking-[0.2em] text-[#5c636b]">
              Last {recentTicks.length} Digits
            </span>
            {lastTick && (
              <span className="font-mono text-[10px] font-bold text-[#0369a1]">
                Latest: <strong className="text-sm font-extrabold">{lastTick.digit}</strong>
              </span>
            )}
          </div>

          <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
            {recentTicks.length === 0 ? (
              <div className="flex h-9 items-center font-mono text-xs text-[#8e959e]">
                Waiting for tick stream...
              </div>
            ) : (
              recentTicks.map((t, idx) => {
                const isLatest = idx === recentTicks.length - 1;
                const isEven = t.digit % 2 === 0;

                return (
                  <div
                    key={`${t.epoch}-${idx}`}
                    className={`relative grid h-9 w-9 shrink-0 place-items-center rounded-lg border-2 font-mono text-sm font-extrabold transition-all duration-150 ${
                      isLatest
                        ? `border-black bg-black text-white shadow-hard ${
                            flashing ? "scale-110 bg-[#0ea5e9] text-black" : ""
                          }`
                        : isEven
                        ? "border-black bg-[#f0f9ff] text-black hover:bg-[#e0f2fe]"
                        : "border-black bg-white text-black hover:bg-[#f4f6f8]"
                    }`}
                  >
                    {t.digit}
                    {isLatest && (
                      <span className="absolute -top-1 -right-1 h-2.5 w-2.5 rounded-full bg-[#0ea5e9] ring-2 ring-white" />
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
