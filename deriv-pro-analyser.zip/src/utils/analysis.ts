import {
  AnalysisResult,
  DigitDistribution,
  ScannerMarketRank,
  Tick,
} from "../types";

export function extractLastDigit(
  price: number | string,
  pipSize?: number
): number {
  let n = pipSize;
  if (n == null || !Number.isFinite(n)) {
    const s = String(price);
    const dot = s.indexOf(".");
    n = dot === -1 ? 0 : s.length - dot - 1;
  }
  const formatted = Number(price).toFixed(Math.max(0, Math.round(n)));
  const lastChar = formatted[formatted.length - 1];
  const digit = parseInt(lastChar, 10);
  return Number.isNaN(digit) ? 0 : digit;
}

export function calculateDistribution(
  ticks: Tick[],
  recentWindow: number = 20
): DigitDistribution[] {
  const counts = new Array(10).fill(0);
  ticks.forEach((t) => counts[t.digit]++);

  const total = ticks.length || 1;
  const recentCounts = new Array(10).fill(0);
  const recentTicks = ticks.slice(-recentWindow);
  recentTicks.forEach((t) => recentCounts[t.digit]++);
  const recentTotal = recentTicks.length || 1;

  const baseline = total / 10;
  const result: DigitDistribution[] = [];

  for (let d = 0; d < 10; d++) {
    const c = counts[d];
    const pct = ticks.length ? (c / total) * 100 : 0;
    const diff = c - baseline;
    const status: "high" | "low" | "normal" =
      diff > baseline * 0.15 ? "high" : diff < -baseline * 0.15 ? "low" : "normal";

    result.push({
      digit: d,
      count: c,
      percentage: pct,
      recentCount: recentCounts[d],
      recentPercentage: recentTicks.length
        ? (recentCounts[d] / recentTotal) * 100
        : 0,
      status,
    });
  }

  return result;
}

export function calculatePercentages(ticks: Tick[]): number[] {
  const counts = new Array(10).fill(0);
  ticks.forEach((t) => counts[t.digit]++);
  const n = ticks.length;
  return counts.map((c) => (n ? (c / n) * 100 : 0));
}

export function countDistributionRecord(ticks: Tick[]): Record<string, number> {
  const counts = new Array(10).fill(0);
  ticks.forEach((t) => counts[t.digit]++);
  const record: Record<string, number> = {};
  for (let i = 0; i < 10; i++) {
    record[String(i)] = counts[i];
  }
  return record;
}

export function chiSquareDeviation(counts: number[], sampleSize: number): number {
  if (!sampleSize) return 0;
  const expected = sampleSize / 10;
  let sum = 0;
  for (let i = 0; i < 10; i++) {
    const diff = counts[i] - expected;
    sum += (diff * diff) / expected;
  }
  return sum;
}

export function shrinkageProbability(
  sampleRate: number,
  prior: number,
  sampleSize: number,
  priorWeight: number = 40
): number {
  if (sampleSize <= 0) return prior;
  return (
    (sampleRate * sampleSize + prior * priorWeight) /
    (sampleSize + priorWeight)
  );
}

export function boundConfidence(value: number): number {
  return Math.min(95, Math.max(50, Math.round(value * 10) / 10));
}

export function roundTenth(n: number): number {
  return Math.round(n * 10) / 10;
}

export function detectPattern(ticks: Tick[]): string {
  if (ticks.length < 4) return "Insufficient data";
  const lastFour = ticks.slice(-4).map((t) => t.digit);
  if (lastFour.every((d) => d === lastFour[0])) {
    return `Repeated ${lastFour[0]} (x${lastFour.length})`;
  }
  const isRising = lastFour.every((d, i) => i === 0 || d >= lastFour[i - 1]);
  const isFalling = lastFour.every((d, i) => i === 0 || d <= lastFour[i - 1]);
  if (isRising) return "Rising sequence";
  if (isFalling) return "Falling sequence";
  return "Mixed distribution";
}

function emptyAnalysisResult(
  indication: "MATCH" | "DIFFER" | "EVEN" | "ODD" | "OVER" | "UNDER",
  explanation: string
): AnalysisResult {
  return {
    indication,
    predictedDigit: null,
    predictedDigitPercentage: null,
    unrestrictedDigit: null,
    unrestrictedDigitPercentage: null,
    confidence: 50,
    winProbability: 50,
    explanation,
    distribution: {},
    percentages: new Array(10).fill(0),
    outcomes: [],
    evenCount: 0,
    oddCount: 0,
    sampleSize: 0,
    pattern: "Insufficient data",
    topDigits: [],
    lowDigits: [],
  };
}

export function calculateMatchesDiffers(
  ticks: Tick[],
  mode: string = "STANDARD",
  allowedDigits: number[] = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
): AnalysisResult {
  if (ticks.length < 10) {
    return emptyAnalysisResult(
      "DIFFER",
      "Not enough tick data yet. Wait for the stream to fill, then run again."
    );
  }

  const sampleSize = ticks.length;
  const fullCounts = new Array(10).fill(0);
  ticks.forEach((t) => fullCounts[t.digit]++);

  const pool = allowedDigits.length
    ? [...allowedDigits]
    : [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];

  let evalTicks = ticks;
  if (mode === "PRO" && ticks.length > 20) {
    evalTicks = ticks.slice(-Math.ceil(ticks.length * 0.6));
  }

  const evalCounts = new Array(10).fill(0);
  evalTicks.forEach((t) => evalCounts[t.digit]++);
  const activeCounts = mode === "PRO" ? evalCounts : fullCounts;

  let unrestrictedMaxDigit = 0;
  for (let i = 1; i < 10; i++) {
    if (activeCounts[i] > activeCounts[unrestrictedMaxDigit]) {
      unrestrictedMaxDigit = i;
    }
  }

  let selectedDigit = pool[0];
  for (const d of pool) {
    if (activeCounts[d] > activeCounts[selectedDigit]) {
      selectedDigit = d;
    }
  }

  const percentages = calculatePercentages(ticks);
  const sampleRate = percentages[selectedDigit];
  const winProbMatch =
    shrinkageProbability(sampleRate / 100, 0.1, sampleSize) * 100;
  const winProbDiffer = 100 - winProbMatch;

  const indication: "MATCH" | "DIFFER" =
    winProbMatch > 13 ? "MATCH" : "DIFFER";
  const winProbability = roundTenth(
    indication === "MATCH" ? winProbMatch : winProbDiffer
  );

  const chiSquare = chiSquareDeviation(fullCounts, sampleSize);
  const confidence = boundConfidence(50 + (chiSquare / 25) * 45);

  const evenCount = ticks.filter((t) => t.digit % 2 === 0).length;
  const oddCount = sampleSize - evenCount;

  const sortedDigits = fullCounts
    .map((c, d) => ({ d, c }))
    .sort((a, b) => b.c - a.c);
  const topDigits = sortedDigits.slice(0, 3).map((item) => item.d);
  const lowDigits = sortedDigits.slice(-3).map((item) => item.d);

  const outcomes = [
    {
      label: `MATCH ${selectedDigit}`,
      count: fullCounts[selectedDigit],
      percentage: roundTenth(winProbMatch),
    },
    {
      label: `DIFFER ${selectedDigit}`,
      count: sampleSize - fullCounts[selectedDigit],
      percentage: roundTenth(winProbDiffer),
    },
  ];

  const explanation =
    indication === "MATCH"
      ? `Digit ${selectedDigit} has the highest appearance rate in this sample (${sampleRate.toFixed(
          1
        )}% of ${sampleSize} ticks, versus a 10.0% baseline). Estimated chance the next digit repeats it: ${winProbMatch.toFixed(
          1
        )}%.`
      : `Digit ${selectedDigit} appears most often (${sampleRate.toFixed(
          1
        )}% of ${sampleSize} ticks) but not far enough above the 10.0% baseline to favour a repeat. Estimated chance the next digit differs from it: ${winProbDiffer.toFixed(
          1
        )}%.`;

  return {
    indication,
    predictedDigit: selectedDigit,
    predictedDigitPercentage: roundTenth(sampleRate),
    unrestrictedDigit: unrestrictedMaxDigit,
    unrestrictedDigitPercentage: roundTenth(percentages[unrestrictedMaxDigit]),
    confidence,
    winProbability,
    explanation,
    distribution: countDistributionRecord(ticks),
    percentages,
    outcomes,
    evenCount,
    oddCount,
    sampleSize,
    pattern: detectPattern(ticks),
    topDigits,
    lowDigits,
  };
}

export function calculateEvenOdd(ticks: Tick[]): AnalysisResult {
  if (ticks.length < 10) {
    return emptyAnalysisResult(
      "EVEN",
      "Not enough tick data yet. Wait for the stream to fill, then run again."
    );
  }

  const sampleSize = ticks.length;
  const evenCount = ticks.filter((t) => t.digit % 2 === 0).length;
  const oddCount = sampleSize - evenCount;

  const evenRate = evenCount / sampleSize;
  const evenProb = shrinkageProbability(evenRate, 0.5, sampleSize) * 100;
  const oddProb = 100 - evenProb;

  const indication: "EVEN" | "ODD" = evenProb >= oddProb ? "EVEN" : "ODD";
  const winProbability = roundTenth(Math.max(evenProb, oddProb));
  const confidence = boundConfidence(50 + Math.abs(evenProb - 50) * 3);

  const outcomes = [
    {
      label: "EVEN",
      count: evenCount,
      percentage: roundTenth(evenRate * 100),
    },
    {
      label: "ODD",
      count: oddCount,
      percentage: roundTenth((oddCount / sampleSize) * 100),
    },
  ];

  const explanation =
    indication === "EVEN"
      ? `Even digits lead this sample: ${evenCount} of ${sampleSize} ticks (${(
          evenRate * 100
        ).toFixed(
          1
        )}%). Estimated chance the next digit is even: ${evenProb.toFixed(1)}%.`
      : `Odd digits lead this sample: ${oddCount} of ${sampleSize} ticks (${(
          (oddCount / sampleSize) *
          100
        ).toFixed(
          1
        )}%). Estimated chance the next digit is odd: ${oddProb.toFixed(1)}%.`;

  return {
    indication,
    predictedDigit: null,
    predictedDigitPercentage: null,
    unrestrictedDigit: null,
    unrestrictedDigitPercentage: null,
    confidence,
    winProbability,
    explanation,
    distribution: countDistributionRecord(ticks),
    percentages: calculatePercentages(ticks),
    outcomes,
    evenCount,
    oddCount,
    sampleSize,
    pattern: detectPattern(ticks),
    topDigits: [],
    lowDigits: [],
  };
}

export function calculateOverUnder(
  ticks: Tick[],
  entryDigit: number
): AnalysisResult {
  const barrier = Math.min(9, Math.max(0, Math.round(entryDigit)));
  if (ticks.length < 10) {
    return emptyAnalysisResult(
      "OVER",
      "Not enough tick data yet. Wait for the stream to fill, then run again."
    );
  }

  const sampleSize = ticks.length;
  const overCount = ticks.filter((t) => t.digit > barrier).length;
  const underCount = ticks.filter((t) => t.digit < barrier).length;
  const equalCount = sampleSize - overCount - underCount;

  const overRate = overCount / sampleSize;
  const underRate = underCount / sampleSize;
  const equalRate = equalCount / sampleSize;

  const overBaseline = (9 - barrier) / 10;
  const underBaseline = barrier / 10;

  const overProb =
    shrinkageProbability(overRate, overBaseline, sampleSize) * 100;
  const underProb =
    shrinkageProbability(underRate, underBaseline, sampleSize) * 100;

  const overDiff = overProb - overBaseline * 100;
  const underDiff = underProb - underBaseline * 100;

  const indication: "OVER" | "UNDER" = overProb >= underProb ? "OVER" : "UNDER";
  const winProbability = roundTenth(indication === "OVER" ? overProb : underProb);
  const diffEdge = indication === "OVER" ? overDiff : underDiff;

  const dampener = Math.min(1, sampleSize / 100);
  const confidence = boundConfidence(50 + Math.max(0, diffEdge) * 3.2 * dampener);

  const outcomes = [
    {
      label: `OVER ${barrier}`,
      count: overCount,
      percentage: roundTenth(overRate * 100),
    },
    {
      label: `UNDER ${barrier}`,
      count: underCount,
      percentage: roundTenth(underRate * 100),
    },
    {
      label: `EQUALS ${barrier}`,
      count: equalCount,
      percentage: roundTenth(equalRate * 100),
    },
  ];

  const baselinePct = (
    (indication === "OVER" ? overBaseline : underBaseline) * 100
  ).toFixed(0);

  const edgeText =
    diffEdge > 0.5
      ? `${diffEdge.toFixed(1)} points above its ${baselinePct}% baseline`
      : `in line with its ${baselinePct}% baseline, so this sample shows no real edge`;

  const explanation =
    indication === "OVER"
      ? `Over ${barrier}: ${overCount} of ${sampleSize} ticks (${(
          overRate * 100
        ).toFixed(1)}%). Under ${barrier}: ${underCount} (${(
          underRate * 100
        ).toFixed(1)}%). Ties on ${barrier}: ${equalCount} (${(
          equalRate * 100
        ).toFixed(
          1
        )}%), which lose both contracts. Estimated win rate for OVER ${barrier} is ${overProb.toFixed(
          1
        )}%, ${edgeText}.`
      : `Under ${barrier}: ${underCount} of ${sampleSize} ticks (${(
          underRate * 100
        ).toFixed(1)}%). Over ${barrier}: ${overCount} (${(
          overRate * 100
        ).toFixed(1)}%). Ties on ${barrier}: ${equalCount} (${(
          equalRate * 100
        ).toFixed(
          1
        )}%), which lose both contracts. Estimated win rate for UNDER ${barrier} is ${underProb.toFixed(
          1
        )}%, ${edgeText}.`;

  const evenCount = ticks.filter((t) => t.digit % 2 === 0).length;
  const oddCount = sampleSize - evenCount;

  return {
    indication,
    predictedDigit: barrier,
    predictedDigitPercentage: roundTenth(equalRate * 100),
    unrestrictedDigit: null,
    unrestrictedDigitPercentage: null,
    confidence,
    winProbability,
    explanation,
    distribution: countDistributionRecord(ticks),
    percentages: calculatePercentages(ticks),
    outcomes,
    evenCount,
    oddCount,
    sampleSize,
    pattern: `Barrier ${barrier}`,
    topDigits: [],
    lowDigits: [],
  };
}

export function rankMarketsByDeviation(
  marketTicksMap: Record<string, Tick[]>
): ScannerMarketRank[] {
  const ranked = Object.entries(marketTicksMap).map(([symbol, ticks]) => {
    const counts = new Array(10).fill(0);
    ticks.forEach((t) => counts[t.digit]++);
    const sample = ticks.length || 1;
    const score = chiSquareDeviation(counts, sample);

    let activity = 0;
    if (ticks.length > 1) {
      const duration = ticks[ticks.length - 1].epoch - ticks[0].epoch || 1;
      activity = sample / duration;
    }

    return {
      symbol,
      name: symbol,
      score,
      sample: ticks.length,
      activity,
    };
  });

  ranked.sort((a, b) => b.score - a.score);
  return ranked;
}

export function weightedRandomSelect(
  rankings: ScannerMarketRank[]
): ScannerMarketRank {
  if (!rankings.length) {
    throw new Error("No markets to select from");
  }
  const weights = rankings.map((_, i) => 1 / (i + 1));
  const totalWeight = weights.reduce((acc, w) => acc + w, 0);
  let randomVal = Math.random() * totalWeight;

  for (let i = 0; i < rankings.length; i++) {
    randomVal -= weights[i];
    if (randomVal <= 0) {
      return rankings[i];
    }
  }

  return rankings[rankings.length - 1];
}
