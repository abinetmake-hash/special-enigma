import React, { useState } from "react";
import { Loader2 } from "lucide-react";
import { PageId } from "./types";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { useDeriv, useMarketTicks } from "./hooks/useDeriv";
import { IntroSplash } from "./components/IntroSplash";
import { Header } from "./components/Header";
import { Sidebar } from "./components/Sidebar";
import { PublicLanding } from "./pages/PublicLanding";
import { DashboardView } from "./pages/DashboardView";
import { MatchesDiffersView } from "./pages/MatchesDiffersView";
import { EvenOddView } from "./pages/EvenOddView";
import { OverUnderView } from "./pages/OverUnderView";
import { ScannerView } from "./pages/ScannerView";
import { FrequencyView } from "./pages/FrequencyView";

function MainApp() {
  const { session, loading } = useAuth();
  const [currentPage, setCurrentPage] = useState<PageId>("dashboard");
  const [selectedSymbol, setSelectedSymbol] = useState("1HZ100V");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Hook for the global feed and active market ticks
  const { status, error, source, reconnect } = useDeriv([selectedSymbol], 600);
  const { ticks } = useMarketTicks(selectedSymbol);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-white">
        <div className="flex flex-col items-center gap-3">
          <Loader2 size={36} className="animate-spin text-[#0ea5e9]" />
          <p className="font-mono text-sm font-extrabold uppercase tracking-wide text-[#22272e]">
            Loading Deriv Pro Analyser...
          </p>
        </div>
      </div>
    );
  }

  // Not authenticated: Show Public Landing & Login page
  if (!session) {
    return <PublicLanding />;
  }

  // Authenticated App Shell
  const renderPage = () => {
    switch (currentPage) {
      case "matches":
        return (
          <MatchesDiffersView
            ticks={ticks}
            selectedSymbol={selectedSymbol}
            onSelectSymbol={setSelectedSymbol}
            feedStatus={status}
          />
        );
      case "evenodd":
        return (
          <EvenOddView
            ticks={ticks}
            selectedSymbol={selectedSymbol}
            onSelectSymbol={setSelectedSymbol}
            feedStatus={status}
          />
        );
      case "overunder":
        return (
          <OverUnderView
            ticks={ticks}
            selectedSymbol={selectedSymbol}
            onSelectSymbol={setSelectedSymbol}
            feedStatus={status}
          />
        );
      case "scanner":
        return (
          <ScannerView
            selectedSymbol={selectedSymbol}
            onSelectSymbol={setSelectedSymbol}
            feedStatus={status}
          />
        );
      case "frequency":
        return (
          <FrequencyView
            ticks={ticks}
            selectedSymbol={selectedSymbol}
            onSelectSymbol={setSelectedSymbol}
            feedStatus={status}
          />
        );
      case "dashboard":
      default:
        return (
          <DashboardView
            status={status}
            error={error}
            source={source}
            ticks={ticks}
            selectedSymbol={selectedSymbol}
            onSelectSymbol={setSelectedSymbol}
            onNavigate={setCurrentPage}
            onReconnect={reconnect}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#f4f6f8] text-black">
      {/* Sidebar Navigation */}
      <Sidebar
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex min-h-screen flex-col lg:pl-64">
        {/* Top Header */}
        <Header
          status={status}
          source={source}
          error={error}
          onReconnect={reconnect}
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
        />

        {/* Page View Container */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {renderPage()}
        </main>

        {/* Quiet Footer */}
        <footer className="border-t-2 border-[#e6e9ed] bg-white px-4 py-4 text-center">
          <p className="font-mono text-xs font-bold text-[#5c636b]">
            © {new Date().getFullYear()} Deriv Pro Analyser. Statistical analysis
            only. Not financial advice.
          </p>
        </footer>
      </div>
    </div>
  );
}

export default function App() {
  const [showSplash, setShowSplash] = useState(true);

  return (
    <AuthProvider>
      {showSplash && <IntroSplash onDone={() => setShowSplash(false)} />}
      <MainApp />
    </AuthProvider>
  );
}
