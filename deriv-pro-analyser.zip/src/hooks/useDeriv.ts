import { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { derivClient } from "../services/derivClient";
import { AnalysisResult, FeedSnapshot, Tick } from "../types";

export function useDeriv(symbols: string[], bufferLimit: number = 200) {
  useEffect(() => {
    derivClient.start();
    const cleanups = symbols.map((s) => derivClient.watch(s));
    return () => {
      cleanups.forEach((c) => c());
    };
  }, [symbols]);

  const snapshot = useSyncExternalStore<FeedSnapshot>(
    derivClient.subscribe,
    derivClient.getSnapshot,
    derivClient.getSnapshot
  );

  const key = symbols.join(",");
  const ticks = useMemo(() => {
    const list = key
      .split(",")
      .filter(Boolean)
      .flatMap((s) => derivClient.getBook(s).ticks);
    if (symbols.length > 1) {
      list.sort((a, b) => a.epoch - b.epoch);
    }
    return list.slice(-bufferLimit);
  }, [snapshot.version, key, bufferLimit, symbols.length]);

  const reconnect = useCallback(() => derivClient.reconnect(), []);
  const ticksFor = useCallback(
    (sym: string) => derivClient.getBook(sym).ticks,
    []
  );

  const error = useMemo(() => {
    return (
      snapshot.error ??
      key
        .split(",")
        .filter(Boolean)
        .map((s) => derivClient.getBook(s).error)
        .find(Boolean) ??
      null
    );
  }, [snapshot.error, key]);

  return {
    status: snapshot.status,
    error,
    ticks,
    lastTick: ticks.length ? ticks[ticks.length - 1] : null,
    lastMessageAt: snapshot.lastMessageAt,
    source: snapshot.endpoint?.label ?? null,
    reconnect,
    ticksFor,
  };
}

export function useMarketTicks(symbol: string) {
  useEffect(() => {
    return derivClient.watch(symbol);
  }, [symbol]);

  const book = useSyncExternalStore(
    derivClient.subscribe,
    () => derivClient.getBook(symbol),
    () => derivClient.getBook(symbol)
  );

  return {
    ticks: book.ticks,
    seeding: book.state === "loading" && book.ticks.length === 0,
    error: book.error,
  };
}

export interface RunOptions {
  symbol: string;
  mode: string;
  sampleSize: number;
  entryDigit?: number | null;
  compute: (ticks: Tick[], mode: string, entryDigit?: number | null) => AnalysisResult;
  durationSec?: number;
}

export function useAnalysisRunner() {
  const [phase, setPhase] = useState<"ready" | "running" | "done">("ready");
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [locked, setLocked] = useState(false);

  const intervalRef = useRef<NodeJS.Timeout | number | null>(null);
  const timeoutRef = useRef<NodeJS.Timeout | number | null>(null);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  const run = useCallback(
    async ({
      symbol,
      mode,
      sampleSize,
      entryDigit,
      compute,
      durationSec = 4,
    }: RunOptions) => {
      setPhase("running");
      setLocked(true);
      setResult(null);
      setError(null);
      setProgress(0);

      if (intervalRef.current) clearInterval(intervalRef.current);
      intervalRef.current = setInterval(() => {
        setProgress((prev) => Math.min(prev + 100 / (durationSec * 10), 99));
      }, 100);

      const startTime = Date.now();
      try {
        const historyTicks = await derivClient.history(
          symbol,
          Math.max(sampleSize, 120)
        );
        const slicedTicks = historyTicks.slice(-sampleSize);
        const computed = compute(slicedTicks, mode, entryDigit ?? null);

        const elapsed = Date.now() - startTime;
        const remainingDelay = Math.max(0, durationSec * 1000 - elapsed);
        await new Promise((resolve) => setTimeout(resolve, remainingDelay));

        if (!mountedRef.current) return;
        setResult(computed);
      } catch (err: any) {
        if (!mountedRef.current) return;
        setError(
          err instanceof Error ? err.message : "Could not reach the Deriv tick feed."
        );
      } finally {
        if (intervalRef.current) clearInterval(intervalRef.current);
        if (mountedRef.current) {
          setProgress(100);
          setPhase("done");
          timeoutRef.current = setTimeout(() => {
            setLocked(false);
          }, 600);
        }
      }
    },
    []
  );

  const reset = useCallback(() => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    setPhase("ready");
    setProgress(0);
    setResult(null);
    setError(null);
    setLocked(false);
  }, []);

  return {
    phase,
    progress,
    result,
    error,
    locked,
    run,
    reset,
  };
}
