import { Market } from "./types";

export const MARKETS: Market[] = [
  { symbol: "R_10", name: "Volatility 10 Index" },
  { symbol: "R_25", name: "Volatility 25 Index" },
  { symbol: "R_50", name: "Volatility 50 Index" },
  { symbol: "R_75", name: "Volatility 75 Index" },
  { symbol: "R_100", name: "Volatility 100 Index" },
  { symbol: "1HZ10V", name: "Volatility 10 (1s) Index" },
  { symbol: "1HZ25V", name: "Volatility 25 (1s) Index" },
  { symbol: "1HZ50V", name: "Volatility 50 (1s) Index" },
  { symbol: "1HZ75V", name: "Volatility 75 (1s) Index" },
  { symbol: "1HZ100V", name: "Volatility 100 (1s) Index" },
];

export const PREDICTION_DIGITS = [1, 2, 3, 4, 5];
export const ALL_DIGITS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];

export const DEFAULT_DURATION_SEC = 4;
export const DEFAULT_SAMPLE_SIZE = 120;
export const SAMPLE_SIZE_OPTIONS = [25, 50, 100, 120, 200, 500, 1000];

export const PIPELINE_STAGES = [
  "Subscribe to Deriv tick stream",
  "Extract last digit at native pip size",
  "Build digit frequency table",
  "Measure deviation from uniform baseline",
  "Estimate win probability",
  "Score model confidence",
  "Emit prediction",
];

export const WHATSAPP_PHONE = "254700523688";
export const RNGTRADER_URL = "https://rngtrader.site";

export function getWhatsAppUrl(text: string): string {
  return `https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(text)}`;
}

export function openPurchaseWhatsApp(): void {
  window.open(
    getWhatsAppUrl("I want to purchase the derivproanalyzer for 115$"),
    "_blank",
    "noopener,noreferrer"
  );
}

export function openBotPurchaseWhatsApp(): void {
  window.open(
    getWhatsAppUrl(
      "I want to pay 55 dollars for derivproanalyzer synchronised pro bot"
    ),
    "_blank",
    "noopener,noreferrer"
  );
}
