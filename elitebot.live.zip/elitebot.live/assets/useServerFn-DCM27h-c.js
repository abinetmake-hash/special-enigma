import {
    w as a,
    r as i,
    x as e
} from "./index-CELiIWTZ.js";

function c(o) {
    const t = a();
    return i.useCallback(async (...s) => {
        try {
            const r = await o(...s);
            if (e(r)) throw r;
            return r
        } catch (r) {
            if (e(r)) return r.options._fromLocation = t.stores.location.get(), t.navigate(t.resolveRedirect(r).options);
            throw r
        }
    }, [t, o])
}
export {
    c as u
};