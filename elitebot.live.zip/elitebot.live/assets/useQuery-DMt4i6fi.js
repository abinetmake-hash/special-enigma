import {
    S as G,
    p as N,
    d as u,
    e as Q,
    f as g,
    n as M,
    g as x,
    i as B,
    h as J,
    k as C,
    l as X,
    m as Y,
    o as A,
    q as z,
    r as d,
    v as V,
    a as Z
} from "./index-CELiIWTZ.js";
var $ = class extends G {
    constructor(t, e) {
        super(), this.options = e, this.#s = t, this.#r = null, this.#i = N(), this.bindMethods(), this.setOptions(e)
    }#
    s;#
    t = void 0;#
    p = void 0;#
    e = void 0;#
    a;#
    u;#
    i;#
    r;#
    v;#
    l;#
    d;#
    o;#
    h;#
    n;#
    f = new Set;
    bindMethods() {
        this.refetch = this.refetch.bind(this)
    }
    onSubscribe() {
        this.listeners.size === 1 && (this.#t.addObserver(this), j(this.#t, this.options) ? this.#c() : this.updateResult(), this.#g())
    }
    onUnsubscribe() {
        this.hasListeners() || this.destroy()
    }
    shouldFetchOnReconnect() {
        return _(this.#t, this.options, this.options.refetchOnReconnect)
    }
    shouldFetchOnWindowFocus() {
        return _(this.#t, this.options, this.options.refetchOnWindowFocus)
    }
    destroy() {
        this.listeners = new Set, this.#y(), this.#S(), this.#t.removeObserver(this)
    }
    setOptions(t) {
        const e = this.options,
            s = this.#t;
        if (this.options = this.#s.defaultQueryOptions(t), this.options.enabled !== void 0 && typeof this.options.enabled != "boolean" && typeof this.options.enabled != "function" && typeof u(this.options.enabled, this.#t) != "boolean") throw new Error("Expected enabled to be a boolean or a callback that returns a boolean");
        this.#O(), this.#t.setOptions(this.options), e._defaulted && !Q(this.options, e) && this.#s.getQueryCache().notify({
            type: "observerOptionsUpdated",
            query: this.#t,
            observer: this
        });
        const i = this.hasListeners();
        i && H(this.#t, s, this.options, e) && this.#c(), this.updateResult(), i && (this.#t !== s || u(this.options.enabled, this.#t) !== u(e.enabled, this.#t) || g(this.options.staleTime, this.#t) !== g(e.staleTime, this.#t)) && this.#R();
        const r = this.#b();
        i && (this.#t !== s || u(this.options.enabled, this.#t) !== u(e.enabled, this.#t) || r !== this.#n) && this.#m(r)
    }
    getOptimisticResult(t) {
        const e = this.#s.getQueryCache().build(this.#s, t),
            s = this.createResult(e, t);
        return tt(this, s) && (this.#e = s, this.#u = this.options, this.#a = this.#t.state), s
    }
    getCurrentResult() {
        return this.#e
    }
    trackResult(t, e) {
        return new Proxy(t, {
            get: (s, i) => (this.trackProp(i), e ? .(i), i === "promise" && (this.trackProp("data"), !this.options.experimental_prefetchInRender && this.#i.status === "pending" && this.#i.reject(new Error("experimental_prefetchInRender feature flag is not enabled"))), Reflect.get(s, i))
        })
    }
    trackProp(t) {
        this.#f.add(t)
    }
    getCurrentQuery() {
        return this.#t
    }
    refetch({ ...t
    } = {}) {
        return this.fetch({ ...t
        })
    }
    fetchOptimistic(t) {
        const e = this.#s.defaultQueryOptions(t),
            s = this.#s.getQueryCache().build(this.#s, e);
        return s.fetch().then(() => this.createResult(s, e))
    }
    fetch(t) {
        return this.#c({ ...t,
            cancelRefetch: t.cancelRefetch ? ? !0
        }).then(() => (this.updateResult(), this.#e))
    }#
    c(t) {
        this.#O();
        let e = this.#t.fetch(this.options, t);
        return t ? .throwOnError || (e = e.catch(M)), e
    }#
    R() {
        this.#y();
        const t = g(this.options.staleTime, this.#t);
        if (x.isServer() || this.#e.isStale || !B(t)) return;
        const s = J(this.#e.dataUpdatedAt, t) + 1;
        this.#o = C.setTimeout(() => {
            this.#e.isStale || this.updateResult()
        }, s)
    }#
    b() {
        return (typeof this.options.refetchInterval == "function" ? this.options.refetchInterval(this.#t) : this.options.refetchInterval) ? ? !1
    }#
    m(t) {
        this.#S(), this.#n = t, !(x.isServer() || u(this.options.enabled, this.#t) === !1 || !B(this.#n) || this.#n === 0) && (this.#h = C.setInterval(() => {
            (this.options.refetchIntervalInBackground || X.isFocused()) && this.#c()
        }, this.#n))
    }#
    g() {
        this.#R(), this.#m(this.#b())
    }#
    y() {
        this.#o !== void 0 && (C.clearTimeout(this.#o), this.#o = void 0)
    }#
    S() {
        this.#h !== void 0 && (C.clearInterval(this.#h), this.#h = void 0)
    }
    createResult(t, e) {
        const s = this.#t,
            i = this.options,
            r = this.#e,
            l = this.#a,
            n = this.#u,
            R = t !== s ? t.state : this.#p,
            {
                state: h
            } = t;
        let a = { ...h
            },
            b = !1,
            o;
        if (e._optimisticResults) {
            const c = this.hasListeners(),
                m = !c && j(t, e),
                S = c && H(t, s, e, i);
            (m || S) && (a = { ...a,
                ...Y(h.data, t.options)
            }), e._optimisticResults === "isRestoring" && (a.fetchStatus = "idle")
        }
        let {
            error: y,
            errorUpdatedAt: F,
            status: v
        } = a;
        o = a.data;
        let U = !1;
        if (e.placeholderData !== void 0 && o === void 0 && v === "pending") {
            let c;
            r ? .isPlaceholderData && e.placeholderData === n ? .placeholderData ? (c = r.data, U = !0) : c = typeof e.placeholderData == "function" ? e.placeholderData(this.#d ? .state.data, this.#d) : e.placeholderData, c !== void 0 && (v = "success", o = A(r ? .data, c, e), b = !0)
        }
        if (e.select && o !== void 0 && !U)
            if (r && o === l ? .data && e.select === this.#v) o = this.#l;
            else try {
                this.#v = e.select, o = e.select(o), o = A(r ? .data, o, e), this.#l = o, this.#r = null
            } catch (c) {
                this.#r = c
            }
        this.#r && (y = this.#r, o = this.#l, F = Date.now(), v = "error");
        const I = a.fetchStatus === "fetching",
            T = v === "pending",
            w = v === "error",
            D = T && I,
            k = o !== void 0,
            p = {
                status: v,
                fetchStatus: a.fetchStatus,
                isPending: T,
                isSuccess: v === "success",
                isError: w,
                isInitialLoading: D,
                isLoading: D,
                data: o,
                dataUpdatedAt: a.dataUpdatedAt,
                error: y,
                errorUpdatedAt: F,
                failureCount: a.fetchFailureCount,
                failureReason: a.fetchFailureReason,
                errorUpdateCount: a.errorUpdateCount,
                isFetched: t.isFetched(),
                isFetchedAfterMount: a.dataUpdateCount > R.dataUpdateCount || a.errorUpdateCount > R.errorUpdateCount,
                isFetching: I,
                isRefetching: I && !T,
                isLoadingError: w && !k,
                isPaused: a.fetchStatus === "paused",
                isPlaceholderData: b,
                isRefetchError: w && k,
                isStale: P(t, e),
                refetch: this.refetch,
                promise: this.#i,
                isEnabled: u(e.enabled, t) !== !1
            };
        if (this.options.experimental_prefetchInRender) {
            const c = p.data !== void 0,
                m = p.status === "error" && !c,
                S = E => {
                    m ? E.reject(p.error) : c && E.resolve(p.data)
                },
                L = () => {
                    const E = this.#i = p.promise = N();
                    S(E)
                },
                O = this.#i;
            switch (O.status) {
                case "pending":
                    t.queryHash === s.queryHash && S(O);
                    break;
                case "fulfilled":
                    (m || p.data !== O.value) && L();
                    break;
                case "rejected":
                    (!m || p.error !== O.reason) && L();
                    break
            }
        }
        return p
    }
    updateResult() {
        const t = this.#e,
            e = this.createResult(this.#t, this.options);
        if (this.#a = this.#t.state, this.#u = this.options, this.#a.data !== void 0 && (this.#d = this.#t), Q(e, t)) return;
        this.#e = e;
        const s = () => {
            if (!t) return !0;
            const {
                notifyOnChangeProps: i
            } = this.options, r = typeof i == "function" ? i() : i;
            if (r === "all" || !r && !this.#f.size) return !0;
            const l = new Set(r ? ? this.#f);
            return this.options.throwOnError && l.add("error"), Object.keys(this.#e).some(n => {
                const f = n;
                return this.#e[f] !== t[f] && l.has(f)
            })
        };
        this.#E({
            listeners: s()
        })
    }#
    O() {
        const t = this.#s.getQueryCache().build(this.#s, this.options);
        if (t === this.#t) return;
        const e = this.#t;
        this.#t = t, this.#p = t.state, this.hasListeners() && (e ? .removeObserver(this), t.addObserver(this))
    }
    onQueryUpdate() {
        this.updateResult(), this.hasListeners() && this.#g()
    }#
    E(t) {
        z.batch(() => {
            t.listeners && this.listeners.forEach(e => {
                e(this.#e)
            }), this.#s.getQueryCache().notify({
                query: this.#t,
                type: "observerResultsUpdated"
            })
        })
    }
};

function q(t, e) {
    return u(e.enabled, t) !== !1 && t.state.data === void 0 && !(t.state.status === "error" && u(e.retryOnMount, t) === !1)
}

function j(t, e) {
    return q(t, e) || t.state.data !== void 0 && _(t, e, e.refetchOnMount)
}

function _(t, e, s) {
    if (u(e.enabled, t) !== !1 && g(e.staleTime, t) !== "static") {
        const i = typeof s == "function" ? s(t) : s;
        return i === "always" || i !== !1 && P(t, e)
    }
    return !1
}

function H(t, e, s, i) {
    return (t !== e || u(i.enabled, t) === !1) && (!s.suspense || t.state.status !== "error") && P(t, s)
}

function P(t, e) {
    return u(e.enabled, t) !== !1 && t.isStaleByTime(g(e.staleTime, t))
}

function tt(t, e) {
    return !Q(t.getCurrentResult(), e)
}
var K = d.createContext(!1),
    et = () => d.useContext(K);
K.Provider;

function st() {
    let t = !1;
    return {
        clearReset: () => {
            t = !1
        },
        reset: () => {
            t = !0
        },
        isReset: () => t
    }
}
var it = d.createContext(st()),
    rt = () => d.useContext(it),
    nt = (t, e, s) => {
        const i = s ? .state.error && typeof t.throwOnError == "function" ? V(t.throwOnError, [s.state.error, s]) : t.throwOnError;
        (t.suspense || t.experimental_prefetchInRender || i) && (e.isReset() || (t.retryOnMount = !1))
    },
    at = t => {
        d.useEffect(() => {
            t.clearReset()
        }, [t])
    },
    ot = ({
        result: t,
        errorResetBoundary: e,
        throwOnError: s,
        query: i,
        suspense: r
    }) => t.isError && !e.isReset() && !t.isFetching && i && (r && t.data === void 0 || V(s, [t.error, i])),
    ht = t => {
        if (t.suspense) {
            const s = r => r === "static" ? r : Math.max(r ? ? 1e3, 1e3),
                i = t.staleTime;
            t.staleTime = typeof i == "function" ? (...r) => s(i(...r)) : s(i), typeof t.gcTime == "number" && (t.gcTime = Math.max(t.gcTime, 1e3))
        }
    },
    ct = (t, e) => t.isLoading && t.isFetching && !e,
    ut = (t, e) => t ? .suspense && e.isPending,
    W = (t, e, s) => e.fetchOptimistic(t).catch(() => {
        s.clearReset()
    });

function lt(t, e, s) {
    const i = et(),
        r = rt(),
        l = Z(),
        n = l.defaultQueryOptions(t);
    l.getDefaultOptions().queries ? ._experimental_beforeQuery ? .(n);
    const f = l.getQueryCache().get(n.queryHash);
    n._optimisticResults = i ? "isRestoring" : "optimistic", ht(n), nt(n, r, f), at(r);
    const R = !l.getQueryCache().get(n.queryHash),
        [h] = d.useState(() => new e(l, n)),
        a = h.getOptimisticResult(n),
        b = !i && t.subscribed !== !1;
    if (d.useSyncExternalStore(d.useCallback(o => {
            const y = b ? h.subscribe(z.batchCalls(o)) : M;
            return h.updateResult(), y
        }, [h, b]), () => h.getCurrentResult(), () => h.getCurrentResult()), d.useEffect(() => {
            h.setOptions(n)
        }, [n, h]), ut(n, a)) throw W(n, h, r);
    if (ot({
            result: a,
            errorResetBoundary: r,
            throwOnError: n.throwOnError,
            query: f,
            suspense: n.suspense
        })) throw a.error;
    return l.getDefaultOptions().queries ? ._experimental_afterQuery ? .(n, a), n.experimental_prefetchInRender && !x.isServer() && ct(a, i) && (R ? W(n, h, r) : f ? .promise) ? .catch(M).finally(() => {
        h.updateResult()
    }), n.notifyOnChangeProps ? a : h.trackResult(a)
}

function pt(t, e) {
    return lt(t, $)
}
export {
    pt as u
};