import {
    r as a
} from "./index-CELiIWTZ.js";
import {
    u as i
} from "./useServerFn-DCM27h-c.js";
import {
    u
} from "./useQuery-DMt4i6fi.js";
import {
    z as l
} from "./admin.functions-X0VyiQO1.js";
import {
    b as m
} from "./payments.functions-CYyE4sTY.js";
const s = "ghosttrader:auth";

function o() {
    if (typeof window > "u") return null;
    try {
        const e = localStorage.getItem(s);
        return e ? JSON.parse(e) : null
    } catch {
        return null
    }
}

function r(e) {
    typeof window > "u" || (e ? localStorage.setItem(s, JSON.stringify(e)) : localStorage.removeItem(s), window.dispatchEvent(new Event("ghosttrader:auth-change")))
}
const p = {
    current: o,
    login(e) {
        const t = {
            email: e,
            username: e.split("@")[0] || "trader"
        };
        return r(t), t
    },
    loginWallet(e) {
        const t = {
            email: `${e.slice(0,6)}…${e.slice(-4)}@wallet`,
            username: `${e.slice(0,6)}…${e.slice(-4)}`,
            walletAddress: e
        };
        return r(t), t
    },
    logout() {
        r(null)
    }
};

function c() {
    const [e, t] = a.useState(() => o());
    return a.useEffect(() => {
        const n = () => t(o());
        return window.addEventListener("ghosttrader:auth-change", n), window.addEventListener("storage", n), () => {
            window.removeEventListener("ghosttrader:auth-change", n), window.removeEventListener("storage", n)
        }
    }, []), e
}

function y() {
    const e = c(),
        t = i(l),
        {
            data: n
        } = u({
            queryKey: ["isAdmin", e ? .email ? ? ""],
            queryFn: () => t({
                data: {
                    email: e.email
                }
            }),
            enabled: !!e ? .email,
            staleTime: 6e4
        });
    return !!n ? .isAdmin
}

function v() {
    const e = c(),
        t = i(m);
    return u({
        queryKey: ["subscription", e ? .email ? ? ""],
        queryFn: () => t({
            data: {
                email: e.email
            }
        }),
        enabled: !!e ? .email,
        staleTime: 3e4
    })
}
export {
    p as a, y as b, v as c, c as u
};