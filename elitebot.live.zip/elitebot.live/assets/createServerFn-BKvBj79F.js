import {
    z as b,
    T as y,
    A as _,
    x
} from "./index-CELiIWTZ.js";

function M(r) {
    if (Array.isArray(r)) return r.flatMap(i => M(i));
    if (typeof r != "string") return [];
    const n = [];
    let e = 0,
        a, l, t, s, o;
    const d = () => {
            for (; e < r.length && /\s/.test(r.charAt(e));) e += 1;
            return e < r.length
        },
        c = () => (l = r.charAt(e), l !== "=" && l !== ";" && l !== ",");
    for (; e < r.length;) {
        for (a = e, o = !1; d();)
            if (l = r.charAt(e), l === ",") {
                for (t = e, e += 1, d(), s = e; e < r.length && c();) e += 1;
                e < r.length && r.charAt(e) === "=" ? (o = !0, e = s, n.push(r.slice(a, t)), a = e) : e = t + 1
            } else e += 1;
        (!o || e >= r.length) && n.push(r.slice(a))
    }
    return n
}

function A(r) {
    return r instanceof Headers ? r : Array.isArray(r) ? new Headers(r) : typeof r == "object" ? new Headers(r) : null
}

function j(...r) {
    return r.reduce((n, e) => {
        const a = A(e);
        if (!a) return n;
        for (const [l, t] of a.entries()) l === "set-cookie" ? M(t).forEach(s => n.append("set-cookie", s)) : n.set(l, t);
        return n
    }, new Headers)
}

function v(r) {
    return r !== "__proto__" && r !== "constructor" && r !== "prototype"
}

function p(r, n) {
    const e = Object.create(null);
    if (r)
        for (const a of Object.keys(r)) v(a) && (e[a] = r[a]);
    if (n && typeof n == "object")
        for (const a of Object.keys(n)) v(a) && (e[a] = n[a]);
    return e
}

function F(r) {
    return Object.create(null)
}
var O = () => {
        throw new Error("createServerOnlyFn() functions can only be called on the server!")
    },
    w = (r, n) => {
        const e = n || r || {};
        return typeof e.method > "u" && (e.method = "GET"), Object.assign(t => w(void 0, { ...e,
            ...t
        }), {
            options: e,
            middleware: t => {
                const s = [...e.middleware || []];
                t.map(d => {
                    y in d ? d.options.middleware && s.push(...d.options.middleware) : s.push(d)
                });
                const o = w(void 0, { ...e,
                    middleware: s
                });
                return o[y] = !0, o
            },
            inputValidator: t => w(void 0, { ...e,
                inputValidator: t
            }),
            handler: (...t) => {
                const [s, o] = t, d = { ...e,
                    extractedFn: s,
                    serverFn: o
                }, c = [...d.middleware || [], S(d)];
                return s.method = e.method, Object.assign(async i => {
                    const u = await m(c, "client", { ...s,
                            ...d,
                            data: i ? .data,
                            headers: i ? .headers,
                            signal: i ? .signal,
                            fetch: i ? .fetch,
                            context: F()
                        }),
                        f = b(u.error);
                    if (f) throw f;
                    if (u.error) throw u.error;
                    return u.result
                }, { ...s,
                    method: e.method,
                    __executeServer: async i => {
                        const u = O(),
                            f = u.contextAfterGlobalMiddlewares;
                        return await m(c, "server", { ...s,
                            ...i,
                            serverFnMeta: s.serverFnMeta,
                            context: p(i.context, f),
                            request: u.request
                        }).then(h => ({
                            result: h.result,
                            error: h.error,
                            context: h.sendContext
                        }))
                    }
                })
            }
        })
    };
async function m(r, n, e) {
    let a = E([..._() ? .functionMiddleware || [], ...r]);
    if (n === "server") {
        const t = O();
        t ? .executedRequestMiddlewares && (a = a.filter(s => !t.executedRequestMiddlewares.has(s)))
    }
    const l = async t => {
        const s = a.shift();
        if (!s) return t;
        try {
            "inputValidator" in s.options && s.options.inputValidator && n === "server" && (t.data = await R(s.options.inputValidator, t.data));
            let o;
            if (n === "client" ? "client" in s.options && (o = s.options.client) : "server" in s.options && (o = s.options.server), o) {
                const c = await o({ ...t,
                    next: async (i = {}) => {
                        const u = await l({ ...t,
                            ...i,
                            context: p(t.context, i.context),
                            sendContext: p(t.sendContext, i.sendContext),
                            headers: j(t.headers, i.headers),
                            _callSiteFetch: t._callSiteFetch,
                            fetch: t._callSiteFetch ? ? i.fetch ? ? t.fetch,
                            result: i.result !== void 0 ? i.result : i instanceof Response ? i : t.result,
                            error: i.error ? ? t.error
                        });
                        if (u.error) throw u.error;
                        return u
                    }
                });
                if (x(c)) return { ...t,
                    error: c
                };
                if (c instanceof Response) return { ...t,
                    result: c
                };
                if (!c) throw new Error("User middleware returned undefined. You must call next() or return a result in your middlewares.");
                return c
            }
            return l(t)
        } catch (o) {
            return { ...t,
                error: o
            }
        }
    };
    return l({ ...e,
        headers: e.headers || {},
        sendContext: e.sendContext || {},
        context: e.context || F(),
        _callSiteFetch: e.fetch
    })
}

function E(r, n = 100) {
    const e = new Set,
        a = [],
        l = (t, s) => {
            if (s > n) throw new Error(`Middleware nesting depth exceeded maximum of ${n}. Check for circular references.`);
            t.forEach(o => {
                o.options.middleware && l(o.options.middleware, s + 1), e.has(o) || (e.add(o), a.push(o))
            })
        };
    return l(r, 0), a
}
async function R(r, n) {
    if (r == null) return {};
    if ("~standard" in r) {
        const e = await r["~standard"].validate(n);
        if (e.issues) throw new Error(JSON.stringify(e.issues, void 0, 2));
        return e.value
    }
    if ("parse" in r) return r.parse(n);
    if (typeof r == "function") return r(n);
    throw new Error("Invalid validator type!")
}

function S(r) {
    return {
        "~types": void 0,
        options: {
            inputValidator: r.inputValidator,
            client: async ({
                next: n,
                sendContext: e,
                fetch: a,
                ...l
            }) => {
                const t = { ...l,
                    context: e,
                    fetch: a
                };
                return n(await r.extractedFn ? .(t))
            },
            server: async ({
                next: n,
                ...e
            }) => {
                const a = await r.serverFn ? .(e);
                return n({ ...e,
                    result: a
                })
            }
        }
    }
}
export {
    w as c
};