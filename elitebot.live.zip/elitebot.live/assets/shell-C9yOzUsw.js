import {
    j as e,
    L as o
} from "./index-CELiIWTZ.js";
import "./admin.functions-X0VyiQO1.js";
import "./payments.functions-CYyE4sTY.js";
import {
    L as i
} from "./logo-Cph7X3mc.js";

function u({
    title: r,
    subtitle: t,
    children: a,
    footer: s
}) {
    return e.jsxs("div", {
        className: "relative grid min-h-screen place-items-center bg-background px-4",
        children: [e.jsx("div", {
            className: "bg-grid absolute inset-0 -z-10 opacity-50"
        }), e.jsx("div", {
            className: "pointer-events-none absolute -top-40 left-1/2 -z-10 size-[500px] -translate-x-1/2 rounded-full bg-primary/10 blur-[120px]"
        }), e.jsxs("div", {
            className: "w-full max-w-md",
            children: [e.jsx(o, {
                to: "/",
                className: "mb-10 flex items-center justify-center",
                "aria-label": "Ghost Trader AI",
                children: e.jsx(i, {
                    height: 36
                })
            }), e.jsxs("div", {
                className: "glass rounded-2xl p-8",
                children: [e.jsx("h1", {
                    className: "text-2xl font-semibold tracking-tight",
                    children: r
                }), t && e.jsx("p", {
                    className: "mt-2 text-sm text-muted-foreground",
                    children: t
                }), e.jsx("div", {
                    className: "mt-8",
                    children: a
                })]
            }), s && e.jsx("p", {
                className: "mt-6 text-center text-xs text-muted-foreground",
                children: s
            })]
        })]
    })
}

function p({
    label: r,
    type: t = "text",
    value: a,
    onChange: s,
    placeholder: n
}) {
    return e.jsxs("label", {
        className: "block",
        children: [e.jsx("span", {
            className: "font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground",
            children: r
        }), e.jsx("input", {
            type: t,
            value: a,
            onChange: l => s(l.target.value),
            placeholder: n,
            className: "mt-2 h-11 w-full rounded-md border border-border bg-background px-3 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-primary"
        })]
    })
}
export {
    u as A, p as a
};