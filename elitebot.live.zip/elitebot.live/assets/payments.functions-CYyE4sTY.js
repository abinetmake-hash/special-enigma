import {
    y as o,
    c as e
} from "./index-CELiIWTZ.js";
import {
    c as a
} from "./createServerFn-BKvBj79F.js";
var f = {};

function r() {
    const d = f.SUPABASE_URL,
        t = f.SUPABASE_SERVICE_ROLE_KEY;
    if (!d || !t) {
        const c = `Missing Supabase environment variable(s): ${[...d?[]:["SUPABASE_URL"],...t?[]:["SUPABASE_SERVICE_ROLE_KEY"]].join(", ")}. Connect Supabase in Lovable Cloud.`;
        throw console.error(`[Supabase] ${c}`), new Error(c)
    }
    return o(d, t, {
        auth: {
            storage: void 0,
            persistSession: !1,
            autoRefreshToken: !1
        }
    })
}
let s;
new Proxy({}, {
    get(d, t, n) {
        return s || (s = r()), Reflect.get(s, t, n)
    }
});
const S = a({
        method: "POST"
    }).handler(e("9bd693b3b9e99413905f260915f7aa3255ce63dd27f526f0fe4bc52d2ebdfa43")),
    m = a({
        method: "POST"
    }).handler(e("f60f29559a8cd8e245aa259c0daf7290eb025da8f3621e32e7529635b3c3eee2")),
    l = a({
        method: "POST"
    }).handler(e("62008d6e644b2493fd320428de91d6f647b9ed8ed23840b45bf951e4654d6acf")),
    h = a({
        method: "POST"
    }).handler(e("3de2bec937eeaaf8428d4b2738d74133cd009e55102571745fb8e891c943a937")),
    E = a({
        method: "POST"
    }).handler(e("921e5dcf08e32072ae4a24722910381d992027974fa0129968a4ad5937fff157")),
    u = a({
        method: "GET"
    }).handler(e("bfd09b636449f6432526aabce835fa4fe15674ea545bc1f21a94b8329fa1d388")),
    P = a({
        method: "GET"
    }).handler(e("418633573147bc3c3bb9fa2ef38a75fb0668356a6f5a0f52b7dcfdf28e9d86b8")),
    _ = a({
        method: "POST"
    }).handler(e("83efcfbc92b09b05ddaa938b6b2d282f6a4cf50fdccbe7140ecdb2d90bb53d41"));
export {
    P as a, h as b, u as g, m as l, E as m, S as r, l as s, _ as v
};