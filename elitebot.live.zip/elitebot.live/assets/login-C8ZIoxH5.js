import {
    r as s,
    u as h,
    j as e,
    L as n,
    t as r
} from "./index-CELiIWTZ.js";
import {
    u as x
} from "./useServerFn-DCM27h-c.js";
import {
    A as f,
    a as u
} from "./shell-C9yOzUsw.js";
import {
    l as y
} from "./payments.functions-CYyE4sTY.js";
import {
    a as b
} from "./auth-W4ffuZEE.js";
import "./admin.functions-X0VyiQO1.js";
import "./createServerFn-BKvBj79F.js";
import "./logo-Cph7X3mc.js";
import "./useQuery-DMt4i6fi.js";

function A() {
    const [t, m] = s.useState(""), [a, d] = s.useState(""), [i, l] = s.useState(!1), c = h(), p = x(y), g = async () => {
        if (!t || !a) {
            r.error("Enter email and password.");
            return
        }
        l(!0);
        try {
            const o = await p({
                data: {
                    email: t,
                    password: a
                }
            });
            if (!o.ok) {
                r.error(o.reason);
                return
            }
            if (!o.active) {
                if (o.stage === "awaiting") {
                    r.info(o.reason);
                    return
                }
                r.message("Complete your payment to activate your account."), c({
                    to: "/subscribe",
                    search: {
                        email: t
                    }
                });
                return
            }
            b.login(t), c({
                to: "/mt5"
            })
        } catch {
            r.error("Could not log in. Please try again.")
        } finally {
            l(!1)
        }
    };
    return e.jsx(f, {
        title: "Log in to terminal",
        subtitle: "Welcome back. Enter your credentials to continue.",
        footer: e.jsxs(e.Fragment, {
            children: ["No account?", " ", e.jsx(n, {
                to: "/signup",
                className: "text-primary hover:underline",
                children: "Sign up"
            })]
        }),
        children: e.jsxs("div", {
            className: "space-y-4",
            children: [e.jsx(u, {
                label: "Email",
                type: "email",
                value: t,
                onChange: m,
                placeholder: "you@trader.io"
            }), e.jsx(u, {
                label: "Password",
                type: "password",
                value: a,
                onChange: d,
                placeholder: "••••••••"
            }), e.jsxs("div", {
                className: "flex items-center justify-between",
                children: [e.jsx(n, {
                    to: "/forgot-password",
                    className: "text-xs text-primary hover:underline",
                    children: "Forgot password?"
                }), e.jsx(n, {
                    to: "/support",
                    className: "text-xs text-muted-foreground hover:text-foreground",
                    children: "Need help?"
                })]
            }), e.jsx("button", {
                type: "button",
                disabled: i,
                onClick: g,
                className: "h-11 w-full rounded-md bg-primary text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-50",
                children: i ? "Authenticating…" : "Log in"
            })]
        })
    })
}
export {
    A as component
};