import React from 'react';

export interface Market {
  code: string;
  label: string;
  seed: number;
  fast: boolean;
}

export const MARKETS: Market[] = [
  { code: "R_10", label: "Volatility 10 Index", seed: 6412.38, fast: false },
  { code: "1HZ10V", label: "Volatility 10 (1s) Index", seed: 9284.15, fast: true },
  { code: "R_25", label: "Volatility 25 Index", seed: 2731.94, fast: false },
  { code: "1HZ25V", label: "Volatility 25 (1s) Index", seed: 1844.62, fast: true },
  { code: "R_50", label: "Volatility 50 Index", seed: 218.47, fast: false },
  { code: "1HZ50V", label: "Volatility 50 (1s) Index", seed: 335.09, fast: true },
  { code: "R_75", label: "Volatility 75 Index", seed: 104233.5, fast: false },
  { code: "1HZ75V", label: "Volatility 75 (1s) Index", seed: 5127.83, fast: true },
  { code: "R_100", label: "Volatility 100 Index", seed: 1583.26, fast: false },
  { code: "1HZ100V", label: "Volatility 100 (1s) Index", seed: 724.71, fast: true },
];

export const DEFAULT_MARKET = MARKETS[MARKETS.length - 1]; // Volatility 100 (1s) Index

export const DURATIONS = [
  "1 tick",
  "2 ticks",
  "3 ticks",
  "4 ticks",
  "5 ticks",
];

export function durationSeconds(duration: string, fast: boolean): string {
  const ticks = Number.parseInt(duration, 10) || 1;
  return `~${(ticks * (fast ? 1 : 2)).toFixed(0)}s`;
}

export function marketByCode(code: string): Market {
  return MARKETS.find((m) => m.code === code) ?? DEFAULT_MARKET;
}

export interface DigitStat {
  digit: number;
  count: number;
  percent: number;
}

export interface NavItem {
  key: string;
  label: string;
  icon: React.ReactNode;
  group: 'overview' | 'analysis' | 'tools' | 'help';
}

export interface NavGroup {
  key: 'overview' | 'analysis' | 'tools' | 'help';
  label: string | null;
}

export const NAV_GROUPS: NavGroup[] = [
  { key: "overview", label: null },
  { key: "analysis", label: "Contract analysis" },
  { key: "tools", label: "Market tools" },
  { key: "help", label: null },
];

export interface AnalysisVerdict {
  headline: string;
  tone: "neutral" | "bull" | "bear";
  winRate: number;
  confidence: number;
  sample: number;
  reason: string;
}
