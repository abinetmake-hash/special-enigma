import React from 'react';
import { Market } from '../types.ts';
import { TickFeedCard } from './TickFeedCard.tsx';
import { cn } from './ui.tsx';

export interface SideOption {
  value: string;
  label: string;
  tone?: "bull" | "bear";
}

interface SideButtonProps {
  label: string;
  tone?: "bull" | "bear";
  active: boolean;
  onClick: () => void;
}

export function SideButton({ label, tone, active, onClick }: SideButtonProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "min-h-[64px] w-full rounded-[12px] border-2 px-3 text-[18px] font-bold transition-colors",
        active
          ? tone === "bull"
            ? "border-[#047857] bg-[#047857] text-white"
            : tone === "bear"
            ? "border-[#DC2626] bg-[#DC2626] text-white"
            : "border-ink bg-ink text-white"
          : cn(
              "bg-white hover:bg-[#f1f5f9]",
              tone === "bull"
                ? "border-[#6ee7b7] text-bull-ink"
                : tone === "bear"
                ? "border-[#fca5a5] text-bear-ink"
                : "border-line-strong text-ink"
            )
      )}
    >
      {label}
    </button>
  );
}

export function SideSelector({
  market,
  stream,
  sides,
  selected,
  onSelect,
  rangeLabel,
  range,
  rangeValue,
  onRange,
  caption,
  children,
}: {
  market: Market;
  stream: {
    quote: number;
    history: number[];
    digits: number[];
    latest: number | null;
    tickCount: number;
    rate: number;
  };
  sides: SideOption[];
  selected: string | null;
  onSelect: (val: string) => void;
  rangeLabel?: string;
  range?: number[];
  rangeValue?: number;
  onRange?: (val: number) => void;
  caption?: string;
  children?: React.ReactNode;
}) {
  const [firstSide, secondSide] = sides;

  return (
    <section className="tac-panel overflow-hidden">
      <div className="p-5 sm:p-6">
        <TickFeedCard market={market} stream={stream} bare={true} />
      </div>
      <div className="border-t border-line bg-[#f8fafc] p-5 sm:p-6">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h3 className="text-[16px] font-bold text-ink">Pick a side</h3>
          {caption ? <p className="tac-small">{caption}</p> : null}
        </div>
        <div className="mt-4 grid grid-cols-[1fr_auto_1fr] items-center gap-3 sm:gap-5">
          <SideButton
            label={firstSide.label}
            tone={firstSide.tone}
            active={selected === firstSide.value}
            onClick={() => onSelect(firstSide.value)}
          />
          <div className="flex flex-col items-center gap-1.5">
            <div
              className="tac-dial"
              aria-live="polite"
              aria-label={`Last digit ${stream.latest ?? "pending"}`}
            >
              {stream.latest ?? "–"}
            </div>
            <span className="tac-small font-medium">Last digit</span>
          </div>
          <SideButton
            label={secondSide.label}
            tone={secondSide.tone}
            active={selected === secondSide.value}
            onClick={() => onSelect(secondSide.value)}
          />
        </div>

        {range?.length ? (
          <div className="mt-5">
            <p className="tac-label mb-2">{rangeLabel}</p>
            <div className="flex flex-wrap gap-2" role="radiogroup" aria-label={rangeLabel}>
              {range.map((num) => {
                const isActive = String(rangeValue) === String(num);
                return (
                  <button
                    key={num}
                    type="button"
                    role="radio"
                    aria-checked={isActive}
                    onClick={() => onRange?.(num)}
                    className={cn(
                      "tac-num grid h-11 min-w-11 place-items-center rounded-[9px] border px-2 text-[16px] font-bold transition-colors",
                      isActive
                        ? "border-ink bg-ink text-white"
                        : "border-line-strong bg-white text-ink hover:border-[#94a3b8] hover:bg-[#f1f5f9]"
                    )}
                  >
                    {num}
                  </button>
                );
              })}
            </div>
          </div>
        ) : null}

        {children}
      </div>
    </section>
  );
}
