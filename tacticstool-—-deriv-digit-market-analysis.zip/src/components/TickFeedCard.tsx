import { useMemo } from 'react';
import { Market } from '../types.ts';
import { Dot, Pill, cn } from './ui.tsx';

interface TickStreamData {
  quote: number;
  history: number[];
  digits: number[];
  latest: number | null;
  tickCount: number;
  rate: number;
}

export function TickTrendChart({ values, up }: { values: number[]; up: boolean }) {
  const chartData = useMemo(() => {
    if (values.length < 2) return null;
    const min = Math.min(...values);
    const range = Math.max(...values) - min || 1;
    const points = values.map((val, idx) => [
      (idx / (values.length - 1)) * 300,
      66 - ((val - min) / range) * 60,
    ]);
    const line = points
      .map(([x, y], idx) => `${idx === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`)
      .join(" ");
    const area = `${line} L300,72 L0,72 Z`;
    return {
      line,
      area,
      last: points[points.length - 1],
    };
  }, [values]);

  const strokeColor = up ? "#059669" : "#DC2626";

  return (
    <div className="relative h-[72px] w-full">
      <svg
        viewBox="0 0 300 72"
        preserveAspectRatio="none"
        className="absolute inset-0 h-full w-full"
        role="img"
        aria-label={`Quote trend over the last ${values.length} ticks, ${up ? "rising" : "falling"}`}
      >
        <line
          x1="0"
          y1="71.5"
          x2="300"
          y2="71.5"
          stroke="#E2E8F0"
          strokeWidth="1"
          vectorEffect="non-scaling-stroke"
        />
        {chartData ? (
          <>
            <path
              d={chartData.area}
              fill={up ? "rgba(5,150,105,0.08)" : "rgba(220,38,38,0.07)"}
            />
            <path
              d={chartData.line}
              fill="none"
              stroke={strokeColor}
              strokeWidth="2"
              strokeLinejoin="round"
              strokeLinecap="round"
              vectorEffect="non-scaling-stroke"
            />
          </>
        ) : null}
      </svg>
      {chartData ? (
        <span
          aria-hidden="true"
          className="absolute h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-white"
          style={{
            left: `${(chartData.last[0] / 300) * 100}%`,
            top: `${(chartData.last[1] / 72) * 100}%`,
            background: strokeColor,
          }}
        />
      ) : null}
    </div>
  );
}

export function TickFeedCard({
  market,
  stream,
  bare = false,
}: {
  market: Market;
  stream: TickStreamData;
  bare?: boolean;
}) {
  const recentDigits = stream.digits.slice(-8);
  const history = stream.history;
  const prevQuote = history.length > 1 ? history[history.length - 2] : null;
  const diff = prevQuote === null ? 0 : stream.quote - prevQuote;
  const totalChange = history.length > 1 ? stream.quote - history[0] : 0;
  const percentChange = history.length > 1 && history[0] ? (totalChange / history[0]) * 100 : 0;
  const isTickUp = diff >= 0;
  const isOverallUp = totalChange >= 0;

  return (
    <div className={cn(bare ? "" : "tac-panel p-5 sm:p-6")}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <h2 className="tac-h2">Live tick feed</h2>
          <p className="tac-small mt-0.5 truncate">{market.label}</p>
        </div>
        <div className="flex items-center gap-2">
          <Pill className="tac-num">{market.code}</Pill>
          <Pill tone="bull">
            <Dot />
            Streaming
          </Pill>
        </div>
      </div>

      <div className="mt-5 flex flex-wrap items-end gap-x-4 gap-y-1">
        <p className="tac-num text-[40px] leading-none font-bold tracking-[-0.02em] text-ink sm:text-[44px]">
          {stream.quote.toFixed(2)}
        </p>
        <div className="pb-1">
          <p
            className={cn(
              "tac-num flex items-center gap-1 text-[17px] font-bold",
              prevQuote === null ? "text-ink-2" : isTickUp ? "text-bull-ink" : "text-bear-ink"
            )}
          >
            {prevQuote === null ? null : (
              <svg
                width="12"
                height="12"
                viewBox="0 0 12 12"
                aria-hidden="true"
                className={isTickUp ? "" : "rotate-180"}
              >
                <path d="M6 1.5 11 9.5H1Z" fill="currentColor" />
              </svg>
            )}
            {diff >= 0 ? "+" : ""}
            {diff.toFixed(2)}
            <span className="sr-only">{isTickUp ? "up" : "down"} on the last tick</span>
          </p>
        </div>
        <p
          className={cn(
            "tac-num ml-auto pb-1 text-[14px] font-semibold",
            isOverallUp ? "text-bull-ink" : "text-bear-ink"
          )}
        >
          {percentChange >= 0 ? "+" : ""}
          {percentChange.toFixed(3)}% over {Math.max(0, history.length - 1)} ticks
        </p>
      </div>

      <div className="mt-4">
        <TickTrendChart values={history} up={isOverallUp} />
      </div>

      <div className="mt-5 flex flex-wrap items-center justify-between gap-4">
        <div className="min-w-0">
          <p className="tac-small mb-2">Last digits, newest on the right</p>
          <div className="flex flex-wrap gap-1.5" aria-label="Recent digits">
            {recentDigits.map((digit, idx) => {
              const isLast = idx === recentDigits.length - 1;
              return (
                <span
                  key={idx}
                  className="tac-chip"
                  data-hot={isLast ? "true" : undefined}
                >
                  {digit}
                </span>
              );
            })}
          </div>
        </div>
        <div className="text-right">
          <p className="tac-small">Tick rate</p>
          <p className="tac-num mt-0.5 text-[15px] font-semibold text-ink">
            ~{stream.rate.toFixed(2)}/s
          </p>
        </div>
      </div>
    </div>
  );
}
