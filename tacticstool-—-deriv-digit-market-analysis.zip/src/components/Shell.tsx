import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { useMarket } from '../context/MarketContext.tsx';
import {
  BarsIcon,
  CloseIcon,
  GridIcon,
  LifebuoyIcon,
  LogOutIcon,
  MenuIcon,
  RobotIcon,
  ScanIcon,
  SplitIcon,
  TargetIcon,
  TrendIcon,
} from '../icons.tsx';
import { NAV_GROUPS, NavItem } from '../types.ts';
import { Dot, cn } from './ui.tsx';

export function BrandLogo() {
  return (
    <span className="flex items-center gap-2.5">
      <span className="tac-mark">
        <RobotIcon className="h-full w-full" />
      </span>
      <span className="tac-wordmark">tacticstool</span>
    </span>
  );
}

const NAV_ITEMS: NavItem[] = [
  { key: "dashboard", label: "Dashboard", icon: <GridIcon width={19} height={19} />, group: "overview" },
  { key: "matches", label: "Matches / Differs", icon: <TargetIcon width={19} height={19} />, group: "analysis" },
  { key: "evenodd", label: "Even / Odd", icon: <SplitIcon width={19} height={19} />, group: "analysis" },
  { key: "overunder", label: "Over / Under", icon: <TrendIcon width={19} height={19} />, group: "analysis" },
  { key: "scanner", label: "Market scanner", icon: <ScanIcon width={19} height={19} />, group: "tools" },
  { key: "frequency", label: "Frequency graph", icon: <BarsIcon width={19} height={19} />, group: "tools" },
  { key: "support", label: "Support", icon: <LifebuoyIcon width={19} height={19} />, group: "help" },
];

function NavList({
  view,
  onSelect,
  onLogout,
  focusable = true,
}: {
  view: string;
  onSelect: (key: string) => void;
  onLogout: () => void;
  focusable?: boolean;
}) {
  const tabIdx = focusable ? 0 : -1;

  return (
    <div className="flex-1 overflow-y-auto px-3 py-4">
      {NAV_GROUPS.map((group) => {
        const groupItems = NAV_ITEMS.filter((item) => item.group === group.key);
        return (
          <div key={group.key} className="mb-4 last:mb-0">
            {group.label ? (
              <p className="tac-small mb-1.5 px-3 font-semibold">{group.label}</p>
            ) : null}
            <div className="space-y-1">
              {groupItems.map((item) => {
                const isActive = view === item.key;
                return (
                  <button
                    key={item.key}
                    type="button"
                    tabIndex={tabIdx}
                    data-active={isActive ? "true" : undefined}
                    aria-current={isActive ? "page" : undefined}
                    className="tac-navitem"
                    onClick={() => onSelect(item.key)}
                  >
                    {item.icon}
                    {item.label}
                  </button>
                );
              })}
            </div>
          </div>
        );
      })}

      <div className="mt-2 border-t border-line pt-3">
        <button
          type="button"
          tabIndex={tabIdx}
          className="tac-navitem hover:text-brand-deep"
          onClick={onLogout}
        >
          <LogOutIcon width={19} height={19} />
          Free Get Info
        </button>
      </div>
    </div>
  );
}

function SidebarMarketFooter() {
  const { market } = useMarket();
  return (
    <div className="border-t border-line px-5 py-4">
      <p className="tac-small">Active market</p>
      <p className="mt-0.5 truncate text-[15px] font-semibold text-ink">{market.label}</p>
    </div>
  );
}

export function Shell({
  view,
  onNavigate,
  children,
}: {
  view: string;
  onNavigate: (v: string) => void;
  children: React.ReactNode;
}) {
  const { resetAccess } = useAuth();
  const { market } = useMarket();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const activeNavItem = NAV_ITEMS.find((item) => item.key === view);

  useEffect(() => {
    document.body.style.overflow = mobileMenuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileMenuOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setMobileMenuOpen(false);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [view]);

  return (
    <div className="tac-shell">
      <div className="tac-app">
        {/* Desktop Sticky Sidebar */}
        <div className="hidden border-r border-line bg-white lg:block">
          <aside className="tac-sidebar" aria-label="Main navigation">
            <div className="flex h-[68px] items-center border-b border-line px-5">
              <BrandLogo />
            </div>
            <NavList view={view} onSelect={onNavigate} onLogout={resetAccess} />
            <SidebarMarketFooter />
          </aside>
        </div>

        {/* Main Content Area */}
        <div className="flex min-w-0 flex-col min-h-screen">
          <header className="tac-topbar">
            <div className="tac-content flex h-[64px] items-center justify-between gap-3 lg:h-[68px]">
              <div className="flex min-w-0 items-center gap-3">
                <button
                  type="button"
                  aria-label="Open menu"
                  aria-expanded={mobileMenuOpen}
                  onClick={() => setMobileMenuOpen(true)}
                  className="tac-iconbtn lg:hidden"
                >
                  <MenuIcon width={20} height={20} />
                </button>
                <span className="lg:hidden">
                  <BrandLogo />
                </span>
                <p className="hidden truncate text-[15px] text-ink-2 lg:block">
                  <span className="font-semibold text-ink">{activeNavItem?.label}</span>
                  <span className="mx-2 text-line-strong">/</span>
                  {market.label}
                </p>
              </div>

              <div className="flex flex-none items-center gap-2">
                <span className="tac-pill hidden sm:inline-flex" data-tone="bull">
                  <Dot />
                  Feed live
                </span>
                <span className="tac-pill tac-num hidden md:inline-flex">{market.code}</span>
                <span className="tac-pill sm:hidden" data-tone="bull">
                  <Dot />
                  Live
                </span>
              </div>
            </div>
          </header>

          <main className="tac-content flex-1">{children}</main>

          <footer className="mt-10 border-t border-line bg-white py-6">
            <div className="tac-content flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-[14px] font-semibold text-ink">Tactical Analysis Tool</p>
              <p className="tac-small">
                © 2026 Statistical analysis for Deriv digit markets
              </p>
            </div>
          </footer>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      <div
        className={cn(
          "fixed inset-0 z-[60] transition-opacity duration-200 lg:hidden",
          mobileMenuOpen ? "opacity-100" : "pointer-events-none opacity-0"
        )}
        aria-hidden={!mobileMenuOpen}
      >
        <button
          type="button"
          aria-label="Close menu"
          tabIndex={mobileMenuOpen ? 0 : -1}
          onClick={() => setMobileMenuOpen(false)}
          className="absolute inset-0 bg-[#0f172a]/50 border-0 cursor-pointer"
        />
        <nav
          aria-label="Main navigation"
          className={cn(
            "absolute inset-y-0 left-0 flex w-[300px] max-w-[85vw] flex-col bg-white shadow-xl transition-transform duration-200",
            mobileMenuOpen ? "translate-x-0" : "-translate-x-full"
          )}
        >
          <div className="flex h-[64px] items-center justify-between border-b border-line px-5">
            <BrandLogo />
            <button
              type="button"
              aria-label="Close menu"
              onClick={() => setMobileMenuOpen(false)}
              className="tac-iconbtn"
            >
              <CloseIcon width={18} height={18} />
            </button>
          </div>
          <NavList
            view={view}
            onSelect={(k) => {
              onNavigate(k);
              setMobileMenuOpen(false);
            }}
            onLogout={() => {
              resetAccess();
              setMobileMenuOpen(false);
            }}
            focusable={mobileMenuOpen}
          />
          <SidebarMarketFooter />
        </nav>
      </div>
    </div>
  );
}
