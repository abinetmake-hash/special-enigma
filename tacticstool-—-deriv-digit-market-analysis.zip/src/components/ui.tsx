import React from 'react';
import { ChevronDownIcon } from '../icons.tsx';
import { MARKETS } from '../types.ts';

export function cn(...classes: (string | boolean | undefined | null)[]): string {
  return classes.filter(Boolean).join(' ');
}

export function Dot({ live = true, tone = "bull" }: { live?: boolean; tone?: "bull" | "bear" | "warn" }) {
  return (
    <span
      aria-hidden="true"
      className={cn(
        "inline-block h-2 w-2 flex-none rounded-full",
        live
          ? cn(tone === "bear" ? "bg-bear" : tone === "warn" ? "bg-warn" : "bg-bull", "tac-live")
          : "bg-[#94a3b8]"
      )}
    />
  );
}

export function Label({
  children,
  className,
  htmlFor,
}: {
  children: React.ReactNode;
  className?: string;
  htmlFor?: string;
}) {
  if (htmlFor) {
    return (
      <label htmlFor={htmlFor} className={cn("tac-label block", className)}>
        {children}
      </label>
    );
  }
  return <p className={cn("tac-label", className)}>{children}</p>;
}

export function Field({
  label,
  children,
  hint,
  htmlFor,
}: {
  label: React.ReactNode;
  children: React.ReactNode;
  hint?: React.ReactNode;
  htmlFor?: string;
}) {
  return (
    <div className="space-y-2">
      <Label htmlFor={htmlFor}>{label}</Label>
      {children}
      {hint ? <p className="tac-small">{hint}</p> : null}
    </div>
  );
}

interface SelectOption {
  value: string;
  label: string;
}

export function Select({
  id,
  value,
  onChange,
  options,
  disabled,
}: {
  id?: string;
  value: string;
  onChange: (val: string) => void;
  options: SelectOption[];
  disabled?: boolean;
}) {
  return (
    <div className="relative">
      <select
        id={id}
        className="tac-field cursor-pointer pr-11"
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(e.target.value)}
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
      <ChevronDownIcon
        width={18}
        height={18}
        className="pointer-events-none absolute top-1/2 right-3.5 -translate-y-1/2 text-ink-2"
      />
    </div>
  );
}

export function MarketSelect({
  id,
  value,
  onChange,
  disabled,
}: {
  id?: string;
  value: string;
  onChange: (val: string) => void;
  disabled?: boolean;
}) {
  return (
    <Select
      id={id}
      value={value}
      onChange={onChange}
      disabled={disabled}
      options={MARKETS.map((m) => ({ value: m.code, label: m.label }))}
    />
  );
}

export function Note({
  children,
  tone = "warn",
  icon,
}: {
  children: React.ReactNode;
  tone?: "bull" | "bear" | "warn";
  icon?: React.ReactNode;
}) {
  return (
    <div
      className={cn(
        "flex gap-3 rounded-[12px] border px-4 py-3.5",
        tone === "bull"
          ? "border-[#a7f3d0] bg-[#ecfdf5] text-[#065f46]"
          : tone === "bear"
          ? "border-[#fecaca] bg-[#fef2f2] text-[#991b1b]"
          : "border-[#fde68a] bg-[#fffbeb] text-[#92400e]"
      )}
      role={tone === "bear" ? "alert" : undefined}
    >
      {icon ? (
        <span
          className={cn(
            "mt-0.5 flex-none",
            tone === "bull" ? "text-bull-ink" : tone === "bear" ? "text-bear-ink" : "text-warn-ink"
          )}
        >
          {icon}
        </span>
      ) : null}
      <p className="text-[15px] leading-relaxed">{children}</p>
    </div>
  );
}

export function Panel({
  children,
  className,
  hot = false,
  as: Component = "section",
}: {
  children: React.ReactNode;
  className?: string;
  hot?: boolean;
  as?: React.ElementType;
}) {
  return (
    <Component className={cn("tac-panel p-5 sm:p-6", hot && "tac-panel-hot", className)}>
      {children}
    </Component>
  );
}

export function Pill({
  children,
  tone = "default",
  className,
}: {
  children: React.ReactNode;
  tone?: "default" | "bull" | "bear" | "warn" | "solid";
  className?: string;
}) {
  return (
    <span className={cn("tac-pill", className)} data-tone={tone}>
      {children}
    </span>
  );
}

export function Progress({ value }: { value: number }) {
  const clamped = Math.max(0, Math.min(100, value));
  return (
    <div className="flex items-center gap-3">
      <div
        className="tac-track"
        role="progressbar"
        aria-valuenow={Math.round(clamped)}
        aria-valuemin={0}
        aria-valuemax={100}
      >
        <div className="tac-track-fill" style={{ width: `${clamped}%` }} />
      </div>
      <p className="tac-num w-11 flex-none text-right text-[14px] font-semibold text-ink">
        {Math.round(clamped)}%
      </p>
    </div>
  );
}

export function ReadOnlyField({ children }: { children: React.ReactNode }) {
  return <div className="tac-field tac-field-readonly">{children}</div>;
}

export function Ring({ children, value }: { children: React.ReactNode; value: number }) {
  const clamped = Math.max(0, Math.min(100, value));
  return (
    <div
      className="grid h-[84px] w-[84px] place-items-center rounded-full"
      style={{
        background: `conic-gradient(#059669 ${3.6 * clamped}deg, #e2e8f0 ${3.6 * clamped}deg)`,
      }}
    >
      <div className="grid h-[68px] w-[68px] place-items-center rounded-full bg-white text-brand-deep">
        {children}
      </div>
    </div>
  );
}

export function SectionHero({
  icon,
  title,
  description,
  aside,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  aside?: React.ReactNode;
}) {
  return (
    <header className="flex flex-col gap-4 pt-6 pb-6 sm:flex-row sm:items-end sm:justify-between md:pt-8">
      <div className="flex items-start gap-4">
        <span className="tac-tile">{icon}</span>
        <div className="min-w-0">
          <h1 className="tac-title">{title}</h1>
          <p className="tac-sub mt-1.5">{description}</p>
        </div>
      </div>
      {aside ? <div className="flex-none">{aside}</div> : null}
    </header>
  );
}

export function Segmented({
  value,
  onChange,
  options,
  label,
}: {
  value: string;
  onChange: (val: string) => void;
  options: { value: string; label: string; icon?: React.ReactNode }[];
  label: string;
}) {
  return (
    <div className="tac-segwrap" role="radiogroup" aria-label={label}>
      {options.map((opt) => (
        <button
          key={opt.value}
          type="button"
          role="radio"
          aria-checked={value === opt.value}
          className="tac-seg"
          data-active={value === opt.value}
          onClick={() => onChange(opt.value)}
        >
          {opt.icon}
          {opt.label}
        </button>
      ))}
    </div>
  );
}

export interface StatItem {
  label: string;
  value: string;
  tone?: "bull" | "bear" | "warn";
}

export function StatGrid({ items, columns = 2 }: { items: StatItem[]; columns?: 2 | 4 }) {
  return (
    <dl
      className={cn(
        "grid grid-cols-2 gap-px overflow-hidden rounded-[12px] border border-line bg-line",
        columns === 4 && "md:grid-cols-4"
      )}
    >
      {items.map((item) => (
        <div key={item.label} className="bg-white px-4 py-3.5">
          <dt className="tac-small">{item.label}</dt>
          <dd
            className={cn(
              "tac-num mt-1 text-[22px] leading-tight font-bold",
              item.tone === "bull"
                ? "text-bull-ink"
                : item.tone === "bear"
                ? "text-bear-ink"
                : item.tone === "warn"
                ? "text-warn-ink"
                : "text-ink"
            )}
          >
            {item.value}
          </dd>
        </div>
      ))}
    </dl>
  );
}

export function StatusCell({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-3 px-5 py-4">
      <span className="grid h-10 w-10 flex-none place-items-center rounded-[10px] bg-[#f1f5f9] text-ink">
        {icon}
      </span>
      <div className="min-w-0">
        <p className="tac-small">{label}</p>
        <div className="mt-0.5 truncate text-[16px] font-semibold text-ink">{value}</div>
      </div>
    </div>
  );
}

export function Toggle({
  id,
  checked,
  onChange,
  label,
  description,
  icon,
  disabled,
}: {
  id: string;
  checked: boolean;
  onChange: (val: boolean) => void;
  label: string;
  description?: string;
  icon?: React.ReactNode;
  disabled?: boolean;
}) {
  return (
    <div
      className={cn(
        "flex items-center justify-between gap-4 rounded-[12px] border px-4 py-3.5 transition-colors",
        checked ? "border-[#a7f3d0] bg-[#ecfdf5]" : "border-line-strong bg-white"
      )}
    >
      <div className="flex min-w-0 items-start gap-3">
        {icon ? (
          <span
            className={cn(
              "mt-0.5 grid h-9 w-9 flex-none place-items-center rounded-[9px]",
              checked ? "bg-brand-deep text-white" : "bg-[#f1f5f9] text-ink"
            )}
          >
            {icon}
          </span>
        ) : null}
        <div className="min-w-0">
          <label htmlFor={id} className="block cursor-pointer text-[16px] font-semibold text-ink">
            {label}
          </label>
          {description ? (
            <p id={`${id}-desc`} className="tac-small mt-0.5 text-ink-2">
              {description}
            </p>
          ) : null}
        </div>
      </div>
      <div className="flex flex-none items-center gap-2">
        <button
          type="button"
          role="switch"
          id={id}
          aria-checked={checked}
          aria-describedby={description ? `${id}-desc` : undefined}
          disabled={disabled}
          onClick={() => onChange(!checked)}
          className="tac-switch"
        />
      </div>
    </div>
  );
}
