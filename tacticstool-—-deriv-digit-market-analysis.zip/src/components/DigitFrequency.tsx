import { DigitStat } from '../types.ts';
import { cn } from './ui.tsx';

const COLOR_HIGHEST = "#059669";
const COLOR_LOWEST = "#DC2626";
const COLOR_OTHER = "#94A3B8";

function LegendItem({ color, text }: { color: string; text: string }) {
  return (
    <span className="flex items-center gap-1.5 text-[13px] font-medium text-ink-2">
      <span className="h-3 w-3 rounded-full flex-none" style={{ background: color }} />
      {text}
    </span>
  );
}

export function DigitFrequency({
  stats,
  highest,
  lowest,
  latest,
  sample,
  compact = false,
}: {
  stats: DigitStat[];
  highest: number | null;
  lowest: number | null;
  latest: number | null;
  sample: number;
  compact?: boolean;
}) {
  const maxPercent = Math.max(...stats.map((s) => s.percent), 14);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="tac-h2">Digit frequency</h2>
          <p className="tac-small tac-num mt-0.5">{sample} ticks in sample</p>
        </div>
        <div className="flex flex-wrap gap-x-4 gap-y-1.5">
          <LegendItem color={COLOR_HIGHEST} text="Most frequent" />
          <LegendItem color={COLOR_LOWEST} text="Least frequent" />
          <LegendItem color={COLOR_OTHER} text="Other digits" />
          <span className="flex items-center gap-1.5 text-[13px] font-medium text-ink-2">
            <span className="w-4 border-t-2 border-dashed border-[#0F172A]/60" />
            10% baseline
          </span>
        </div>
      </div>
      <figure>
        <div className={cn("relative", compact ? "h-[150px]" : "h-[200px]")}>
          {/* Dashed baseline line */}
          <div
            className="pointer-events-none absolute inset-x-0 z-10 border-t-2 border-dashed border-[#0F172A]/45"
            style={{ bottom: `${(10 / maxPercent) * 82}%` }}
          />
          <div className="absolute inset-0 flex items-end gap-1 border-b border-line-strong sm:gap-2.5">
            {stats.map((item) => {
              const heightPercent = sample === 0 ? 2 : Math.max(2, (item.percent / maxPercent) * 82);
              const color = item.digit === highest ? COLOR_HIGHEST : item.digit === lowest ? COLOR_LOWEST : COLOR_OTHER;
              const isHighlight = item.digit === highest || item.digit === lowest;
              return (
                <div key={item.digit} className="relative flex h-full flex-1 items-end justify-center">
                  <span
                    className={cn(
                      "tac-num absolute text-[10.5px] font-semibold tracking-[-0.02em] sm:text-[12.5px] sm:tracking-normal",
                      isHighlight ? "text-ink" : "text-ink-2"
                    )}
                    style={{ bottom: `calc(${heightPercent}% + 4px)` }}
                  >
                    {sample === 0 ? "" : item.percent.toFixed(1)}
                  </span>
                  <div
                    className="w-full max-w-[44px] rounded-t-[5px] transition-[height] duration-500"
                    style={{ height: `${heightPercent}%`, background: color }}
                  />
                </div>
              );
            })}
          </div>
        </div>
        <div className="mt-2 flex gap-1 sm:gap-2.5">
          {stats.map((item) => (
            <div key={item.digit} className="flex flex-1 justify-center">
              <span
                className={cn("tac-chip", item.digit === latest && "tac-chip-hot")}
                data-hot={item.digit === latest ? "true" : undefined}
              >
                {item.digit}
              </span>
            </div>
          ))}
        </div>
      </figure>
    </div>
  );
}
