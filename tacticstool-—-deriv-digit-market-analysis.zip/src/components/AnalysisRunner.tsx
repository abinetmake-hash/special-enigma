import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useMarket } from '../context/MarketContext.tsx';
import { useDigitStats } from '../hooks/useDigitStats.ts';
import { useTickStream } from '../hooks/useTickStream.ts';
import {
  BoltIcon,
  CheckIcon,
  ClockIcon,
  LockIcon,
  RobotIcon,
  ShieldIcon,
  SparkIcon,
  TargetIcon,
} from '../icons.tsx';
import {
  AnalysisVerdict,
  DURATIONS,
  durationSeconds,
} from '../types.ts';
import { DigitFrequency } from './DigitFrequency.tsx';
import { SideOption, SideSelector } from './SideSelector.tsx';
import {
  Field,
  MarketSelect,
  Note,
  Panel,
  Pill,
  Progress,
  ReadOnlyField,
  SectionHero,
  Segmented,
  Select,
  StatGrid,
  Toggle,
  cn,
} from './ui.tsx';

export interface AnalysisConfig {
  duration: string;
  mode: "standard" | "pro";
  botActive: boolean;
}

export function AnalysisSettings({
  market,
  config,
  onChange,
  idPrefix = "analysis",
}: {
  market: { code: string; label: string; fast: boolean };
  config: AnalysisConfig;
  onChange: (val: AnalysisConfig) => void;
  idPrefix?: string;
}) {
  const ticks = Number.parseInt(config.duration, 10) || 1;

  return (
    <section className="tac-panel space-y-5 p-5 sm:p-6">
      <h2 className="tac-h2">Analysis settings</h2>
      <Toggle
        id={`${idPrefix}-robot`}
        checked={config.botActive}
        onChange={(val) => onChange({ ...config, botActive: val })}
        icon={<RobotIcon className="h-[22px] w-[22px]" />}
        label="Activate robot"
        description={
          config.botActive
            ? "Robot is running. Deeper filtering and synchronized analysis are on."
            : "Turn on for deeper statistical filtering on every run."
        }
      />
      <Field label="Contract duration" htmlFor={`${idPrefix}-duration`}>
        <Select
          id={`${idPrefix}-duration`}
          value={config.duration}
          onChange={(val) => onChange({ ...config, duration: val })}
          options={DURATIONS.map((d) => ({ value: d, label: d }))}
        />
      </Field>
      <Field label="Analysis mode">
        <Segmented
          label="Analysis mode"
          value={config.mode}
          onChange={(val) => onChange({ ...config, mode: val as "standard" | "pro" })}
          options={[
            { value: "standard", label: "Standard", icon: <BoltIcon width={16} height={16} /> },
            { value: "pro", label: "Pro", icon: <SparkIcon width={16} height={16} /> },
          ]}
        />
      </Field>
      <Field label="Analysis window">
        <ReadOnlyField>
          <span className="tac-num">{durationSeconds(config.duration, market.fast)}</span>
        </ReadOnlyField>
      </Field>
      <p className="tac-body text-[14px]">
        {config.mode === "pro"
          ? "Pro weights the most recent 60% of the sample more heavily when ranking digits."
          : `The contract runs for ${ticks} tick${ticks === 1 ? "" : "s"}. The model reads a much wider window of real ticks to produce win rate and confidence, because a 1–5 tick sample is too small to measure anything.`}
      </p>
    </section>
  );
}

export function AnalysisProgress({
  title,
  steps,
  progress,
  preview,
}: {
  title: string;
  steps: string[];
  progress: number;
  preview?: number[];
}) {
  const currentStep = Math.min(steps.length - 1, Math.floor((progress / 100) * steps.length));

  return (
    <section className="tac-panel space-y-5 p-5 sm:p-6" aria-live="polite">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="tac-h2">{title}</h2>
        {preview?.length ? (
          <div className="flex gap-1.5" aria-label="Digits being analysed">
            {preview.map((d, i) => (
              <span key={i} className="tac-chip h-8 w-8 text-[15px]">
                {d}
              </span>
            ))}
          </div>
        ) : null}
      </div>
      <ol className="space-y-2.5">
        {steps.map((step, idx) => (
          <li
            key={step}
            className={cn(
              "flex items-center gap-3 text-[15px]",
              idx < currentStep && "tac-checklist-done",
              idx === currentStep && "tac-checklist-active",
              idx > currentStep && "tac-checklist-idle"
            )}
          >
            <span
              className={cn(
                "grid h-6 w-6 flex-none place-items-center rounded-full border-2",
                idx < currentStep
                  ? "border-[#059669] bg-[#059669] text-white"
                  : idx === currentStep
                  ? "border-[#059669] bg-white"
                  : "border-line-strong bg-white"
              )}
            >
              {idx < currentStep ? (
                <CheckIcon width={13} height={13} />
              ) : idx === currentStep ? (
                <span className="tac-live h-2 w-2 rounded-full bg-[#059669]" />
              ) : null}
            </span>
            {step}
          </li>
        ))}
      </ol>
      <Progress value={progress} />
    </section>
  );
}

function clampConfidence(val: number): number {
  return Math.max(50, Math.min(96, val));
}

export function AnalysisVerdictCard({
  verdict,
  duration,
  mode,
}: {
  verdict: AnalysisVerdict;
  duration: string;
  mode: string;
}) {
  const isLowConfidence = verdict.confidence < 60;

  return (
    <Panel hot={true} className="space-y-5" as="article">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Pill tone="solid">
          <TargetIcon width={14} height={14} />
          Analysis result
        </Pill>
        <span className="flex gap-2">
          <Pill>
            <LockIcon width={13} height={13} />
            Locked
          </Pill>
          <Pill>
            <ClockIcon width={13} height={13} />
            {duration}
          </Pill>
        </span>
      </div>

      <div>
        <p className="tac-small">Suggested contract</p>
        <p
          className={cn(
            "mt-1 text-[40px] leading-none font-bold tracking-[-0.02em] sm:text-[48px]",
            verdict.tone === "bull"
              ? "text-bull-ink"
              : verdict.tone === "bear"
              ? "text-bear-ink"
              : "text-ink"
          )}
        >
          {verdict.headline}
        </p>
      </div>

      <StatGrid
        columns={4}
        items={[
          {
            label: "Win rate",
            value: `${verdict.winRate.toFixed(1)}%`,
            tone: verdict.winRate >= 50 ? "bull" : "bear",
          },
          {
            label: "Confidence",
            value: `${verdict.confidence.toFixed(0)}%`,
            tone: isLowConfidence ? "warn" : undefined,
          },
          {
            label: "Sample size",
            value: String(verdict.sample),
          },
          {
            label: "Mode",
            value: mode === "pro" ? "Pro" : "Standard",
          },
        ]}
      />

      <p className="tac-body">{verdict.reason}</p>

      {isLowConfidence ? (
        <Note tone="warn" icon={<ShieldIcon width={18} height={18} />}>
          Confidence is under 60%. The sample sits close to its baseline, so let more ticks build before you trade on this.
        </Note>
      ) : null}
    </Panel>
  );
}

function useAnalysisRunner(onComplete: () => void, stepIncrement = 4) {
  const [progress, setProgress] = useState(0);
  const [running, setRunning] = useState(false);
  const callbackRef = useRef(onComplete);
  callbackRef.current = onComplete;

  useEffect(() => {
    if (!running) return;
    if (progress >= 100) {
      setRunning(false);
      callbackRef.current();
      return;
    }
    const timer = setTimeout(() => {
      setProgress((p) => Math.min(100, p + stepIncrement));
    }, 80);
    return () => clearTimeout(timer);
  }, [running, progress, stepIncrement]);

  const start = useCallback(() => {
    setProgress(0);
    setRunning(true);
  }, []);

  const reset = useCallback(() => {
    setRunning(false);
    setProgress(0);
  }, []);

  return { progress, running, start, reset };
}

export function AnalysisRunner({
  variant,
  icon,
  title,
  description,
  sides,
  caption,
  steps,
  rangeLabel,
  range,
}: {
  variant: "matches" | "evenodd" | "overunder";
  icon: React.ReactNode;
  title: string;
  description: string;
  sides: SideOption[];
  caption: string;
  steps: string[];
  rangeLabel?: string;
  range?: number[];
}) {
  const { market, setMarketCode } = useMarket();
  const stream = useTickStream(market);
  const { stats, highest, lowest, deviation, evenPercent } = useDigitStats(stream.digits);

  const [config, setConfig] = useState<AnalysisConfig>({
    duration: "1 tick",
    mode: "standard",
    botActive: false,
  });

  const [selectedSide, setSelectedSide] = useState<string | null>(null);
  const [barrierValue, setBarrierValue] = useState<number>(range ? range[0] : 0);
  const [verdict, setVerdict] = useState<AnalysisVerdict | null>(null);

  const calculateVerdict = (): AnalysisVerdict => {
    const sample = stream.digits.length;
    const proBonus = config.mode === "pro" ? 6 : 0;
    const botBonus = config.botActive ? 4 : 0;

    if (variant === "matches") {
      const targetDigit = selectedSide === "differ" ? lowest ?? 0 : highest ?? 0;
      const stat = stats[targetDigit] ?? { digit: targetDigit, count: 0, percent: 10 };
      const winRate = selectedSide === "differ" ? 100 - stat.percent : stat.percent;

      return {
        headline: `${selectedSide === "differ" ? "Differ" : "Match"} ${targetDigit}`,
        tone: "neutral",
        winRate,
        confidence: clampConfidence(52 + 1.4 * deviation + proBonus + botBonus),
        sample,
        reason:
          selectedSide === "differ"
            ? `Digit ${targetDigit} is the least frequent in the sample, so a differs contract has the wider margin.`
            : `Digit ${targetDigit} leads the sample at ${stat.percent.toFixed(1)}% against a 10% baseline.`,
      };
    }

    if (variant === "evenodd") {
      const isEvenFavored = evenPercent >= 50;
      const winRate = isEvenFavored ? evenPercent : 100 - evenPercent;

      return {
        headline: isEvenFavored ? "Even" : "Odd",
        tone: "neutral",
        winRate,
        confidence: clampConfidence(50 + 2.2 * Math.abs(evenPercent - 50) + proBonus + botBonus),
        sample,
        reason: `Even digits took ${evenPercent.toFixed(1)}% of the last ${sample} ticks.`,
      };
    }

    // overunder
    const aboveCount = stream.digits.filter((d) => d > barrierValue).length;
    const winRatio = sample ? (aboveCount / sample) * 100 : 50;
    const isOver = winRatio >= 50;

    return {
      headline: `${isOver ? "Over" : "Under"} ${barrierValue}`,
      tone: isOver ? "bull" : "bear",
      winRate: isOver ? winRatio : 100 - winRatio,
      confidence: clampConfidence(50 + 2 * Math.abs(winRatio - 50) + proBonus + botBonus),
      sample,
      reason: `${aboveCount} of the last ${sample} ticks landed above barrier ${barrierValue}.`,
    };
  };

  const { progress, running, start, reset } = useAnalysisRunner(() => {
    setVerdict(calculateVerdict());
  });

  const isCollectingTicks = stream.digits.length < 12;
  const isReadyToRun = !isCollectingTicks && (variant !== "matches" || selectedSide !== null);

  return (
    <div className="pb-6">
      <SectionHero
        icon={icon}
        title={title}
        description={description}
        aside={
          config.botActive ? (
            <Pill tone="bull">
              <RobotIcon className="h-4 w-4" />
              Robot on
            </Pill>
          ) : null
        }
      />

      <div className="flex flex-col gap-5 lg:grid lg:grid-cols-[minmax(0,1fr)_380px] lg:items-start lg:gap-6 xl:grid-cols-[minmax(0,1fr)_420px]">
        {/* Left Column */}
        <div className="contents lg:flex lg:flex-col lg:gap-5">
          <div className="order-4">
            <SideSelector
              market={market}
              stream={stream}
              sides={sides}
              selected={selectedSide}
              onSelect={(val) => {
                setSelectedSide(val);
                setVerdict(null);
                reset();
              }}
              rangeLabel={rangeLabel}
              range={range}
              rangeValue={barrierValue}
              onRange={(val) => setBarrierValue(Number(val))}
              caption={caption}
            />
          </div>

          <div className="order-5 space-y-2">
            <button
              type="button"
              className={cn("tac-btn", isReadyToRun && !running ? "tac-btn-primary" : "tac-btn-waiting")}
              disabled={!isReadyToRun || running}
              onClick={() => {
                setVerdict(null);
                start();
              }}
            >
              <TargetIcon width={18} height={18} />
              {running
                ? "Analysing…"
                : isCollectingTicks
                ? `Collecting ticks (${stream.digits.length}/12)`
                : isReadyToRun
                ? `Run ${title} analysis`
                : `Pick ${sides[0].label} or ${sides[1].label} to continue`}
            </button>
          </div>

          {running ? (
            <div className="order-6">
              <AnalysisProgress
                title="Analysing pattern"
                steps={steps}
                progress={progress}
                preview={stream.digits.slice(-5)}
              />
            </div>
          ) : null}

          {verdict && !running ? (
            <div className="order-7">
              <AnalysisVerdictCard verdict={verdict} duration={config.duration} mode={config.mode} />
            </div>
          ) : null}

          <div className="order-2 lg:order-last">
            <Panel>
              <DigitFrequency
                stats={stats}
                highest={highest}
                lowest={lowest}
                latest={stream.latest}
                sample={stream.digits.length}
              />
            </Panel>
          </div>
        </div>

        {/* Right Column */}
        <div className="contents lg:flex lg:flex-col lg:gap-5">
          <div className="order-1">
            <Panel>
              <Field label="Market" htmlFor={`${variant}-market`}>
                <MarketSelect
                  id={`${variant}-market`}
                  value={market.code}
                  onChange={setMarketCode}
                  disabled={running}
                />
              </Field>
            </Panel>
          </div>
          <div className="order-3">
            <AnalysisSettings
              idPrefix={variant}
              market={market}
              config={config}
              onChange={setConfig}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
