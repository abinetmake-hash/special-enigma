import { useState } from 'react';
import { AnalysisRunner } from '../components/AnalysisRunner.tsx';
import { Shell } from '../components/Shell.tsx';
import { MarketProvider } from '../context/MarketContext.tsx';
import { SplitIcon, TargetIcon, TrendIcon } from '../icons.tsx';
import { DashboardView } from './DashboardView.tsx';
import { FrequencyView } from './FrequencyView.tsx';
import { ScannerView } from './ScannerView.tsx';
import { SupportView } from './SupportView.tsx';

export function DashboardPage() {
  const [view, setView] = useState<string>("dashboard");

  return (
    <MarketProvider>
      <Shell view={view} onNavigate={setView}>
        {view === "dashboard" ? <DashboardView onNavigate={setView} /> : null}

        {view === "matches" ? (
          <AnalysisRunner
            variant="matches"
            icon={<TargetIcon width={24} height={24} />}
            title="Matches / Differs"
            description="Find the most frequent digit in recent ticks and read how likely the next tick is to repeat it."
            sides={[
              { value: "differ", label: "Differ" },
              { value: "match", label: "Match" },
            ]}
            caption="Pick Differ or Match to lock a prediction."
            steps={[
              "Pulling Deriv tick history",
              "Counting appearances per digit",
              "Ranking digits by frequency",
              "Comparing against the 10% baseline",
              "Estimating win probability",
            ]}
            rangeLabel="Prediction range"
            range={[1, 2, 3, 4, 5]}
          />
        ) : null}

        {view === "evenodd" ? (
          <AnalysisRunner
            variant="evenodd"
            icon={<SplitIcon width={24} height={24} />}
            title="Even / Odd"
            description="Track the even-odd split across the running sample and see which side the distribution favours."
            sides={[
              { value: "even", label: "Even" },
              { value: "odd", label: "Odd" },
            ]}
            caption="Pick a side, or run the analysis and take its call."
            steps={[
              "Pulling Deriv tick history",
              "Splitting digits into even and odd",
              "Measuring the running split",
              "Checking drift against 50/50",
              "Estimating win probability",
            ]}
            rangeLabel="Prediction range"
            range={[1, 2, 3, 4, 5]}
          />
        ) : null}

        {view === "overunder" ? (
          <AnalysisRunner
            variant="overunder"
            icon={<TrendIcon width={24} height={24} />}
            title="Over / Under"
            description="Set a barrier digit and see how the recent distribution sits above and below it."
            sides={[
              { value: "over", label: "Over", tone: "bull" },
              { value: "under", label: "Under", tone: "bear" },
            ]}
            caption="Choose Over or Under, then set a barrier."
            steps={[
              "Pulling Deriv tick history",
              "Sorting digits around the barrier",
              "Counting each side of the split",
              "Weighting the recent window",
              "Estimating win probability",
            ]}
            rangeLabel="Barrier"
            range={[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]}
          />
        ) : null}

        {view === "scanner" ? <ScannerView /> : null}
        {view === "frequency" ? <FrequencyView /> : null}
        {view === "support" ? <SupportView /> : null}
      </Shell>
    </MarketProvider>
  );
}
