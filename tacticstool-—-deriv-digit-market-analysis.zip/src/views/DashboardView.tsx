import { DigitFrequency } from '../components/DigitFrequency.tsx';
import { TickFeedCard } from '../components/TickFeedCard.tsx';
import { Dot, Panel, Pill, SectionHero, StatusCell } from '../components/ui.tsx';
import { useMarket } from '../context/MarketContext.tsx';
import { useDigitStats } from '../hooks/useDigitStats.ts';
import { useTickStream } from '../hooks/useTickStream.ts';
import {
  BarsIcon,
  ChevronDownIcon,
  GridIcon,
  PulseIcon,
  RadioIcon,
  ScanIcon,
  SplitIcon,
  TargetIcon,
  TrendIcon,
} from '../icons.tsx';

export function DashboardView({ onNavigate }: { onNavigate: (key: string) => void }) {
  const { market } = useMarket();
  const stream = useTickStream(market);
  const { stats, highest, lowest, deviation, evenPercent } = useDigitStats(stream.digits);
  const isNoTicks = stream.digits.length === 0;

  const modules = [
    {
      key: "matches",
      label: "Matches / Differs",
      icon: <TargetIcon width={22} height={22} />,
      note: highest === null ? "Waiting for ticks" : `Digit ${highest} leads the sample`,
    },
    {
      key: "evenodd",
      label: "Even / Odd",
      icon: <SplitIcon width={22} height={22} />,
      note: isNoTicks ? "Waiting for ticks" : `Even digits at ${evenPercent.toFixed(0)}%`,
    },
    {
      key: "overunder",
      label: "Over / Under",
      icon: <TrendIcon width={22} height={22} />,
      note: lowest === null ? "Waiting for ticks" : `Digit ${lowest} trails the sample`,
    },
    {
      key: "scanner",
      label: "Market scanner",
      icon: <ScanIcon width={22} height={22} />,
      note: "Rank all ten markets",
    },
  ];

  const isSkewed = deviation > 20;

  return (
    <div className="space-y-6 pb-6">
      <SectionHero
        icon={<GridIcon width={24} height={24} />}
        title="Dashboard"
        description="Live market data and every analysis module in one place."
      />

      <section
        aria-label="System status"
        className="tac-panel grid grid-cols-1 divide-y divide-line sm:grid-cols-3 sm:divide-x sm:divide-y-0"
      >
        <StatusCell
          icon={<BarsIcon width={20} height={20} />}
          label="System"
          value={
            <span className="flex items-center gap-2 text-bull-ink">
              <Dot />
              Online
            </span>
          }
        />
        <StatusCell
          icon={<PulseIcon width={20} height={20} />}
          label="Tick feed"
          value={
            isNoTicks ? (
              <span className="flex items-center gap-2 text-warn-ink">
                <Dot tone="warn" />
                Connecting
              </span>
            ) : (
              <span className="flex items-center gap-2 text-bull-ink">
                <Dot />
                Connected
              </span>
            )
          }
        />
        <StatusCell
          icon={<RadioIcon width={20} height={20} />}
          label="Market"
          value={market.label}
        />
      </section>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <TickFeedCard market={market} stream={stream} />
        <Panel>
          <DigitFrequency
            stats={stats}
            highest={highest}
            lowest={lowest}
            latest={stream.latest}
            sample={stream.digits.length}
            compact={true}
          />
        </Panel>
      </div>

      <section aria-labelledby="modules-heading" className="space-y-3">
        <h2 id="modules-heading" className="tac-h2">
          Analysis modules
        </h2>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {modules.map((m) => (
            <button
              key={m.key}
              type="button"
              onClick={() => onNavigate(m.key)}
              className="group tac-panel flex items-center gap-4 p-4 text-left transition-colors hover:border-[#6ee7b7] hover:bg-[#fcfffd] cursor-pointer"
            >
              <span className="grid h-12 w-12 flex-none place-items-center rounded-[11px] bg-[#ecfdf5] text-brand-deep">
                {m.icon}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-[16px] font-semibold text-ink">{m.label}</span>
                <span className="tac-small tac-num mt-0.5 block text-ink-2">{m.note}</span>
              </span>
              <ChevronDownIcon
                width={18}
                height={18}
                className="flex-none -rotate-90 text-ink-2 transition-transform group-hover:translate-x-0.5"
              />
            </button>
          ))}
        </div>
      </section>

      <Panel className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="tac-label">Distribution deviation</p>
          <p className="tac-num mt-1 text-[32px] leading-none font-bold text-ink">
            {deviation.toFixed(2)}
          </p>
          <p className="tac-small mt-2 max-w-[56ch]">
            Sum of each digit's distance from the 10% baseline. Above 20 means the sample is skewed enough to be worth a closer look.
          </p>
        </div>
        <Pill tone={isSkewed ? "warn" : "default"}>
          {isSkewed ? "Skewed" : "Near baseline"}
        </Pill>
      </Panel>
    </div>
  );
}
