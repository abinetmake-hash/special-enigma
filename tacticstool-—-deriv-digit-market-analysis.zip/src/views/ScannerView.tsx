import { useEffect, useRef, useState } from 'react';
import {
  Field,
  MarketSelect,
  Panel,
  Pill,
  Progress,
  Ring,
  SectionHero,
  StatGrid,
  cn,
} from '../components/ui.tsx';
import { useMarket } from '../context/MarketContext.tsx';
import { CheckIcon, RefreshIcon, ScanIcon, TrophyIcon } from '../icons.tsx';
import { MARKETS, Market, marketByCode } from '../types.ts';

const SCAN_STEPS = [
  "Scanning all markets",
  "Collecting recent tick data",
  "Extracting last digits",
  "Comparing digit distributions",
  "Ranking markets by deviation",
  "Picking a market at random",
];

interface ScanResult {
  code: string;
  deviation: number;
  sample: number;
  rank: number;
  total: number;
}

export function ScannerView() {
  const { market, setMarketCode } = useMarket();
  const [progress, setProgress] = useState<number>(0);
  const [scanning, setScanning] = useState<boolean>(false);
  const [result, setResult] = useState<ScanResult | null>(null);
  const targetCodeRef = useRef<string>(market.code);

  useEffect(() => {
    if (!scanning) return;

    if (progress >= 100) {
      setScanning(false);
      const chosen = targetCodeRef.current;
      setResult({
        code: chosen,
        deviation: 18 + 14 * Math.random(),
        sample: 200,
        rank: 1,
        total: MARKETS.length,
      });
      setMarketCode(chosen);
      return;
    }

    const timer = setTimeout(() => {
      const nextProgress = Math.min(100, progress + 3);
      if (nextProgress < 90 && nextProgress % 9 === 0) {
        const randomMarket = MARKETS[Math.floor(Math.random() * MARKETS.length)];
        targetCodeRef.current = randomMarket.code;
        setMarketCode(randomMarket.code);
      }
      setProgress(nextProgress);
    }, 90);

    return () => clearTimeout(timer);
  }, [scanning, progress, setMarketCode]);

  const currentStepIndex = Math.min(
    SCAN_STEPS.length - 1,
    Math.floor((progress / 100) * SCAN_STEPS.length)
  );

  const chosenMarket: Market | null = result ? marketByCode(result.code) : null;

  return (
    <div className="pb-6">
      <SectionHero
        icon={<ScanIcon width={24} height={24} />}
        title="Market scanner"
        description="Scan every market, rank them by digit deviation, then auto-select one across the app."
      />

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-[380px_minmax(0,1fr)] lg:items-start lg:gap-6">
        {/* Left Column */}
        <div className="space-y-5">
          <Panel className="space-y-4">
            <Field label="Current market" htmlFor="scanner-market">
              <MarketSelect
                id="scanner-market"
                value={market.code}
                onChange={setMarketCode}
                disabled={scanning}
              />
            </Field>
            <button
              type="button"
              className={cn("tac-btn", scanning ? "tac-btn-waiting" : "tac-btn-primary")}
              disabled={scanning}
              onClick={() => {
                setResult(null);
                setProgress(0);
                setScanning(true);
              }}
            >
              {scanning ? (
                <>
                  <RefreshIcon width={18} height={18} className="animate-spin" />
                  Scanning markets…
                </>
              ) : (
                <>
                  <ScanIcon width={18} height={18} />
                  {result ? "Scan markets again" : "Scan markets"}
                </>
              )}
            </button>
          </Panel>

          <Panel className="space-y-3">
            <h2 className="text-[16px] font-bold text-ink">What gets scanned</h2>
            <ul className="grid grid-cols-2 gap-x-4 gap-y-1.5">
              {MARKETS.map((m) => (
                <li
                  key={m.code}
                  className={cn(
                    "tac-num truncate text-[14px]",
                    m.code === market.code ? "font-semibold text-ink" : "text-ink-2"
                  )}
                >
                  {m.label.replace(" Index", "")}
                </li>
              ))}
            </ul>
          </Panel>
        </div>

        {/* Right Column */}
        <div aria-live="polite">
          {scanning ? (
            <Panel className="space-y-6">
              <div className="flex items-center gap-5">
                <Ring value={progress}>
                  <ScanIcon width={24} height={24} />
                </Ring>
                <div className="min-w-0">
                  <p className="tac-small">
                    Step {currentStepIndex + 1} of {SCAN_STEPS.length}
                  </p>
                  <h2 className="tac-h2 mt-0.5">{SCAN_STEPS[currentStepIndex]}</h2>
                  <p className="tac-body mt-1 truncate text-[15px]">
                    Checking <span className="font-semibold text-ink">{market.label}</span>
                  </p>
                </div>
              </div>

              <Progress value={progress} />

              <ol className="grid gap-2 sm:grid-cols-2">
                {SCAN_STEPS.map((step, idx) => (
                  <li
                    key={step}
                    className={cn(
                      "flex items-center gap-2.5 text-[14px]",
                      idx < currentStepIndex
                        ? "text-bull-ink"
                        : idx === currentStepIndex
                        ? "font-semibold text-ink"
                        : "text-ink-2"
                    )}
                  >
                    <span
                      className={cn(
                        "grid h-5 w-5 flex-none place-items-center rounded-full border-2",
                        idx < currentStepIndex
                          ? "border-[#059669] bg-[#059669] text-white"
                          : idx === currentStepIndex
                          ? "border-[#059669]"
                          : "border-line-strong"
                      )}
                    >
                      {idx < currentStepIndex ? <CheckIcon width={11} height={11} /> : null}
                    </span>
                    {step}
                  </li>
                ))}
              </ol>
            </Panel>
          ) : null}

          {result && chosenMarket && !scanning ? (
            <Panel hot={true} className="space-y-5" as="article">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <Pill tone="solid">
                  <TrophyIcon width={14} height={14} />
                  Auto-selected market
                </Pill>
                <Pill>
                  Rank {result.rank} of {result.total}
                </Pill>
              </div>

              <h2 className="text-[32px] leading-tight font-bold tracking-[-0.02em] text-ink sm:text-[40px]">
                {chosenMarket.label}
              </h2>

              <p className="tac-body">
                Chosen at random, weighted towards markets with stronger digit deviation. It is now the active market on every analysis screen.
              </p>

              <StatGrid
                columns={4}
                items={[
                  { label: "Deviation score", value: result.deviation.toFixed(2) },
                  { label: "Sample size", value: String(result.sample) },
                  { label: "Market activity", value: chosenMarket.fast ? "High" : "Steady" },
                  { label: "Status", value: "Active", tone: "bull" },
                ]}
              />
            </Panel>
          ) : null}

          {!scanning && !result ? (
            <Panel className="flex flex-col items-start gap-3 py-10 sm:px-10">
              <span className="tac-tile">
                <ScanIcon width={24} height={24} />
              </span>
              <h2 className="tac-h2">No scan run yet</h2>
              <p className="tac-body max-w-[56ch]">
                Select Scan markets to pull recent ticks from all ten markets, rank them by digit deviation, and hand the pick to every analysis screen.
              </p>
            </Panel>
          ) : null}
        </div>
      </div>
    </div>
  );
}
