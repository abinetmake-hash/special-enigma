import React, { useState } from 'react';
import { Dot, Note } from '../components/ui.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import {
  BarsIcon,
  CheckIcon,
  RobotIcon,
  ScanIcon,
  ShieldIcon,
  SparkIcon,
  SplitIcon,
  TargetIcon,
  TrendIcon,
} from '../icons.tsx';

const FEATURES = [
  {
    icon: <TargetIcon width={20} height={20} />,
    name: "Matches / Differs",
    text: "Which digit leads and which trails.",
  },
  {
    icon: <SplitIcon width={20} height={20} />,
    name: "Even / Odd",
    text: "The running split against 50/50.",
  },
  {
    icon: <TrendIcon width={20} height={20} />,
    name: "Over / Under",
    text: "Distribution around any barrier.",
  },
  {
    icon: <ScanIcon width={20} height={20} />,
    name: "Market scanner",
    text: "All ten markets ranked by deviation.",
  },
  {
    icon: <BarsIcon width={20} height={20} />,
    name: "Frequency graph",
    text: "Overall versus the last 50 ticks.",
  },
];

export function LoginPage({ onAuthenticated }: { onAuthenticated?: () => void }) {
  const { grantFreeAccess } = useAuth();
  const [operatorName, setOperatorName] = useState<string>("Trader");
  const [acceptedTerms, setAcceptedTerms] = useState<boolean>(true);
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);

  const handleFreeGet = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");

    if (!acceptedTerms) {
      setErrorMessage("Please accept the risk disclaimer to launch the analysis engine.");
      return;
    }

    setLoading(true);
    setTimeout(() => {
      grantFreeAccess();
      onAuthenticated?.();
    }, 400);
  };

  return (
    <div className="tac-shell flex flex-col min-h-screen">
      <header className="tac-topbar">
        <div className="tac-content flex h-[64px] items-center justify-between gap-3">
          <span className="flex items-center gap-2.5">
            <span className="tac-mark">
              <RobotIcon className="h-full w-full" />
            </span>
            <span className="tac-wordmark">tacticstool</span>
          </span>
          <div className="flex items-center gap-2">
            <span className="tac-pill" data-tone="bull">
              <Dot />
              Free Access Active
            </span>
          </div>
        </div>
      </header>

      <main className="tac-content flex-1 py-8 md:py-14">
        <div className="grid grid-cols-1 items-start gap-10 lg:grid-cols-[minmax(0,1fr)_440px] lg:gap-16">
          {/* Left Column: Briefing & Features */}
          <div className="order-2 lg:order-1 lg:pt-4">
            <div className="inline-flex items-center gap-2 rounded-full bg-[#ecfdf5] border border-[#a7f3d0] px-3.5 py-1 text-[13px] font-semibold text-brand-deep mb-3">
              <SparkIcon width={14} height={14} />
              100% Free Access — No Payment Required
            </div>
            <h1 className="max-w-[18ch] text-[34px] leading-[1.1] font-bold tracking-[-0.025em] text-ink md:text-[48px]">
              Read the digit market before you trade it.
            </h1>
            <p className="tac-sub mt-4 text-[17px]">
              Statistical analysis for Deriv synthetic indices, calculated live from real tick history. Free instant access for all traders.
            </p>
            <ul className="mt-8 divide-y divide-line border-y border-line">
              {FEATURES.map((item) => (
                <li key={item.name} className="flex items-center gap-4 py-3.5">
                  <span className="grid h-10 w-10 flex-none place-items-center rounded-[10px] bg-[#ecfdf5] text-brand-deep">
                    {item.icon}
                  </span>
                  <span>
                    <span className="block text-[16px] font-semibold text-ink">{item.name}</span>
                    <span className="block text-[15px] text-ink-2">{item.text}</span>
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* Right Column: Free Get Card */}
          <div className="order-1 lg:order-2">
            <form
              onSubmit={handleFreeGet}
              className="tac-panel space-y-5 p-6 shadow-[0_12px_32px_-12px_rgba(15,23,42,0.18)] sm:p-8"
              noValidate
            >
              <div>
                <div className="flex items-center justify-between">
                  <h2 className="text-[26px] leading-tight font-bold tracking-[-0.015em] text-ink">
                    Free Get
                  </h2>
                  <span className="tac-pill" data-tone="bull">
                    Instant Free Pass
                  </span>
                </div>
                <p className="tac-body mt-1">
                  No sign in, credentials, or payment needed. Unlock full tactical tools instantly.
                </p>
              </div>

              <div className="space-y-2">
                <label htmlFor="operator-alias" className="tac-label block">
                  Operator Alias (Optional)
                </label>
                <input
                  id="operator-alias"
                  type="text"
                  value={operatorName}
                  onChange={(e) => setOperatorName(e.target.value)}
                  placeholder="Your trader name"
                  className="tac-field"
                  disabled={loading}
                />
              </div>

              <div className="rounded-[10px] bg-[#f8fafc] border border-line p-3.5 space-y-2">
                <div className="flex items-center gap-2 text-[14px] font-semibold text-ink">
                  <CheckIcon width={16} height={16} className="text-bull-ink" />
                  All 10 Deriv Volatility Markets Included
                </div>
                <div className="flex items-center gap-2 text-[14px] font-semibold text-ink">
                  <CheckIcon width={16} height={16} className="text-bull-ink" />
                  Matches, Even/Odd & Over/Under Modules
                </div>
                <div className="flex items-center gap-2 text-[14px] font-semibold text-ink">
                  <CheckIcon width={16} height={16} className="text-bull-ink" />
                  Live Market Scanner & Frequency Analyzer
                </div>
              </div>

              <label className="flex cursor-pointer items-start gap-3">
                <input
                  type="checkbox"
                  checked={acceptedTerms}
                  onChange={(e) => setAcceptedTerms(e.target.checked)}
                  className="mt-[3px] h-5 w-5 flex-none accent-[#047857]"
                  disabled={loading}
                />
                <span className="text-[15px] leading-relaxed text-ink-2">
                  I understand analysis output is statistical rather than a guarantee, and digit markets involve risk.
                </span>
              </label>

              {errorMessage ? <Note tone="bear">{errorMessage}</Note> : null}

              <button
                type="submit"
                disabled={loading}
                className={`tac-btn ${loading ? "tac-btn-waiting" : "tac-btn-primary"}`}
              >
                {loading ? "Launching engine…" : "Get Free Access Now"}
              </button>

              <p className="tac-small text-center text-ink-3">
                Free for all users • No card required • Instant access
              </p>
            </form>

            <div className="mt-5">
              <Note tone="warn" icon={<ShieldIcon width={18} height={18} />}>
                Digit markets are random by design. Size every position so a losing run cannot take the account out.
              </Note>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t border-line bg-white py-6">
        <div className="tac-content flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-[14px] font-semibold text-ink">Tactical Analysis Tool — Free Edition</p>
          <p className="tac-small">© 2026 All rights reserved</p>
        </div>
      </footer>
    </div>
  );
}
