import { DigitFrequency } from '../components/DigitFrequency.tsx';
import {
  Field,
  MarketSelect,
  Panel,
  Pill,
  SectionHero,
  StatGrid,
  cn,
} from '../components/ui.tsx';
import { useMarket } from '../context/MarketContext.tsx';
import { useDigitStats } from '../hooks/useDigitStats.ts';
import { useTickStream } from '../hooks/useTickStream.ts';
import { BarsIcon } from '../icons.tsx';

export function FrequencyView() {
  const { market, setMarketCode } = useMarket();
  const stream = useTickStream(market);
  const { stats, highest, lowest, deviation, evenPercent } = useDigitStats(stream.digits);

  const recentFifty = stream.digits.slice(-50);
  const recentStats = useDigitStats(recentFifty).stats;

  return (
    <div className="space-y-6 pb-6">
      <SectionHero
        icon={<BarsIcon width={24} height={24} />}
        title="Frequency graph"
        description="How often each digit appears across the running sample, measured against a flat 10% baseline."
        aside={
          <div className="w-full sm:w-[300px]">
            <Field label="Market" htmlFor="freq-market">
              <MarketSelect id="freq-market" value={market.code} onChange={setMarketCode} />
            </Field>
          </div>
        }
      />

      <StatGrid
        columns={4}
        items={[
          { label: "Ticks collected", value: String(stream.digits.length) },
          { label: "Deviation score", value: deviation.toFixed(2), tone: deviation > 20 ? "warn" : undefined },
          { label: "Even share", value: `${evenPercent.toFixed(1)}%` },
          { label: "Odd share", value: `${(100 - evenPercent).toFixed(1)}%` },
        ]}
      />

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)]">
        <Panel>
          <DigitFrequency
            stats={stats}
            highest={highest}
            lowest={lowest}
            latest={stream.latest}
            sample={stream.digits.length}
          />
        </Panel>

        <section className="tac-panel overflow-hidden">
          <div className="flex flex-wrap items-start justify-between gap-3 p-5 sm:p-6">
            <div>
              <h2 className="tac-h2">Overall vs recent</h2>
              <p className="tac-small mt-0.5">
                Drift is the recent share minus the overall share, in points.
              </p>
            </div>
            <Pill>Last 50 ticks</Pill>
          </div>

          <div className="tac-scroll-x border-t border-line">
            <table className="tac-table min-w-[340px]">
              <thead>
                <tr>
                  <th scope="col">Digit</th>
                  <th scope="col">Overall</th>
                  <th scope="col">Recent</th>
                  <th scope="col">Drift</th>
                </tr>
              </thead>
              <tbody>
                {stats.map((item) => {
                  const recentShare = recentStats[item.digit]?.percent ?? 10;
                  const drift = recentShare - item.percent;
                  const isUp = drift > 0.5;
                  const isDown = drift < -0.5;

                  return (
                    <tr key={item.digit}>
                      <td>{item.digit}</td>
                      <td>{item.percent.toFixed(1)}%</td>
                      <td>{recentShare.toFixed(1)}%</td>
                      <td
                        className={cn(
                          "font-bold",
                          isUp ? "text-bull-ink" : isDown ? "text-bear-ink" : "text-ink-2"
                        )}
                      >
                        {isUp ? "▲ " : isDown ? "▼ " : ""}
                        {drift > 0 ? "+" : ""}
                        {drift.toFixed(1)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  );
}
