import { Note, Panel, SectionHero } from '../components/ui.tsx';
import { LifebuoyIcon, MessageIcon, ShieldIcon } from '../icons.tsx';

const FAQS = [
  {
    q: "Where do the numbers come from?",
    a: "Every screen reads the same running tick sample for the selected market. Win rate and confidence are calculated from that window, not from the contract duration.",
  },
  {
    q: "What does Pro mode change?",
    a: "Pro weights the most recent 60% of the sample more heavily when ranking digits, so it reacts faster to a shifting distribution.",
  },
  {
    q: "What does Activate robot do?",
    a: "It switches on synchronized analysis: deeper statistical filtering on each run, which nudges confidence when the sample supports it. Turn it off at any time from Analysis settings.",
  },
  {
    q: "Why does the market keep changing during a scan?",
    a: "The market scanner cycles through all ten markets while it ranks them, then settles on one and pushes that choice to every market dropdown in the app.",
  },
];

export function SupportView() {
  return (
    <div className="pb-6">
      <SectionHero
        icon={<LifebuoyIcon width={24} height={24} />}
        title="Support"
        description="Reach the operator directly, or read how the analysis engine reaches its numbers."
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[minmax(0,1fr)_360px] lg:items-start">
        {/* FAQs */}
        <section className="tac-panel" aria-labelledby="faq-heading">
          <h2 id="faq-heading" className="tac-h2 px-5 pt-5 sm:px-6 sm:pt-6">
            Common questions
          </h2>
          <div className="mt-3 divide-y divide-line">
            {FAQS.map((faq) => (
              <details key={faq.q} className="group px-5 py-4 sm:px-6" open={true}>
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4 text-[16px] font-semibold text-ink">
                  {faq.q}
                  <span
                    aria-hidden="true"
                    className="grid h-7 w-7 flex-none place-items-center rounded-full border border-line-strong text-[18px] leading-none text-ink-2 transition-transform group-open:rotate-45"
                  >
                    +
                  </span>
                </summary>
                <p className="tac-body mt-2 max-w-[68ch]">{faq.a}</p>
              </details>
            ))}
          </div>
        </section>

        {/* Right column: Message operator & Warning */}
        <div className="space-y-5">
          <Panel className="space-y-4">
            <h2 className="tac-h2">Message the operator</h2>
            <p className="tac-body">
              For strategy questions, setup assistance, or a walkthrough of any module. Replies come on WhatsApp.
            </p>
            <button
              type="button"
              onClick={() => {
                const url = `https://wa.me/254182585105?text=${encodeURIComponent(
                  "Hello, I need help with the free Tactical Analysis Tool"
                )}`;
                window.open(url, "_blank", "noopener,noreferrer");
              }}
              className="tac-btn tac-btn-primary"
            >
              <MessageIcon width={18} height={18} />
              Message support
            </button>
          </Panel>

          <Note tone="warn" icon={<ShieldIcon width={18} height={18} />}>
            Analysis output is statistical, not a guarantee. Digit markets are random by design, so size every position so a losing run cannot take the account out.
          </Note>
        </div>
      </div>
    </div>
  );
}
