import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { DashboardPage } from './views/DashboardPage.tsx';
import { LoginPage } from './views/LoginPage.tsx';

function MainApp() {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? <DashboardPage /> : <LoginPage />;
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
