import React, { createContext, useContext, useEffect, useState } from 'react';

interface AuthContextValue {
  isAuthenticated: boolean;
  grantFreeAccess: () => void;
  resetAccess: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  // Free Get: defaulting or persistent free access
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(true);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    // If user explicitly exited, respect it, otherwise default to granted free access
    const stored = localStorage.getItem("tactical_free_access");
    if (stored === "false") {
      setIsAuthenticated(false);
    } else {
      setIsAuthenticated(true);
      localStorage.setItem("tactical_free_access", "true");
    }
    setLoading(false);
  }, []);

  const grantFreeAccess = () => {
    setIsAuthenticated(true);
    localStorage.setItem("tactical_free_access", "true");
  };

  const resetAccess = () => {
    setIsAuthenticated(false);
    localStorage.setItem("tactical_free_access", "false");
  };

  if (loading) {
    return (
      <div className="tac-shell flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center gap-3">
          <span className="h-9 w-9 animate-spin rounded-full border-[3px] border-[#e2e8f0] border-t-[#059669]"></span>
          <p className="tac-label">Starting engine</p>
        </div>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{ isAuthenticated, grantFreeAccess, resetAccess }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
