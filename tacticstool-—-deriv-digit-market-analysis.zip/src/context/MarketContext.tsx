import React, { createContext, useContext, useMemo, useState } from 'react';
import { DEFAULT_MARKET, Market, marketByCode } from '../types.ts';

interface MarketContextValue {
  market: Market;
  setMarketCode: (code: string) => void;
}

const MarketContext = createContext<MarketContextValue | undefined>(undefined);

export function MarketProvider({ children }: { children: React.ReactNode }) {
  const [currentCode, setCurrentCode] = useState<string>(DEFAULT_MARKET.code);

  const value = useMemo(
    () => ({
      market: marketByCode(currentCode),
      setMarketCode: setCurrentCode,
    }),
    [currentCode]
  );

  return <MarketContext.Provider value={value}>{children}</MarketContext.Provider>;
}

export function useMarket(): MarketContextValue {
  const context = useContext(MarketContext);
  if (!context) {
    throw new Error("useMarket must be used within a MarketProvider");
  }
  return context;
}
