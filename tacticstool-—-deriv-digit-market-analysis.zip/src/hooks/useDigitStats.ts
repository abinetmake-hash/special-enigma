import { useMemo } from 'react';
import { DigitStat } from '../types.ts';

export function useDigitStats(digits: number[]) {
  return useMemo(() => {
    const counts = Array.from({ length: 10 }, () => 0);
    digits.forEach((d) => {
      if (d >= 0 && d <= 9) {
        counts[d] += 1;
      }
    });

    const sample = digits.length || 1;
    const stats: DigitStat[] = counts.map((count, digit) => ({
      digit,
      count,
      percent: (count / sample) * 100,
    }));

    let highest: number | null = null;
    let lowest: number | null = null;

    if (digits.length > 0) {
      highest = stats.reduce((acc, curr) => (curr.count > acc.count ? curr : acc)).digit;
      lowest = stats.reduce((acc, curr) => (curr.count < acc.count ? curr : acc)).digit;
    }

    const deviation = stats.reduce((acc, curr) => acc + Math.abs(curr.percent - 10), 0);
    const evenCount = digits.filter((d) => d % 2 === 0).length;
    const evenPercent = (evenCount / sample) * 100;

    return {
      stats,
      highest,
      lowest,
      deviation,
      evenPercent,
    };
  }, [digits]);
}
