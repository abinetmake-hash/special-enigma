import { useEffect, useRef, useState } from 'react';
import { Market } from '../types.ts';

export function useTickStream(market: Market) {
  // Pre-generate a reasonable starting history so the user can immediately analyze
  const generateInitial = () => {
    const hist: number[] = [];
    const digs: number[] = [];
    let cur = market.seed;
    const stepSize = 8e-5 * market.seed;
    for (let i = 0; i < 28; i++) {
      cur = Math.max(0.01, cur + (Math.random() - 0.49) * stepSize * 10);
      const rounded = Number(cur.toFixed(2));
      const lastDigit = Math.floor(Math.round(100 * cur)) % 10;
      hist.push(rounded);
      digs.push(Math.abs(lastDigit));
    }
    return { hist, digs, lastQuote: hist[hist.length - 1] };
  };

  const initial = useRef(generateInitial()).current;
  const [quote, setQuote] = useState<number>(initial.lastQuote);
  const [history, setHistory] = useState<number[]>(initial.hist);
  const [digits, setDigits] = useState<number[]>(initial.digs);
  const [tickCount, setTickCount] = useState<number>(initial.digs.length);
  const quoteRef = useRef<number>(initial.lastQuote);

  useEffect(() => {
    // When market changes, reseed with realistic history
    const init = generateInitial();
    quoteRef.current = init.lastQuote;
    setQuote(init.lastQuote);
    setHistory(init.hist);
    setDigits(init.digs);
    setTickCount(init.digs.length);

    const intervalMs = market.fast ? 1000 : 1600;
    const stepSize = 8e-5 * market.seed;

    const timer = setInterval(() => {
      const next = Math.max(0.01, quoteRef.current + (Math.random() - 0.495) * stepSize * 12);
      quoteRef.current = next;
      const rounded = Number(next.toFixed(2));
      const lastDigit = Math.abs(Math.floor(Math.round(100 * next)) % 10);

      setQuote(rounded);
      setHistory((prev) => {
        const nextHist = [...prev, rounded];
        return nextHist.length > 60 ? nextHist.slice(nextHist.length - 60) : nextHist;
      });
      setTickCount((prev) => prev + 1);
      setDigits((prev) => {
        const nextDigits = [...prev, lastDigit];
        return nextDigits.length > 250 ? nextDigits.slice(nextDigits.length - 250) : nextDigits;
      });
    }, intervalMs);

    return () => clearInterval(timer);
  }, [market.code, market.seed, market.fast]);

  return {
    quote,
    history,
    digits,
    latest: digits.length ? digits[digits.length - 1] : null,
    tickCount: Math.min(tickCount, 250),
    rate: market.fast ? 1.03 : 0.62,
  };
}
