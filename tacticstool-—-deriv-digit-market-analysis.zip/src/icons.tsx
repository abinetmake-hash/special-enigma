import React from 'react';

export function RobotIcon({ className = '', animated = false }: { className?: string; animated?: boolean }) {
  return (
    <svg
      viewBox="0 0 100 120"
      className={`${className} ${animated ? 'animate-bounce' : ''}`}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <rect x="30" y="20" width="40" height="40" fill="none" stroke="currentColor" strokeWidth="2" rx="4" />
      <circle cx="38" cy="32" r="4" fill="currentColor" className={animated ? 'animate-pulse' : ''} />
      <circle cx="62" cy="32" r="4" fill="currentColor" className={animated ? 'animate-pulse' : ''} />
      <line x1="38" y1="50" x2="62" y2="50" stroke="currentColor" strokeWidth="2" />
      <rect x="25" y="65" width="50" height="35" fill="none" stroke="currentColor" strokeWidth="2" rx="4" />
      <rect x="35" y="75" width="30" height="20" fill="none" stroke="currentColor" strokeWidth="1.5" />
      <line x1="25" y1="80" x2="10" y2="80" stroke="currentColor" strokeWidth="2" />
      <line x1="75" y1="80" x2="90" y2="80" stroke="currentColor" strokeWidth="2" />
      <circle cx="10" cy="80" r="3" fill="currentColor" />
      <circle cx="90" cy="80" r="3" fill="currentColor" />
      <line x1="40" y1="100" x2="40" y2="115" stroke="currentColor" strokeWidth="2" />
      <line x1="60" y1="100" x2="60" y2="115" stroke="currentColor" strokeWidth="2" />
      <line x1="50" y1="20" x2="50" y2="8" stroke="currentColor" strokeWidth="2" />
      <circle cx="50" cy="6" r="3" fill="currentColor" />
    </svg>
  );
}

interface SvgProps extends React.SVGProps<SVGSVGElement> {
  width?: number | string;
  height?: number | string;
  className?: string;
}

function BaseSvg({ children, ...props }: React.PropsWithChildren<SvgProps>) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      width={18}
      height={18}
      aria-hidden="true"
      {...props}
    >
      {children}
    </svg>
  );
}

export function BarsIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <path d="M4 20V13" />
      <path d="M9 20V6" />
      <path d="M14 20v-9" />
      <path d="M19 20V9" />
    </BaseSvg>
  );
}

export function BoltIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <path d="M13 2 4 14h7l-1 8 9-12h-7l1-8Z" />
    </BaseSvg>
  );
}

export function CheckIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <path d="m4 12.5 5 5L20 6.5" />
    </BaseSvg>
  );
}

export function ChevronDownIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <path d="m6 9 6 6 6-6" />
    </BaseSvg>
  );
}

export function ClockIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5.2l3.2 2" />
    </BaseSvg>
  );
}

export function CloseIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <path d="M18 6 6 18M6 6l12 12" />
    </BaseSvg>
  );
}

export function GridIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <rect x="3" y="3" width="7" height="7" rx="1.5" />
      <rect x="14" y="3" width="7" height="7" rx="1.5" />
      <rect x="3" y="14" width="7" height="7" rx="1.5" />
      <rect x="14" y="14" width="7" height="7" rx="1.5" />
    </BaseSvg>
  );
}

export function LifebuoyIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <circle cx="12" cy="12" r="9" />
      <circle cx="12" cy="12" r="3.6" />
      <path d="m5.7 5.7 3.8 3.8M14.5 14.5l3.8 3.8M18.3 5.7l-3.8 3.8M9.5 14.5l-3.8 3.8" />
    </BaseSvg>
  );
}

export function LockIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <rect x="4" y="10" width="16" height="10" rx="2" />
      <path d="M8 10V7a4 4 0 0 1 8 0v3" />
    </BaseSvg>
  );
}

export function LogOutIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
      <path d="m16 17 5-5-5-5" />
      <path d="M21 12H9" />
    </BaseSvg>
  );
}

export function MenuIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <path d="M3 6h18M3 12h18M3 18h18" />
    </BaseSvg>
  );
}

export function MessageIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <path d="M20 15a2 2 0 0 1-2 2H8l-4 4V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v9Z" />
    </BaseSvg>
  );
}

export function PulseIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <path d="M2 12h4l3-8 5 16 3-8h5" />
    </BaseSvg>
  );
}

export function RadioIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <circle cx="12" cy="12" r="2" fill="currentColor" />
      <path d="M7.8 7.8a6 6 0 0 0 0 8.4M16.2 16.2a6 6 0 0 0 0-8.4" />
      <path d="M4.9 4.9a10 10 0 0 0 0 14.2M19.1 19.1a10 10 0 0 0 0-14.2" />
    </BaseSvg>
  );
}

export function RefreshIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <path d="M20 11a8 8 0 0 0-13.7-5.1L4 8" />
      <path d="M4 4v4h4" />
      <path d="M4 13a8 8 0 0 0 13.7 5.1L20 16" />
      <path d="M20 20v-4h-4" />
    </BaseSvg>
  );
}

export function ScanIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <path d="M3 8V5.5A2.5 2.5 0 0 1 5.5 3H8" />
      <path d="M16 3h2.5A2.5 2.5 0 0 1 21 5.5V8" />
      <path d="M21 16v2.5a2.5 2.5 0 0 1-2.5 2.5H16" />
      <path d="M8 21H5.5A2.5 2.5 0 0 1 3 18.5V16" />
      <path d="M7 12h10" />
    </BaseSvg>
  );
}

export function ShieldIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <path d="M12 3 4.5 6v5.5c0 4.6 3.1 8.2 7.5 9.5 4.4-1.3 7.5-4.9 7.5-9.5V6L12 3Z" />
      <path d="m9 12 2 2 4-4" />
    </BaseSvg>
  );
}

export function SparkIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <path d="M12 3v5M12 16v5M3 12h5M16 12h5" />
      <path d="m6.3 6.3 3 3M14.7 14.7l3 3M17.7 6.3l-3 3M9.3 14.7l-3 3" />
    </BaseSvg>
  );
}

export function SplitIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <path d="M4 6h5l6 12h5" />
      <path d="M4 18h5l2-4" />
      <path d="M17 3l3 3-3 3" />
      <path d="M17 15l3 3-3 3" />
    </BaseSvg>
  );
}

export function TargetIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <circle cx="12" cy="12" r="9" />
      <circle cx="12" cy="12" r="4.5" />
      <circle cx="12" cy="12" r="1" fill="currentColor" />
    </BaseSvg>
  );
}

export function TrendIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <path d="M3 17 9.5 10.5l4 4L21 7" />
      <path d="M15 7h6v6" />
    </BaseSvg>
  );
}

export function TrophyIcon(props: SvgProps) {
  return (
    <BaseSvg {...props}>
      <path d="M7 4h10v5a5 5 0 0 1-10 0V4Z" />
      <path d="M7 6H4v1a3 3 0 0 0 3 3M17 6h3v1a3 3 0 0 1-3 3" />
      <path d="M12 14v3M9 20h6" />
    </BaseSvg>
  );
}
