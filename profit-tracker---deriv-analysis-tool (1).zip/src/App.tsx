/**
 * PROFIT TRACKER - Deriv Analysis Tool
 * Exact Clone of https://profittracker.site/
 */

import React, { useState, useEffect, useRef, useMemo } from "react";

// Assets
const ROBOT_IMAGE = "/assets/robot_image.jpg";
const WHATSAPP_IMAGE = "/assets/whatsapp_image.png";
const EURO_IMAGE = "/assets/euro_image.jpg";
const SCANNER_IMAGE = "/assets/scanner_image.png";

const TOOL_NAME = "PROFIT TRACKER";
const TOOL_PRICE = "Free";
const WHATSAPP_LINK_NUMBER = "254108487752";
const SIGNAL_COUNTDOWN_SECONDS = 3;
const SIGNAL_ZERO_HOLD_MS = 3000;
const USERS_STORAGE_KEY = "optixProUsers";
const SESSION_STORAGE_KEY = "optixProActiveSessions";
const SYNC_CHANNEL_NAME = "optixProUsersSync";
const MODE_STORAGE_KEY = "profitProModeSettings";
const LOGIN_GUARD_KEY = "profitTrackerLoginGuard";
const ADMIN_ACCESS_USERNAME = "Water";
const ADMIN_ACCESS_PASSWORD = "land1234";
const LOGIN_MAX_ATTEMPTS = 5;
const LOGIN_LOCK_MS = 60 * 1000;
const USER_SESSION_TTL_MS = 15 * 60 * 1000;
const CLIENT_SESSION_ID = `${Date.now()}-${Math.random().toString(36).slice(2)}`;

const MARKETS = ["MATCHES", "EVEN / ODD", "OVER / UNDER"];

const VOLATILITY = [
  "Volatility 10 (1s) Index",
  "Volatility 15 (1s) Index",
  "Volatility 25 (1s) Index",
  "Volatility 50 (1s) Index",
  "Volatility 75 (1s) Index",
  "Volatility 90 (1s) Index",
  "Volatility 100 (1s) Index",
  "Volatility 10 Index",
  "Volatility 25 Index",
  "Volatility 50 Index",
  "Volatility 75 Index",
  "Volatility 100 Index",
];

const STRATEGIES = [
  ["Trend Confirmation", "Wait for market direction to align with recent momentum before taking a signal.", "Medium"],
  ["Volatility Filter", "Avoid weak or unstable movement and focus only on cleaner market conditions.", "Medium"],
  ["Signal Discipline", "Use one clear setup at a time and avoid repeated entries during noisy movement.", "Low"],
  ["Capital Protection", "Set a fixed exposure limit before trading and stop once that limit is reached.", "Low"],
  ["Session Timing", "Trade only during planned sessions so decisions stay focused and consistent.", "Medium"],
  ["Result Review", "Record each signal outcome and review patterns before increasing activity.", "Low-Medium"],
];

const MODE_CONFIG: Record<
  string,
  { name: string; strengths: string[]; durations: string[]; description: string; badge?: string }
> = {
  standard: {
    name: "Standard Mode",
    strengths: ["Low", "Medium", "High"],
    durations: ["1 Tick", "2 Ticks"],
    description: "Balanced filtering for everyday signal scanning.",
  },
  elite: {
    name: "Elite Mode",
    strengths: ["Medium", "High", "Very High"],
    durations: ["1 Tick", "2 Ticks", "3 Ticks"],
    description: "Sharper filtering for cleaner signal conditions.",
  },
  pro: {
    name: "Pro Mode",
    strengths: ["High", "Very High", "Maximum"],
    durations: ["1 Tick", "2 Ticks", "3 Ticks", "4 Ticks"],
    description: "Advanced filtering for focused trading sessions.",
  },
  master: {
    name: "Master Mode",
    strengths: ["Maximum"],
    durations: ["1 Tick"],
    description: "Highest filtering level. Designed for experienced users.",
    badge: "Precision Mode",
  },
};

const DEFAULT_USERS_PASSWORDS = [
  "Rift94Solar", "Cedar27Pulse", "Nova81Ledger", "Orbit63Signal", "Velvet39Index",
  "Copper52Alpha", "Falcon18Grid", "Quartz76Wave", "Harbor41Tick", "Matrix95Blue",
  "Summit24Edge", "Pixel68Trade", "Anchor13Flux", "Zenith57Candle", "Rocket82Prime",
  "Silver36Node", "Vector79Scope", "Marble21Rise", "Cosmic64Win", "Atlas48Trend",
  "Neon17Path", "Vertex73Flow", "Apex29Deriv", "Beacon86Chart", "Cipher34Market",
  "Prism91Scan", "Lunar45Dash", "Turbo69Logic", "Golden12Strike", "Echo58Vault",
  "Ion97Broker", "Rapid31Signal", "Titan74Pro", "Sonic26Digit", "Delta83Access",
  "Phoenix44Edge", "Legacy70Pulse", "Crown25Market", "Signal88Nexus", "Profit19Vault",
  "Deriv62Wave", "Prime53Candle", "Alpha14Scope", "Omega77Tick", "Royal35Grid",
  "Zen90Access", "Nova06Strategy", "Chart59Master", "Swift72Index",
];

export interface UserAccount {
  username: string;
  password: string;
  active: boolean;
  approved: boolean;
  pending?: boolean;
  role: "admin" | "user";
  loginCount: number;
  lastLogin: string;
  createdAt?: string;
}

export interface SignalData {
  id: string;
  market: string;
  volatility: string;
  digit: string;
  confidence: number;
  matrixScore: number;
  reason: string;
  risk: string;
  countdown: number;
  timestamp: Date;
}

function getDefaultUsers(): UserAccount[] {
  return [
    { username: "Water", password: "land1234", active: true, approved: true, role: "admin", loginCount: 0, lastLogin: "" },
    { username: "PRO", password: "pro1234", active: true, approved: true, role: "user", loginCount: 0, lastLogin: "" },
    ...DEFAULT_USERS_PASSWORDS.map((password, index) => ({
      username: `PROFIT${String(index + 1).padStart(2, "0")}`,
      password,
      active: true,
      approved: true,
      role: "user" as const,
      loginCount: 0,
      lastLogin: "",
    })),
  ];
}

function normalizeUsername(username: string) {
  return username.trim().toLowerCase();
}

function getWhatsappUrl(
  message = `Hello ${TOOL_NAME}, I want to get access to ${TOOL_NAME}. Please help me get started.`
) {
  const text = encodeURIComponent(message);
  return `https://wa.me/${WHATSAPP_LINK_NUMBER}?text=${text}`;
}

export default function App() {
  // Navigation / View State
  const [view, setView] = useState<"login" | "welcome" | "dashboard" | "admin">("login");
  const [loginMode, setLoginMode] = useState<"user" | "admin" | "request">("user");
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);
  const [errorMsg, setErrorMsg] = useState("");
  const [noticeMsg, setNoticeMsg] = useState("");

  // Google Admin Sign-in State
  const [customGoogleEmail, setCustomGoogleEmail] = useState("");
  const [showCustomGoogleInput, setShowCustomGoogleInput] = useState(false);

  // Login form inputs
  const [usernameInput, setUsernameInput] = useState("");
  const [passwordInput, setPasswordInput] = useState("");
  const [confirmPasswordInput, setConfirmPasswordInput] = useState("");

  // Users database stored in localStorage
  const [users, setUsers] = useState<UserAccount[]>(() => {
    try {
      const saved = localStorage.getItem(USERS_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.error(e);
    }
    return getDefaultUsers();
  });

  // Save users to localStorage whenever updated
  const saveUsersList = (newUsers: UserAccount[]) => {
    setUsers(newUsers);
    try {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(newUsers));
      if ("BroadcastChannel" in window) {
        new BroadcastChannel(SYNC_CHANNEL_NAME).postMessage({ type: "users-updated" });
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Sync users across tabs
  useEffect(() => {
    const handleStorage = (e: StorageEvent) => {
      if (e.key === USERS_STORAGE_KEY && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          if (Array.isArray(parsed)) setUsers(parsed);
        } catch (err) {
          console.error(err);
        }
      }
    };
    window.addEventListener("storage", handleStorage);

    let channel: BroadcastChannel | null = null;
    if ("BroadcastChannel" in window) {
      channel = new BroadcastChannel(SYNC_CHANNEL_NAME);
      channel.onmessage = (event) => {
        if (event.data?.type === "users-updated") {
          try {
            const saved = localStorage.getItem(USERS_STORAGE_KEY);
            if (saved) {
              const parsed = JSON.parse(saved);
              if (Array.isArray(parsed)) setUsers(parsed);
            }
          } catch (err) {
            console.error(err);
          }
        }
      };
    }

    return () => {
      window.removeEventListener("storage", handleStorage);
      channel?.close();
    };
  }, []);

  // Mode settings
  const [modeSettings, setModeSettings] = useState<{
    mode: string;
    strength: string;
    duration: string;
    applied: boolean;
  }>(() => {
    try {
      const saved = JSON.parse(sessionStorage.getItem(MODE_STORAGE_KEY) || "");
      if (saved && MODE_CONFIG[saved.mode]) {
        return saved;
      }
    } catch {}
    return { mode: "", strength: "", duration: "", applied: false };
  });

  const [modeMessage, setModeMessage] = useState("");

  const saveModeSettingsToStorage = (settings: typeof modeSettings) => {
    setModeSettings(settings);
    sessionStorage.setItem(MODE_STORAGE_KEY, JSON.stringify(settings));
  };

  // Scanner State
  const [market, setMarket] = useState("MATCHES");
  const [volatility, setVolatility] = useState("Volatility 10 (1s) Index");
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [predictions, setPredictions] = useState<SignalData[]>([]);
  const [activeSignal, setActiveSignal] = useState<SignalData | null>(null);

  // Ratings
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [rated, setRated] = useState(false);

  // Admin form
  const [newAdminUsername, setNewAdminUsername] = useState("");
  const [newAdminPassword, setNewAdminPassword] = useState("");
  const [adminFeedback, setAdminFeedback] = useState("");

  // Live Market Opportunity generator
  const [opportunity, setOpportunity] = useState<{
    volatility: string;
    trend: number;
    risk: string;
    expiresAt: number;
    secondsLeft: number;
  }>(() => {
    const vol = VOLATILITY[Math.floor(Math.random() * VOLATILITY.length)];
    const trend = 91 + Math.floor(Math.random() * 8);
    return {
      volatility: vol,
      trend,
      risk: "Low",
      expiresAt: Date.now() + 120000,
      secondsLeft: 120,
    };
  });

  // Opportunity countdown timer
  useEffect(() => {
    const timer = setInterval(() => {
      setOpportunity((prev) => {
        const now = Date.now();
        if (now >= prev.expiresAt) {
          const vol = VOLATILITY[Math.floor(Math.random() * VOLATILITY.length)];
          const trend = 91 + Math.floor(Math.random() * 8);
          return {
            volatility: vol,
            trend,
            risk: "Low",
            expiresAt: now + 120000,
            secondsLeft: 120,
          };
        }
        return {
          ...prev,
          secondsLeft: Math.max(0, Math.ceil((prev.expiresAt - now) / 1000)),
        };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Market Intelligence read
  const [intelligence, setIntelligence] = useState(() => generateMarketIntelligence());

  function generateMarketIntelligence() {
    const clarity = 82 + Math.floor(Math.random() * 17);
    const noise = 100 - clarity + Math.floor(Math.random() * 10);
    const digitPattern = 80 + Math.floor(Math.random() * 18);
    const volatilityStrength = 81 + Math.floor(Math.random() * 17);
    const entryTiming = 79 + Math.floor(Math.random() * 19);
    const matchesMatrix = Math.min(
      99,
      Math.round((clarity + digitPattern + entryTiming) / 3) + Math.floor(Math.random() * 5)
    );
    const risk: "Low" | "Medium" | "High" =
      clarity < 75 ? "High" : clarity >= 86 && matchesMatrix >= 86 ? "Low" : "Medium";
    const patterns = [
      "Repeating digit pressure detected",
      "Volatility spike forming",
      "Even/Odd imbalance detected",
      "Over/Under bias building",
      "Market noise level reducing",
      "Digit cluster forming near entry zone",
    ];
    const waitAlert =
      risk === "High"
        ? "Wait. Market is unstable."
        : risk === "Medium"
        ? "Proceed carefully. Confirm mode settings before scanning."
        : "Market condition is clean. Scanner is ready.";
    return {
      clarity,
      risk,
      pattern: patterns[Math.floor(Math.random() * patterns.length)],
      waitAlert,
      breakdown: {
        "Market Trend": Math.min(98, clarity + Math.floor(Math.random() * 8)),
        "Digit Pattern": digitPattern,
        "Volatility Strength": volatilityStrength,
        "Entry Timing": entryTiming,
        "Matches Matrix": matchesMatrix,
        "Noise Filter": Math.max(52, 100 - noise),
      },
    };
  }

  // Live Digit Analysis data
  const [digitCursor, setDigitCursor] = useState(() => Math.floor(Math.random() * 10));
  const [digitRows, setDigitRows] = useState(() =>
    Array.from({ length: 10 }, (_, digit) => {
      const val = 8 + Math.floor(Math.random() * 86);
      return { digit, value: val, height: 42 + Math.round((val / 100) * 142) };
    })
  );
  const [liveTape, setLiveTape] = useState(() =>
    Array.from({ length: 18 }, () => Math.floor(Math.random() * 10))
  );

  // Periodically update digit analysis panel when not running
  useEffect(() => {
    if (view !== "dashboard" || running) return;
    const interval = setInterval(() => {
      setDigitCursor(Math.floor(Math.random() * 10));
      setDigitRows(
        Array.from({ length: 10 }, (_, digit) => {
          const val = 8 + Math.floor(Math.random() * 86);
          return { digit, value: val, height: 42 + Math.round((val / 100) * 142) };
        })
      );
      setLiveTape(Array.from({ length: 18 }, () => Math.floor(Math.random() * 10)));
      setIntelligence(generateMarketIntelligence());
    }, 7000);
    return () => clearInterval(interval);
  }, [view, running]);

  // Scanner Progress Simulation
  useEffect(() => {
    if (!running) return;
    const interval = setInterval(() => {
      setProgress((prev) => {
        const next = prev + Math.random() * 5 + 3;
        if (next >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            triggerSignal();
          }, 500);
          return 100;
        }
        return next;
      });
    }, 450);

    return () => clearInterval(interval);
  }, [running]);

  const triggerSignal = () => {
    const digit = String(Math.floor(Math.random() * 10));
    const intel = generateMarketIntelligence();
    const matrixScore = intel.breakdown["Matches Matrix"] || 84;
    const confidence = Math.min(
      98,
      Math.max(
        82,
        Math.round(intel.clarity * 0.34 + matrixScore * 0.38 + intel.breakdown["Entry Timing"] * 0.28) +
          Math.floor(Math.random() * 4)
      )
    );

    let reason = `Digit ${digit} appeared after the Deriv Matches Matrix detected ${intel.pattern.toLowerCase()} with a ${intel.risk.toLowerCase()} risk filter.`;
    const num = Number(digit);
    if (market === "EVEN / ODD") {
      reason = `Digit ${digit} supports a ${num % 2 === 0 ? "clean EVEN" : "clean ODD"} read while ${intel.pattern.toLowerCase()} and clarity holds at ${intel.clarity}%.`;
    } else if (market === "OVER / UNDER") {
      reason = `Digit ${digit} supports an ${num >= 5 ? "OVER" : "UNDER"} bias while volatility strength and timing are aligned.`;
    }

    const newSig: SignalData = {
      id: String(Date.now()),
      market,
      volatility,
      digit,
      confidence,
      matrixScore,
      reason,
      risk: intel.risk,
      countdown: SIGNAL_COUNTDOWN_SECONDS,
      timestamp: new Date(),
    };

    setPredictions((prev) => [newSig, ...prev].slice(0, 5));
    setActiveSignal(newSig);
    setRunning(false);
    setProgress(0);
  };

  // Signal Countdown Timer
  useEffect(() => {
    if (!activeSignal) return;

    if (activeSignal.countdown <= 0) {
      const holdTimeout = setTimeout(() => {
        setActiveSignal(null);
      }, SIGNAL_ZERO_HOLD_MS);
      return () => clearTimeout(holdTimeout);
    }

    const timer = setInterval(() => {
      setActiveSignal((prev) => {
        if (!prev) return null;
        if (prev.countdown <= 1) {
          clearInterval(timer);
          return { ...prev, countdown: 0 };
        }
        return { ...prev, countdown: prev.countdown - 1 };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [activeSignal]);

  const handleStartScan = () => {
    if (!modeSettings.applied) {
      setModeMessage("Apply mode settings before starting the scanner.");
      return;
    }
    setRunning(true);
    setProgress(0);
    setActiveSignal(null);
  };

  const handleStopScan = () => {
    setRunning(false);
    setProgress(0);
    setActiveSignal(null);
  };

  const handleLogout = () => {
    setRunning(false);
    setProgress(0);
    setActiveSignal(null);
    setCurrentUser(null);
    setLoginMode("user");
    setView("login");
    setErrorMsg("");
    setNoticeMsg("");
  };

  // Google Admin Sign-in handler
  const handleGoogleSignIn = (
    adminEmail = "abinetmake@gmail.com",
    adminName = "Abinet"
  ) => {
    setErrorMsg("");
    setNoticeMsg("");
    let adminAccount = users.find((u) => u.role === "admin");
    if (!adminAccount) {
      adminAccount = {
        username: adminEmail,
        password: "[Google Account]",
        active: true,
        approved: true,
        role: "admin",
        loginCount: 1,
        lastLogin: new Date().toLocaleString(),
      };
    } else {
      adminAccount = {
        ...adminAccount,
        username: adminEmail,
        loginCount: (adminAccount.loginCount || 0) + 1,
        lastLogin: new Date().toLocaleString(),
      };
    }
    const updated = users.map((u) => (u.role === "admin" ? adminAccount! : u));
    if (!updated.some((u) => u.username === adminAccount!.username)) {
      updated.unshift(adminAccount);
    }
    saveUsersList(updated);
    setCurrentUser(adminAccount);
    setView("admin");
  };

  // Login handler
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const uname = usernameInput.trim();
    const pwd = passwordInput;
    setErrorMsg("");
    setNoticeMsg("");

    if (!uname || !pwd) {
      setErrorMsg("Please enter both username and password");
      return;
    }

    if (loginMode === "request") {
      if (pwd !== confirmPasswordInput) {
        setErrorMsg("Passwords do not match");
        return;
      }
      if (users.some((u) => normalizeUsername(u.username) === normalizeUsername(uname))) {
        setErrorMsg("Username is already taken");
        return;
      }
      const newUser: UserAccount = {
        username: uname,
        password: pwd,
        active: false,
        approved: false,
        pending: true,
        role: "user",
        loginCount: 0,
        lastLogin: "",
        createdAt: new Date().toISOString(),
      };
      saveUsersList([...users, newUser]);
      setNoticeMsg("Your account request was saved. An admin must approve it before you can log in.");
      setLoginMode("user");
      setUsernameInput("");
      setPasswordInput("");
      setConfirmPasswordInput("");
      return;
    }

    if (loginMode === "admin") {
      if (normalizeUsername(uname) !== normalizeUsername(ADMIN_ACCESS_USERNAME) || pwd !== ADMIN_ACCESS_PASSWORD) {
        setErrorMsg("Invalid admin username or password");
        return;
      }
      let adminAccount = users.find((u) => u.role === "admin");
      if (!adminAccount) {
        adminAccount = {
          username: "Water",
          password: "land1234",
          active: true,
          approved: true,
          role: "admin",
          loginCount: 1,
          lastLogin: new Date().toLocaleString(),
        };
      } else {
        adminAccount = {
          ...adminAccount,
          loginCount: (adminAccount.loginCount || 0) + 1,
          lastLogin: new Date().toLocaleString(),
        };
      }
      const updated = users.map((u) => (u.username === adminAccount!.username ? adminAccount! : u));
      if (!users.some((u) => u.username === adminAccount!.username)) updated.push(adminAccount);
      saveUsersList(updated);
      setCurrentUser(adminAccount);
      setView("admin");
      return;
    }

    // Regular User Login
    const account = users.find((u) => normalizeUsername(u.username) === normalizeUsername(uname) && u.password === pwd);
    if (!account) {
      setErrorMsg("Invalid username or password");
      return;
    }
    if (!account.approved) {
      setErrorMsg("Your account is waiting for admin approval");
      return;
    }
    if (!account.active) {
      setErrorMsg("This account is inactive. Contact admin.");
      return;
    }

    const updatedAccount = {
      ...account,
      loginCount: (account.loginCount || 0) + 1,
      lastLogin: new Date().toLocaleString(),
    };
    saveUsersList(users.map((u) => (u.username === account.username ? updatedAccount : u)));
    setCurrentUser(updatedAccount);
    setView("welcome");
  };

  // Admin Actions
  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    const uname = newAdminUsername.trim();
    const pwd = newAdminPassword;
    if (!uname || !pwd) return;

    if (users.some((u) => normalizeUsername(u.username) === normalizeUsername(uname))) {
      setAdminFeedback("That username already exists.");
      return;
    }
    const newUser: UserAccount = {
      username: uname,
      password: pwd,
      active: true,
      approved: true,
      role: "user",
      loginCount: 0,
      lastLogin: "",
      createdAt: new Date().toISOString(),
    };
    saveUsersList([...users, newUser]);
    setNewAdminUsername("");
    setNewAdminPassword("");
    setAdminFeedback(`${uname} is active. Log out, choose User Login, and use the new username and password.`);
  };

  const handleApproveUser = (usernameToApprove: string) => {
    const updated = users.map((u) => (u.username === usernameToApprove ? { ...u, approved: true, active: true } : u));
    saveUsersList(updated);
    setAdminFeedback(`${usernameToApprove} is now approved and active.`);
  };

  const handleToggleUser = (usernameToToggle: string) => {
    const updated = users.map((u) =>
      u.username === usernameToToggle ? { ...u, active: !u.active, approved: u.approved || !u.active } : u
    );
    const target = updated.find((u) => u.username === usernameToToggle);
    saveUsersList(updated);
    setAdminFeedback(`${usernameToToggle} is now ${target?.active ? "active" : "deactivated"}.`);
  };

  const handleDeleteUser = (usernameToDelete: string) => {
    const updated = users.filter((u) => u.username !== usernameToDelete);
    saveUsersList(updated);
    setAdminFeedback(`${usernameToDelete} has been deleted.`);
  };

  // Candles preview data
  const miniCandles = [
    { type: "up", wick: 62, body: 28, offset: 18, delay: 0 },
    { type: "down", wick: 78, body: 36, offset: 30, delay: 1 },
    { type: "up", wick: 54, body: 22, offset: 42, delay: 2 },
    { type: "up", wick: 86, body: 44, offset: 24, delay: 3 },
    { type: "down", wick: 68, body: 30, offset: 36, delay: 4 },
    { type: "up", wick: 74, body: 34, offset: 20, delay: 5 },
    { type: "down", wick: 58, body: 24, offset: 44, delay: 6 },
    { type: "up", wick: 90, body: 48, offset: 16, delay: 7 },
    { type: "up", wick: 64, body: 26, offset: 34, delay: 8 },
    { type: "down", wick: 80, body: 38, offset: 22, delay: 9 },
    { type: "up", wick: 72, body: 32, offset: 28, delay: 10 },
    { type: "down", wick: 60, body: 24, offset: 40, delay: 11 },
  ];

  // Radar Matrix Digits
  const matrixDigits = useMemo(() => {
    return Array.from({ length: 12 }, (_, index) => {
      const d = Math.floor(Math.random() * 10);
      const angle = index * 30;
      return { digit: d, angle, delay: index };
    });
  }, []);

  const selectedModeConfig = modeSettings.mode ? MODE_CONFIG[modeSettings.mode] : null;

  return (
    <div id="app">
      {/* ============================================================ */}
      {/* 1. LOGIN SCREEN                                              */}
      {/* ============================================================ */}
      {view === "login" && (
        <main className="screen login-screen fintech-login-screen">
          <div className="market-status-widget">
            <span>Market Status</span>
            <strong>ACTIVE</strong>
            <i />
          </div>

          <section className="fintech-hero">
            <div className="fintech-logo robot-logo" aria-hidden="true">
              <img src={ROBOT_IMAGE} alt="Profit Tracker Robot" />
            </div>
            <div>
              <h1>
                PROFIT <span>TRACKER</span>
              </h1>
              <p>Deriv Analysis Tool</p>
            </div>
          </section>

          <section className="login-grid fintech-login-grid">
            <div className="login-visual-panel robot-visual-panel" aria-hidden="true">
              <div className="robot-showcase">
                <img src={ROBOT_IMAGE} alt="AI Scanner Bot" />
              </div>
              <div className="smart-analysis-copy">
                <strong>Smart Analysis</strong>
                <span>Powerful insights</span>
                <span>Maximum profits</span>
              </div>
            </div>

            <div className="card login-card fintech-login-card">
              <div className="login-head fintech-login-head">
                <h2>
                  {loginMode === "request"
                    ? "Request Access"
                    : loginMode === "admin"
                    ? "Admin Portal"
                    : "Welcome Back"}
                </h2>
                <p>
                  {loginMode === "admin"
                    ? "Sign in with your Google Account for administrator access"
                    : "Secure access for precision market analysis"}
                </p>
              </div>

              <div className="form-area">
                {errorMsg && <div className="error">{errorMsg}</div>}
                {noticeMsg && <div className="success">{noticeMsg}</div>}

                <div className="field access-type-field">
                  <label>Access Type</label>
                  <div className="mode-row">
                    <button
                      className={`mode access-card ${loginMode === "user" ? "active" : ""}`}
                      type="button"
                      onClick={() => {
                        setLoginMode("user");
                        setErrorMsg("");
                      }}
                    >
                      <span className="access-icon">U</span>
                      <strong>User Login</strong>
                    </button>
                    <button
                      className={`mode access-card ${loginMode === "admin" ? "active" : ""}`}
                      type="button"
                      onClick={() => {
                        setLoginMode("admin");
                        setErrorMsg("");
                      }}
                    >
                      <span className="access-icon gold">A</span>
                      <strong>Admin</strong>
                    </button>
                    <button
                      className={`mode access-card ${loginMode === "request" ? "active" : ""}`}
                      type="button"
                      onClick={() => {
                        setLoginMode("request");
                        setErrorMsg("");
                      }}
                    >
                      <span className="access-icon">+</span>
                      <strong>New User</strong>
                    </button>
                  </div>
                </div>

                {loginMode === "admin" ? (
                  <div className="google-admin-auth-pane">
                    <button
                      type="button"
                      className="btn google-sign-in-btn"
                      onClick={() => handleGoogleSignIn()}
                    >
                      <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">
                        <path
                          fill="#4285F4"
                          d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                        />
                        <path
                          fill="#34A853"
                          d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                        />
                        <path
                          fill="#FBBC05"
                          d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                        />
                        <path
                          fill="#EA4335"
                          d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                        />
                      </svg>
                      <span>Sign in with Google Account</span>
                    </button>

                    <div className="google-account-card">
                      <div className="google-account-header">
                        <span>Administrator Google Account</span>
                        <span className="google-badge-verified">Verified Admin</span>
                      </div>
                      <div className="google-account-body">
                        <div className="google-account-avatar">
                          <span>A</span>
                        </div>
                        <div className="google-account-details">
                          <strong>Abinet (Administrator)</strong>
                          <small>abinetmake@gmail.com</small>
                        </div>
                        <button
                          type="button"
                          className="btn small green"
                          onClick={() => handleGoogleSignIn("abinetmake@gmail.com", "Abinet")}
                        >
                          Authorize
                        </button>
                      </div>
                    </div>

                    {showCustomGoogleInput ? (
                      <div className="custom-google-box">
                        <input
                          type="email"
                          placeholder="Enter Google email (e.g. admin@gmail.com)"
                          value={customGoogleEmail}
                          onChange={(e) => setCustomGoogleEmail(e.target.value)}
                          className="custom-google-input"
                        />
                        <button
                          type="button"
                          className="btn small blue"
                          onClick={() => {
                            const email = customGoogleEmail.trim();
                            if (email) {
                              handleGoogleSignIn(email, email.split("@")[0]);
                            }
                          }}
                        >
                          Continue
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        className="btn-text-link"
                        onClick={() => setShowCustomGoogleInput(true)}
                      >
                        Sign in with a different Google account
                      </button>
                    )}
                  </div>
                ) : (
                  <form onSubmit={handleLoginSubmit}>
                    <div className="field premium-field">
                      <label htmlFor="username">Username</label>
                      <div className="input-shell">
                        <span className="input-icon" aria-hidden="true">
                          <svg viewBox="0 0 24 24" focusable="false">
                            <path d="M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4Zm0 2c-4.42 0-8 2.24-8 5v1h16v-1c0-2.76-3.58-5-8-5Z" />
                          </svg>
                        </span>
                        <input
                          id="username"
                          value={usernameInput}
                          onChange={(e) => setUsernameInput(e.target.value)}
                          autoComplete="username"
                          placeholder="Enter your username"
                        />
                      </div>
                    </div>

                    <div className="field premium-field">
                      <label htmlFor="password">Password</label>
                      <div className="input-shell">
                        <span className="input-icon" aria-hidden="true">
                          <svg viewBox="0 0 24 24" focusable="false">
                            <path d="M17 9V7A5 5 0 0 0 7 7v2H5v12h14V9h-2ZM9 7a3 3 0 0 1 6 0v2H9V7Zm4 9.73V18h-2v-1.27a2 2 0 1 1 2 0Z" />
                          </svg>
                        </span>
                        <input
                          id="password"
                          type="password"
                          value={passwordInput}
                          onChange={(e) => setPasswordInput(e.target.value)}
                          autoComplete={loginMode === "request" ? "new-password" : "current-password"}
                          placeholder="Enter your password"
                        />
                      </div>
                    </div>

                    {loginMode === "request" && (
                      <div className="field premium-field">
                        <label htmlFor="confirmPassword">Confirm Password</label>
                        <div className="input-shell">
                          <span className="input-icon" aria-hidden="true">
                            <svg viewBox="0 0 24 24" focusable="false">
                              <path d="M17 9V7A5 5 0 0 0 7 7v2H5v12h14V9h-2ZM9 7a3 3 0 0 1 6 0v2H9V7Zm4 9.73V18h-2v-1.27a2 2 0 1 1 2 0Z" />
                            </svg>
                          </span>
                          <input
                            id="confirmPassword"
                            type="password"
                            value={confirmPasswordInput}
                            onChange={(e) => setConfirmPasswordInput(e.target.value)}
                            autoComplete="new-password"
                            placeholder="Confirm your password"
                          />
                        </div>
                      </div>
                    )}

                    <button className="btn primary fintech-submit" type="submit">
                      <span>
                        {loginMode === "request" ? "Request Admin Approval" : "User Login"}
                      </span>
                      <b aria-hidden="true">-&gt;</b>
                    </button>
                  </form>
                )}

                <a
                  className="btn whatsapp fintech-whatsapp"
                  id="accessBtn"
                  href={getWhatsappUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Contact PROFIT TRACKER on WhatsApp"
                >
                  <span className="whatsapp-icon exact-whatsapp-icon" aria-hidden="true">
                    <img src={WHATSAPP_IMAGE} alt="WhatsApp" />
                  </span>
                  <span className="whatsapp-copy">
                    <strong>WhatsApp Access</strong>
                    <small>Instant Free Access</small>
                  </span>
                  <b aria-hidden="true">-&gt;</b>
                </a>
              </div>
            </div>
          </section>

          <section className="premium-footer-grid">
            <div className="card premium-feature-card">
              <span>OK</span>
              <strong>Accurate Signals</strong>
              <small>High probability trading signals</small>
            </div>
            <div className="card premium-feature-card">
              <span>RT</span>
              <strong>Real-Time Analysis</strong>
              <small>Market moves, we track</small>
            </div>
            <div className="card premium-feature-card">
              <span>AI</span>
              <strong>Smart Strategy</strong>
              <small>Data-driven decisions</small>
            </div>
            <div className="card premium-feature-card">
              <span className="euro-image-badge">
                <img src={EURO_IMAGE} alt="Euro" />
              </span>
              <strong>Maximize Profits</strong>
              <small>Trade smarter, earn more</small>
            </div>
          </section>

          <div className="premium-trust-row">
            <span>Secure</span>
            <i />
            <span>Reliable</span>
            <i />
            <span>Professional</span>
          </div>

          {/* WhatsApp AI Assistant Button */}
          <a
            className="ai-chat-agent"
            href={getWhatsappUrl("Hello PROFIT TRACKER AI, I need help using the tool. Please assist me.")}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Chat with PROFIT TRACKER AI on WhatsApp"
          >
            <span className="ai-chat-icon">AI</span>
            <span className="ai-chat-copy">
              <strong>AI Assistant</strong>
              <small>How can I help you?</small>
            </span>
          </a>
        </main>
      )}

      {/* ============================================================ */}
      {/* 2. WELCOME SCREEN                                            */}
      {/* ============================================================ */}
      {view === "welcome" && currentUser && (
        <main className="screen welcome-screen">
          <section className="card welcome-card">
            <div className="welcome-head">
              <h1>Welcome, {currentUser.username}!</h1>
              <p>PROFIT TRACKER - Deriv Analysis Tool</p>
            </div>
            <div className="welcome-body">
              <h2>Ready to Scan Markets?</h2>
              <div className="copy">
                <p>
                  <strong>Real-time Market Scanning:</strong> The scanner checks Deriv Volatility indices continuously
                  to identify trading opportunities.
                </p>
                <p>
                  <strong>Probability-Based Analysis:</strong> Every prediction includes a confidence score for consistent
                  use.
                </p>
                <p>
                  <strong>Designed for Consistency:</strong> Built for repeatable results across changing market conditions.
                </p>
                <p>
                  <strong>Easy-to-Use Automation:</strong> Select your market and volatility index, then press START.
                </p>
              </div>
              <div className="feature-grid">
                <div className="feature-box">
                  <h3>Multiple Markets</h3>
                  <p>Matches, Even/Odd, Over/Under and more</p>
                </div>
                <div className="feature-box">
                  <h3>All Volatility Indices</h3>
                  <p>From Volatility 10 to 250 indices</p>
                </div>
                <div className="feature-box">
                  <h3>Accurate Predictions</h3>
                  <p>Confidence scores with every signal</p>
                </div>
                <div className="feature-box">
                  <h3>Smart Controls</h3>
                  <p>Start and stop scanning instantly</p>
                </div>
              </div>
              <button className="btn primary" id="enterDash" onClick={() => setView("dashboard")}>
                Enter Scanner Dashboard
              </button>
            </div>
          </section>
        </main>
      )}

      {/* ============================================================ */}
      {/* 3. DASHBOARD SCREEN                                          */}
      {/* ============================================================ */}
      {view === "dashboard" && currentUser && (
        <main className="dash-screen">
          {/* Signal Prediction Modal */}
          {activeSignal && (
            <div className="signal">
              <div className="signal-box">
                <span className="signal-badge">Signal Detected</span>
                <p>
                  <strong>{activeSignal.market}</strong>
                </p>
                <div className="signal-digit">{activeSignal.digit}</div>
                {activeSignal.market === "EVEN / ODD" && (
                  <div className="signal-label">{Number(activeSignal.digit) % 2 === 0 ? "EVEN" : "ODD"}</div>
                )}
                {activeSignal.market === "OVER / UNDER" && (
                  <div className="signal-label">{Number(activeSignal.digit) >= 5 ? "OVER" : "UNDER"}</div>
                )}
                <div className="confidence">{activeSignal.confidence}%</div>
                <p>Win Confidence</p>
                {activeSignal.reason && (
                  <div className="signal-reason">
                    <strong>Signal Reason</strong>
                    <span>{activeSignal.reason}</span>
                  </div>
                )}
                <div className="countdown" aria-label="Signal countdown">
                  {String(Math.max(0, activeSignal.countdown)).padStart(2, "0")}s
                </div>
                <p>Load to Bot - scanner stops after this signal</p>
              </div>
            </div>
          )}

          {/* Dashboard Header */}
          <header className="dash-head">
            <div className="bar">
              <div className="brand">
                <div className="logo euro-logo">
                  <img src={EURO_IMAGE} alt="Profit Tracker Logo" />
                </div>
                <div>
                  <h1>PROFIT TRACKER</h1>
                  <p>Welcome, {currentUser.username}</p>
                </div>
              </div>
              <button className="btn danger" id="logout" onClick={handleLogout}>
                Logout
              </button>
            </div>
          </header>

          <section className="main">
            {/* Top Stat Cards */}
            <div className="stats">
              <div className="card stat">
                <div className="stat-icon">A</div>
                <div>
                  <small>Status</small>
                  <strong>{running ? "LIVE" : "READY"}</strong>
                </div>
              </div>
              <div className="card stat">
                <div className="stat-icon">C</div>
                <div>
                  <small>Predictions</small>
                  <strong>{predictions.length}</strong>
                </div>
              </div>
              <div className="card stat">
                <div className="stat-icon">T</div>
                <div>
                  <small>Accuracy</small>
                  <strong>87.5%</strong>
                </div>
              </div>
              <div className="card stat">
                <div className="stat-icon">S</div>
                <div>
                  <small>Market</small>
                  <strong>{market}</strong>
                </div>
              </div>
            </div>

            {/* Mode Configuration Card */}
            <section className="card mode-config-card">
              <div className="mode-config-head">
                <div>
                  <span className="mode-kicker">Signal Mode Configuration</span>
                  <h2>Activate Your Trading Mode</h2>
                  <p>
                    Choose a mode, signal strength, and trade duration before scanning. Signals stay locked until
                    settings are applied.
                  </p>
                </div>
                <div className={`mode-state ${modeSettings.applied ? "active" : ""}`}>
                  {modeSettings.applied ? "Settings Active" : "Setup Required"}
                </div>
              </div>

              <div className="mode-grid">
                {Object.entries(MODE_CONFIG).map(([key, config]) => (
                  <button
                    key={key}
                    className={`mode-card ${modeSettings.mode === key ? "selected" : ""}`}
                    type="button"
                    disabled={running}
                    onClick={() => {
                      saveModeSettingsToStorage({
                        mode: key,
                        strength: "",
                        duration: "",
                        applied: false,
                      });
                      setModeMessage("");
                    }}
                  >
                    <span>{config.name}</span>
                    {config.badge && <strong>{config.badge}</strong>}
                    <small>{config.description}</small>
                  </button>
                ))}
              </div>

              <div className="mode-fields">
                <div className="field">
                  <label htmlFor="signalStrength">Signal Strength</label>
                  <select
                    id="signalStrength"
                    disabled={!selectedModeConfig || running}
                    value={modeSettings.strength}
                    onChange={(e) => {
                      saveModeSettingsToStorage({
                        ...modeSettings,
                        strength: e.target.value,
                        applied: false,
                      });
                    }}
                  >
                    <option value="">Select strength</option>
                    {(selectedModeConfig?.strengths || []).map((str) => (
                      <option key={str} value={str}>
                        {str}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="field">
                  <label htmlFor="tradeDuration">Trade Duration</label>
                  <select
                    id="tradeDuration"
                    disabled={!selectedModeConfig || running}
                    value={modeSettings.duration}
                    onChange={(e) => {
                      saveModeSettingsToStorage({
                        ...modeSettings,
                        duration: e.target.value,
                        applied: false,
                      });
                    }}
                  >
                    <option value="">Select duration</option>
                    {(selectedModeConfig?.durations || []).map((dur) => (
                      <option key={dur} value={dur}>
                        {dur}
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  className="btn primary apply-settings"
                  id="applySettings"
                  disabled={!modeSettings.mode || !modeSettings.strength || !modeSettings.duration || running}
                  onClick={() => {
                    if (!modeSettings.mode || !modeSettings.strength || !modeSettings.duration) {
                      setModeMessage("Select a mode, signal strength, and trade duration before applying.");
                      saveModeSettingsToStorage({ ...modeSettings, applied: false });
                    } else {
                      saveModeSettingsToStorage({ ...modeSettings, applied: true });
                      setModeMessage("Settings Applied Successfully.");
                    }
                  }}
                >
                  Apply Settings
                </button>
              </div>

              {modeSettings.applied && selectedModeConfig && (
                <div className="settings-summary">
                  <strong>Settings Applied Successfully.</strong>
                  <span>
                    {selectedModeConfig.name} / {modeSettings.strength} / {modeSettings.duration}
                  </span>
                </div>
              )}

              {modeMessage && (
                <div className={modeSettings.applied ? "success" : "error"}>{modeMessage}</div>
              )}
            </section>

            {/* Market Intelligence Panel */}
            <section className="card intelligence-card" data-market-intelligence>
              <div className="intel-head">
                <div>
                  <span className="mode-kicker">Market Intelligence Panel</span>
                  <h2>Hidden Market Read</h2>
                  <p>This panel reads clarity, pattern pressure, volatility strength, timing, and risk before signals are shown.</p>
                </div>
                <div className="clarity-score">
                  <span>Market Clarity</span>
                  <strong>{intelligence.clarity}%</strong>
                </div>
              </div>

              <div className="intel-grid">
                <div className="intel-tile pattern">
                  <span>Pattern Detected</span>
                  <strong>{intelligence.pattern}</strong>
                </div>
                <div className={`intel-tile risk-${intelligence.risk.toLowerCase()}`}>
                  <span>Risk Level</span>
                  <strong>{intelligence.risk}</strong>
                </div>
                <div className="intel-tile wait">
                  <span>Smart Wait Alert</span>
                  <strong>{intelligence.waitAlert}</strong>
                </div>
              </div>

              <div className="volatility-opportunity">
                <div>
                  <span>Volatility Detected</span>
                  <strong>{opportunity.volatility}</strong>
                  <p>
                    Market trend is above {opportunity.trend}%. Risk level is low, and this is the current recommended volatility to trade.
                  </p>
                </div>
                <div className="opportunity-score">
                  <span>Trend Strength</span>
                  <strong>{opportunity.trend}%</strong>
                  <small>Changes in {opportunity.secondsLeft}s</small>
                </div>
              </div>

              <div className="intel-breakdown">
                {Object.entries(intelligence.breakdown).map(([lbl, val]) => (
                  <div className="intel-meter" key={lbl}>
                    <span>{lbl}</span>
                    <strong>{val}%</strong>
                    <i>
                      <b style={{ width: `${val}%` }} />
                    </i>
                  </div>
                ))}
              </div>
            </section>

            {/* Scanner Controls Card */}
            <section className="card control-card">
              <div className="control-grid">
                <div className="scanner-intro">
                  <div className="big-logo euro-logo">
                    <img src={EURO_IMAGE} alt="AI Scanner" />
                  </div>
                  <h2>Advanced AI Scanner</h2>
                  <p>Powered by machine learning style scoring for precise Deriv market predictions.</p>
                  <div className="pill">
                    <span className={`dot ${running ? "live" : ""}`} />
                    {running ? "Analysis Running" : "Ready to Scan"}
                  </div>
                </div>

                <div className="controls">
                  <h3>Scanner Controls</h3>
                  <div className="field">
                    <label htmlFor="market">Market Type</label>
                    <select
                      id="market"
                      disabled={running}
                      value={market}
                      onChange={(e) => setMarket(e.target.value)}
                    >
                      {MARKETS.map((m) => (
                        <option key={m} value={m}>
                          {m}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="field">
                    <label htmlFor="volatility">Volatility Index</label>
                    <select
                      id="volatility"
                      disabled={running}
                      value={volatility}
                      onChange={(e) => setVolatility(e.target.value)}
                    >
                      {VOLATILITY.map((v) => (
                        <option key={v} value={v}>
                          {v}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="button-row">
                    <button
                      className="btn green"
                      id="start"
                      disabled={running || !modeSettings.applied}
                      onClick={handleStartScan}
                    >
                      START
                    </button>
                    <button className="btn danger" id="stop" disabled={!running} onClick={handleStopScan}>
                      STOP
                    </button>
                  </div>

                  {/* Animated Mini Candlesticks */}
                  <div className="mini-market" aria-label="Animated candlestick market preview">
                    <div className="mini-market-head">
                      <span className="dot live" />
                      <strong>Live Market Pulse</strong>
                    </div>
                    <div className="mini-candles">
                      {miniCandles.map((c, i) => (
                        <span
                          key={i}
                          className={`mini-candle ${c.type}`}
                          style={
                            {
                              "--wick": `${c.wick}px`,
                              "--body": `${c.body}px`,
                              "--offset": `${c.offset}px`,
                              "--delay": c.delay,
                            } as React.CSSProperties
                          }
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Network Scanner Card */}
            <section className="card progress-card network-scanner-card">
              <div className="scanner-panel">
                <div
                  className={`network-scanner ${running ? "is-running" : ""}`}
                  style={{ "--progress": Math.round(progress) } as React.CSSProperties}
                  data-scanner
                >
                  <div className="scanner-orbit orbit-one" />
                  <div className="scanner-orbit orbit-two" />
                  <div className="scanner-orbit orbit-three" />
                  <span className="network-node node-one" />
                  <span className="network-node node-two" />
                  <span className="network-node node-three" />

                  <div className="scanner-core">
                    <img src={SCANNER_IMAGE} alt="Global network scanner" />
                    <div className="scanner-matrix" aria-hidden="true">
                      <span className="matrix-ring ring-a" />
                      <span className="matrix-ring ring-b" />
                      <span className="matrix-ring ring-c" />
                      <span className="matrix-cross x" />
                      <span className="matrix-cross y" />
                      <span className="matrix-beam" />
                      {matrixDigits.map((md, idx) => (
                        <span
                          key={idx}
                          className="matrix-digit"
                          style={
                            {
                              "--angle": `${md.angle}deg`,
                              "--delay": `${md.delay}`,
                            } as React.CSSProperties
                          }
                        >
                          {md.digit}
                        </span>
                      ))}
                    </div>
                    <div className="scanner-sweep" />
                    <strong data-scanner-percent>{Math.round(progress)}%</strong>
                  </div>
                </div>

                <div className="scanner-status">
                  <span>Deriv Matches Matrix Scan</span>
                  <strong>{volatility}</strong>
                  <div className="scanner-progress-track">
                    <span style={{ width: `${Math.round(progress)}%` }} data-scanner-bar />
                  </div>
                  <p data-scanner-message>
                    {running
                      ? "Scanning digit pressure, matches matrix, and entry timing..."
                      : "Scanner is ready. Choose your market and press START when you want to scan."}
                  </p>
                </div>
              </div>
            </section>

            {/* Digit Frequency Analysis */}
            <section className="card analysis-card" data-live-digit-analysis>
              <div className="live-analysis-head">
                <div>
                  <span className="live-label">
                    <span className="dot live" /> LIVE MARKET FREQUENCY
                  </span>
                  <h2>Digit Frequency Analysis</h2>
                </div>
                <strong className="cursor-readout">Cursor {digitCursor}</strong>
              </div>

              <div className="bars live-bars">
                <span className="live-cursor" style={{ left: `${digitCursor * 10 + 5}%` }}>
                  <b>{digitCursor}</b>
                </span>
                {digitRows.map((row) => (
                  <div className={`bar-col ${row.digit === digitCursor ? "active" : ""}`} key={row.digit}>
                    <span className="bar-value">{row.value}%</span>
                    <div className="bar-fill" style={{ height: `${row.height}px` }} />
                    <strong>{row.digit}</strong>
                  </div>
                ))}
              </div>

              <div className="digits">
                {Array.from({ length: 10 }, (_, i) => (
                  <button
                    className="digit"
                    key={i}
                    onClick={() => setDigitCursor(i)}
                  >
                    {i}
                  </button>
                ))}
              </div>

              <div className="live-number-strip">
                {liveTape.map((digit, index) => (
                  <span
                    key={index}
                    className={digit === digitCursor ? "hot" : ""}
                    style={{ "--delay": index } as React.CSSProperties}
                  >
                    {digit}
                  </span>
                ))}
              </div>

              <p className="live-analysis-note">
                <span className="dot live" /> Historical digit distribution board based on live market analysis
              </p>
            </section>

            {!running && (
              <section className="card empty-card">
                <p style={{ textAlign: "center", fontWeight: 900 }}>
                  Select Market &amp; Volatility Index, then click <span style={{ color: "#16a34a" }}>START</span> to begin scanning
                </p>
              </section>
            )}

            {/* Trading Strategies (shown when running) */}
            {running && (
              <section className="card strategy-card">
                <h2>Professional Trading Strategies</h2>
                <p>
                  <strong>Market:</strong> {market} | <strong>Volatility:</strong> {volatility}
                </p>
                <div className="strategy-grid">
                  {STRATEGIES.map(([name, desc, rsk]) => (
                    <div className="strategy" key={name}>
                      <h4>{name}</h4>
                      <p>{desc}</p>
                      <span className="risk">Risk: {rsk}</span>
                    </div>
                  ))}
                </div>
                <div className="trading-disclaimer">
                  <strong>Trading Disclaimer</strong>
                  <p>
                    Trading synthetic indices and volatility markets carries risk. Signals are for analysis and
                    education only, not guaranteed results. Use a clear risk limit, protect your capital, and never
                    trade with money you cannot afford to lose.
                  </p>
                </div>
              </section>
            )}

            {/* Rate App Section */}
            <section className="card rating-card">
              <h2>Rate PROFIT TRACKER</h2>
              <p>Your feedback helps us improve</p>
              <div className="stars" onMouseLeave={() => setHoverRating(0)}>
                {[1, 2, 3, 4, 5].map((i) => (
                  <button
                    key={i}
                    className={`star ${(hoverRating || rating) >= i ? "on" : ""}`}
                    disabled={rated}
                    onClick={() => setRating(i)}
                    onMouseEnter={() => setHoverRating(i)}
                  >
                    *
                  </button>
                ))}
              </div>
              <p>
                <strong>
                  {["Rate this app", "Poor", "Fair", "Good", "Very Good", "Excellent!"][hoverRating || rating || 0]}
                </strong>
              </p>
              {rated ? (
                <p>
                  <strong>Thank you for your feedback!</strong>
                  <br />
                  You rated us {rating} out of 5 stars
                </p>
              ) : (
                <button
                  className="btn blue"
                  id="submitRating"
                  disabled={!rating}
                  onClick={() => {
                    if (rating) setRated(true);
                  }}
                >
                  Submit Rating
                </button>
              )}
            </section>
          </section>

          {/* AI WhatsApp Assistant Floating Button */}
          <a
            className="ai-chat-agent"
            href={getWhatsappUrl("Hello PROFIT TRACKER AI, I need help using the tool. Please assist me.")}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Chat with PROFIT TRACKER AI on WhatsApp"
          >
            <span className="ai-chat-icon">AI</span>
            <span className="ai-chat-copy">
              <strong>AI Assistant</strong>
              <small>How can I help you?</small>
            </span>
          </a>
        </main>
      )}

      {/* ============================================================ */}
      {/* 4. ADMIN SCREEN                                              */}
      {/* ============================================================ */}
      {view === "admin" && currentUser && (
        <main className="admin-screen">
          <header className="admin-head">
            <div className="bar">
              <div>
                <h1 style={{ margin: 0 }}>Admin Management</h1>
                <p style={{ margin: 0, color: "rgba(255,255,255,.86)" }}>
                  Google Admin: <strong>{currentUser.username}</strong>
                </p>
              </div>
              <div className="actions">
                <span className="sync-chip">
                  <span className="dot live" />
                  Live updates
                </span>
                <button className="btn blue" id="toDashboard" onClick={() => setView("dashboard")}>
                  To Dashboard
                </button>
                <button className="btn danger" id="logout" onClick={handleLogout}>
                  Logout
                </button>
              </div>
            </div>
          </header>

          <section className="admin-main">
            {/* Admin Stats */}
            <div className="admin-stats">
              <div className="card admin-stat">
                <span>Active Users</span>
                <strong>{users.filter((u) => u.role !== "admin" && u.active && u.approved).length}</strong>
              </div>
              <div className="card admin-stat">
                <span>Pending Approval</span>
                <strong>{users.filter((u) => u.role !== "admin" && !u.approved).length}</strong>
              </div>
              <div className="card admin-stat">
                <span>Inactive Users</span>
                <strong>{users.filter((u) => u.role !== "admin" && u.approved && !u.active).length}</strong>
              </div>
              <div className="card admin-stat">
                <span>Client Logins</span>
                <strong>{users.filter((u) => u.role !== "admin").length}</strong>
              </div>
            </div>

            {/* Pending Requests */}
            {users.filter((u) => !u.approved && u.role !== "admin").length > 0 && (
              <section className="card pending-card">
                <div>
                  <h2>New Client Requests</h2>
                  <p>{users.filter((u) => !u.approved && u.role !== "admin").length} waiting for approval</p>
                </div>
                <div className="pending-list">
                  {users
                    .filter((u) => !u.approved && u.role !== "admin")
                    .map((user) => (
                      <div className="pending-user" key={user.username}>
                        <div>
                          <strong>{user.username}</strong>
                          <span>{user.createdAt ? new Date(user.createdAt).toLocaleString() : "New request"}</span>
                        </div>
                        <button
                          className="btn small green"
                          onClick={() => handleApproveUser(user.username)}
                        >
                          Approve
                        </button>
                      </div>
                    ))}
                </div>
              </section>
            )}

            {/* Create Approved User Form */}
            <section className="card analysis-card">
              <h2>Create Approved User</h2>
              {adminFeedback && <div className="success">{adminFeedback}</div>}
              <form className="admin-create" id="addUserForm" onSubmit={handleAddUser}>
                <input
                  id="newUsername"
                  placeholder="Username"
                  value={newAdminUsername}
                  onChange={(e) => setNewAdminUsername(e.target.value)}
                />
                <input
                  id="newPassword"
                  type="password"
                  placeholder="Password"
                  value={newAdminPassword}
                  onChange={(e) => setNewAdminPassword(e.target.value)}
                />
                <button className="btn green" id="addUser" type="submit">
                  Add User
                </button>
              </form>
            </section>

            {/* 50 Login Accounts Table */}
            <section className="card analysis-card">
              <h2>50 Login Account Management</h2>
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>Username</th>
                      <th>Password</th>
                      <th>Role</th>
                      <th>Status</th>
                      <th>Logins</th>
                      <th>Last Login</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[...users]
                      .sort((a, b) => {
                        if (a.approved !== b.approved) return a.approved ? 1 : -1;
                        return a.username.localeCompare(b.username);
                      })
                      .map((user) => (
                        <tr key={user.username}>
                          <td>
                            <strong>{user.username}</strong>
                          </td>
                          <td>
                            <code>{user.password}</code>
                          </td>
                          <td>{user.role}</td>
                          <td>
                            <span
                              className={`status ${
                                !user.approved ? "pending" : user.active ? "active" : "inactive"
                              }`}
                            >
                              {!user.approved ? "Pending" : user.active ? "Active" : "Inactive"}
                            </span>
                          </td>
                          <td>{user.loginCount || 0}</td>
                          <td>{user.lastLogin ? new Date(user.lastLogin).toLocaleString() : "Never"}</td>
                          <td>
                            <div className="actions">
                              {!user.approved && (
                                <button
                                  className="btn small green"
                                  onClick={() => handleApproveUser(user.username)}
                                >
                                  Approve
                                </button>
                              )}
                              {user.approved && (
                                <button
                                  className={`btn small ${user.active ? "blue" : "green"}`}
                                  onClick={() => handleToggleUser(user.username)}
                                >
                                  {user.active ? "Deactivate" : "Activate"}
                                </button>
                              )}
                              {user.role !== "admin" && (
                                <button
                                  className="btn small danger"
                                  onClick={() => handleDeleteUser(user.username)}
                                >
                                  Delete
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </section>
          </section>
        </main>
      )}
    </div>
  );
}
